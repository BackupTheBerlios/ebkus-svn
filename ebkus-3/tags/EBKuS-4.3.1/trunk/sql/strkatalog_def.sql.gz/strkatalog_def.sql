DROP TABLE IF EXISTS `strkatalog`;
CREATE TABLE `strkatalog` (
--  `id` int(11) NOT NULL auto_increment,
  `von` varchar(5) default NULL,
  `bis` varchar(5) default NULL,
  `gu` char(1) default NULL,
  `name` varchar(60) default NULL,
  `plz` varchar(5) default NULL,
  `ort` varchar(60) default NULL,
  `ortsteil` varchar(60) default NULL,
  `samtgemeinde` varchar(60) default NULL,
  `bezirk` varchar(60) default NULL,
  `plraum` varchar(60) default NULL,
--  PRIMARY KEY  (`id`),
  KEY `von` (`von`),
  KEY `name` (`name`(10)),
  KEY `plz` (`plz`),
  KEY `ort` (`ort`(10)),
  KEY `ortsteil` (`ort`(10)),
  KEY `samtgemeinde` (`samtgemeinde`(10)),
  KEY `bezirk` (`ort`(10)),
  KEY `plraum` (`ort`(10))
) TYPE=MyISAM;









