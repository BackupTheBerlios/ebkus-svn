-- MySQL dump 8.22
--
-- Host: localhost    Database: demo_berlin_XX_init_XX
---------------------------------------------------------
-- Server version	3.23.55-Max-log

--
-- Table structure for table 'akte'
--

CREATE TABLE akte (
  id int(11) default NULL,
  vn char(35) default NULL,
  na char(35) default NULL,
  gb char(10) default NULL,
  ber char(30) default NULL,
  str char(35) default NULL,
  hsnr char(5) default NULL,
  plz char(9) default NULL,
  planungsr char(4) default NULL,
  wohnbez int(11) default NULL,
  lage int(11) default NULL,
  ort char(35) default NULL,
  tl1 char(25) default NULL,
  tl2 char(25) default NULL,
  fs int(11) default NULL,
  no char(255) default NULL,
  stzbg int(11) default NULL,
  stzak int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'akte'
--


INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (2,'Klient2Vn','Klient2Na','22.04.1992','Ausbildung von Nr.: 2',NULL,NULL,NULL,'9999',380,384,'Gro�-Lehnau','89560350','',29,'Das sind alles Beispieldaten f�r Form 2',205,205,1097425727);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (3,'Klient3Vn','Klient3Na','15.04.2001','Ausbildung von Nr.: 3','Am Rott','44','32681','0061',379,383,'Klein-Magrau','55737922','',27,'Das sind alles Beispieldaten f�r Form 3',386,386,1097425728);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (4,'Klient4Vn','Klient4Na','27.04.1999','Ausbildung von Nr.: 4','M�llerstr.','75','79037','0061',379,383,'Klein-Magrau','30139150','',36,'Das sind alles Beispieldaten f�r Form 4',386,386,1097425743);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (5,'Klient5Vn','Klient5Na','23.02.1999','Ausbildung von Nr.: 5','Rosenweg','22','81429','0060',379,383,'Unterhausen','99852184','',26,'Das sind alles Beispieldaten f�r Form 5',386,386,1097425746);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (6,'Klient6Vn','Klient6Na','21.10.1995','Ausbildung von Nr.: 6','Am Rott','64','70252','0063',379,383,'Unterhausen','57983052','',30,'Das sind alles Beispieldaten f�r Form 6',386,386,1097425753);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (7,'Klient7Vn','Klient7Na','14.11.1996','Ausbildung von Nr.: 7','Hinterm Markt','37','21512','0061',379,383,'Unterhausen','57101284','',32,'Das sind alles Beispieldaten f�r Form 7',205,205,1097425760);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (8,'Klient8Vn','Klient8Na','19.10.1983','Ausbildung von Nr.: 8','Am Rott','127','60178','0063',379,383,'Unterhausen','79081550','',32,'Das sind alles Beispieldaten f�r Form 8',386,386,1097425767);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (9,'Klient9Vn','Klient9Na','01.07.1984','Ausbildung von Nr.: 9','Rosenweg','265','31366','0062',379,383,'Klein-Magrau','24928020','',29,'Das sind alles Beispieldaten f�r Form 9',386,386,1097425774);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (10,'Klient10Vn','Klient10Na','01.10.1996','Ausbildung von Nr.: 10','Am Rott','161','56869','0060',379,383,'Gro�-Lehnau','13837425','',29,'Das sind alles Beispieldaten f�r Form 10',205,205,1097425782);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (11,'Klient11Vn','Klient11Na','19.02.1994','Ausbildung von Nr.: 11','Hinterm Markt','208','24837','0062',379,383,'Klein-Magrau','106690','',39,'Das sind alles Beispieldaten f�r Form 11',386,386,1097425789);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (12,'Klient12Vn','Klient12Na','08.04.2001','Ausbildung von Nr.: 12','Karl-Marx-Str.','230','65525','0063',379,383,'Gro�-Lehnau','742381','',31,'Das sind alles Beispieldaten f�r Form 12',205,205,1097425798);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (13,'Klient13Vn','Klient13Na','17.09.1992','Ausbildung von Nr.: 13','M�llerstr.','298','61328','0060',379,383,'Gro�-Lehnau','75551954','',38,'Das sind alles Beispieldaten f�r Form 13',205,205,1097425804);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (14,'Klient14Vn','Klient14Na','09.01.1994','Ausbildung von Nr.: 14',NULL,NULL,NULL,'9999',380,384,'Gro�-Lehnau','19759167','',38,'Das sind alles Beispieldaten f�r Form 14',205,205,1097425818);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (15,'Klient15Vn','Klient15Na','25.05.1988','Ausbildung von Nr.: 15','Am Rott','60','81298','0062',379,383,'Klein-Magrau','8621936','',38,'Das sind alles Beispieldaten f�r Form 15',205,205,1097425826);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (16,'Klient16Vn','Klient16Na','16.02.1990','Ausbildung von Nr.: 16','Am Rott','295','59073','0060',379,383,'Unterhausen','30605664','',34,'Das sind alles Beispieldaten f�r Form 16',205,205,1097425828);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (17,'Klient17Vn','Klient17Na','15.10.1984','Ausbildung von Nr.: 17','M�llerstr.','145','82682','0062',379,383,'Gro�-Lehnau','46584736','',33,'Das sind alles Beispieldaten f�r Form 17',386,386,1097425836);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (18,'Klient18Vn','Klient18Na','17.01.1998','Ausbildung von Nr.: 18','Karl-Marx-Str.','271','80158','0062',379,383,'Klein-Magrau','480481','',33,'Das sind alles Beispieldaten f�r Form 18',205,205,1097425854);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (19,'Klient19Vn','Klient19Na','08.12.1989','Ausbildung von Nr.: 19','M�llerstr.','162','91968','0062',379,383,'Klein-Magrau','41513053','',38,'Das sind alles Beispieldaten f�r Form 19',205,205,1097425857);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (20,'Klient20Vn','Klient20Na','22.11.1991','Ausbildung von Nr.: 20','Rosenweg','7','84174','0061',379,383,'Gro�-Lehnau','64934607','',32,'Das sind alles Beispieldaten f�r Form 20',386,386,1097425862);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (21,'Klient21Vn','Klient21Na','18.08.1987','Ausbildung von Nr.: 21','M�llerstr.','194','46003','0062',379,383,'Gro�-Lehnau','46941522','',28,'Das sind alles Beispieldaten f�r Form 21',386,386,1097425874);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (22,'Klient22Vn','Klient22Na','03.09.2001','Ausbildung von Nr.: 22','M�llerstr.','186','90782','0061',379,383,'Gro�-Lehnau','62550601','',31,'Das sind alles Beispieldaten f�r Form 22',205,205,1097425876);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (23,'Klient23Vn','Klient23Na','20.09.1997','Ausbildung von Nr.: 23','Karl-Marx-Str.','38','39383','0063',379,383,'Gro�-Lehnau','81642047','',37,'Das sind alles Beispieldaten f�r Form 23',205,205,1097425887);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (24,'Klient24Vn','Klient24Na','11.08.1989','Ausbildung von Nr.: 24','Teichweg','115','47957','0061',379,383,'Klein-Magrau','25824256','',26,'Das sind alles Beispieldaten f�r Form 24',386,386,1097425898);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (25,'Klient25Vn','Klient25Na','18.11.1994','Ausbildung von Nr.: 25','M�llerstr.','5','70199','0060',379,383,'Gro�-Lehnau','56885662','',37,'Das sind alles Beispieldaten f�r Form 25',386,386,1097425913);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (26,'Klient26Vn','Klient26Na','25.06.1985','Ausbildung von Nr.: 26','Teichweg','250','81554','0063',379,383,'Klein-Magrau','81444618','',39,'Das sind alles Beispieldaten f�r Form 26',386,386,1097425917);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (27,'Klient27Vn','Klient27Na','07.09.1994','Ausbildung von Nr.: 27','Teichweg','115','34667','0061',379,383,'Unterhausen','89636443','',27,'Das sind alles Beispieldaten f�r Form 27',386,386,1097425926);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (28,'Klient28Vn','Klient28Na','05.07.1985','Ausbildung von Nr.: 28','Rosenweg','179','24166','0061',379,383,'Unterhausen','72340283','',36,'Das sind alles Beispieldaten f�r Form 28',386,386,1097425938);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (29,'Klient29Vn','Klient29Na','13.06.2000','Ausbildung von Nr.: 29','Hinterm Markt','232','95791','0060',379,383,'Gro�-Lehnau','65883288','',38,'Das sind alles Beispieldaten f�r Form 29',205,205,1097425942);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (30,'Klient30Vn','Klient30Na','19.12.1988','Ausbildung von Nr.: 30','M�llerstr.','249','23371','0061',379,383,'Gro�-Lehnau','24111226','',26,'Das sind alles Beispieldaten f�r Form 30',386,386,1097425950);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (31,'Klient31Vn','Klient31Na','17.07.1996','Ausbildung von Nr.: 31','Hinterm Markt','40','87274','0060',379,383,'Gro�-Lehnau','39570497','',30,'Das sind alles Beispieldaten f�r Form 31',205,205,1097425960);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (32,'Klient32Vn','Klient32Na','28.12.1998','Ausbildung von Nr.: 32','Karl-Marx-Str.','98','88169','0063',379,383,'Klein-Magrau','89485339','',39,'Das sind alles Beispieldaten f�r Form 32',205,205,1097425968);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (33,'Klient33Vn','Klient33Na','17.01.1987','Ausbildung von Nr.: 33','Hinterm Markt','199','93805','0063',379,383,'Klein-Magrau','41390512','',37,'Das sind alles Beispieldaten f�r Form 33',386,386,1097425975);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (34,'Klient34Vn','Klient34Na','28.05.1985','Ausbildung von Nr.: 34','Rosenweg','118','38831','0061',379,383,'Klein-Magrau','71756795','',35,'Das sind alles Beispieldaten f�r Form 34',386,386,1097425982);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (35,'Klient35Vn','Klient35Na','18.08.1993','Ausbildung von Nr.: 35',NULL,NULL,NULL,'9999',380,384,'Klein-Magrau','85293362','',27,'Das sind alles Beispieldaten f�r Form 35',205,205,1097425997);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (36,'Klient36Vn','Klient36Na','25.03.1991','Ausbildung von Nr.: 36','M�llerstr.','283','99713','0061',379,383,'Klein-Magrau','22012000','',34,'Das sind alles Beispieldaten f�r Form 36',205,205,1097425999);

--
-- Table structure for table 'anmeldung'
--

CREATE TABLE anmeldung (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  von char(35) default NULL,
  ad int(11) default NULL,
  am int(11) default NULL,
  ay int(11) default NULL,
  mtl char(25) default NULL,
  me char(35) default NULL,
  zm int(11) default NULL,
  mg char(255) default NULL,
  no char(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'anmeldung'
--



--
-- Table structure for table 'bezugsperson'
--

CREATE TABLE bezugsperson (
  id int(11) default NULL,
  akte_id int(11) default NULL,
  vn char(35) default NULL,
  na char(35) default NULL,
  gb char(10) default NULL,
  ber char(30) default NULL,
  str char(35) default NULL,
  hsnr char(5) default NULL,
  lage int(11) default NULL,
  plz char(9) default NULL,
  ort char(35) default NULL,
  tl1 char(25) default NULL,
  tl2 char(25) default NULL,
  fs int(11) default NULL,
  verw int(11) default NULL,
  no char(255) default NULL,
  nobed int(11) default NULL,
  vrt int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'bezugsperson'
--


INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (2,2,'Bezugsperson2Vn','Bezugsperson2Na','28.07.1974','Bezugsperson Beruf: 2','Teichweg','135',383,'33605','Unterhausen','42929170','',29,163,'Notiz f�r Bezugsperson: 2',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (3,3,'Bezugsperson3Vn','Bezugsperson3Na','13.06.1931','Bezugsperson Beruf: 3','M�llerstr.','105',383,'69692','Gro�-Lehnau','66876030','',26,165,'Notiz f�r Bezugsperson: 3',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (4,4,'Bezugsperson4Vn','Bezugsperson4Na','15.05.1983','Bezugsperson Beruf: 4','Hinterm Markt','129',383,'37003','Gro�-Lehnau','60121592','',32,164,'Notiz f�r Bezugsperson: 4',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (5,4,'Bezugsperson5Vn','Bezugsperson5Na','08.09.1923','Bezugsperson Beruf: 5','Teichweg','299',383,'91707','Klein-Magrau','58317382','',28,163,'Notiz f�r Bezugsperson: 5',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (6,4,'Bezugsperson6Vn','Bezugsperson6Na','21.06.1918','Bezugsperson Beruf: 6','Am Rott','216',383,'78248','Unterhausen','65398794','',30,170,'Notiz f�r Bezugsperson: 6',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (7,5,'Bezugsperson7Vn','Bezugsperson7Na','16.05.1938','Bezugsperson Beruf: 7','Hinterm Markt','282',383,'45912','Klein-Magrau','55233983','',31,164,'Notiz f�r Bezugsperson: 7',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (8,6,'Bezugsperson8Vn','Bezugsperson8Na','22.11.1981','Bezugsperson Beruf: 8','Am Rott','243',383,'70288','Gro�-Lehnau','32601784','',35,162,'Notiz f�r Bezugsperson: 8',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (9,6,'Bezugsperson9Vn','Bezugsperson9Na','19.06.1967','Bezugsperson Beruf: 9','Karl-Marx-Str.','180',383,'86524','Klein-Magrau','39885357','',28,171,'Notiz f�r Bezugsperson: 9',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (10,6,'Bezugsperson10Vn','Bezugsperson10Na','14.04.1910','Bezugsperson Beruf: 10','Am Rott','279',383,'62912','Unterhausen','41389367','',39,165,'Notiz f�r Bezugsperson: 10',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (11,7,'Bezugsperson11Vn','Bezugsperson11Na','10.04.1973','Bezugsperson Beruf: 11','Teichweg','287',383,'33002','Unterhausen','16318127','',30,172,'Notiz f�r Bezugsperson: 11',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (12,7,'Bezugsperson12Vn','Bezugsperson12Na','08.12.1958','Bezugsperson Beruf: 12','Am Rott','298',383,'26851','Gro�-Lehnau','26238192','',32,167,'Notiz f�r Bezugsperson: 12',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (13,8,'Bezugsperson13Vn','Bezugsperson13Na','24.06.1933','Bezugsperson Beruf: 13','Teichweg','76',383,'31908','Gro�-Lehnau','23093660','',35,165,'Notiz f�r Bezugsperson: 13',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (14,9,'Bezugsperson14Vn','Bezugsperson14Na','06.02.1950','Bezugsperson Beruf: 14','Teichweg','7',383,'27803','Unterhausen','44175438','',39,169,'Notiz f�r Bezugsperson: 14',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (15,9,'Bezugsperson15Vn','Bezugsperson15Na','02.10.1984','Bezugsperson Beruf: 15','Hinterm Markt','200',383,'82412','Unterhausen','25937684','',37,168,'Notiz f�r Bezugsperson: 15',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (16,10,'Bezugsperson16Vn','Bezugsperson16Na','21.09.1919','Bezugsperson Beruf: 16','Karl-Marx-Str.','168',383,'97439','Klein-Magrau','5186038','',27,165,'Notiz f�r Bezugsperson: 16',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (17,10,'Bezugsperson17Vn','Bezugsperson17Na','08.08.1959','Bezugsperson Beruf: 17','Karl-Marx-Str.','205',383,'96221','Gro�-Lehnau','98822907','',32,166,'Notiz f�r Bezugsperson: 17',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (18,10,'Bezugsperson18Vn','Bezugsperson18Na','24.11.1927','Bezugsperson Beruf: 18','Rosenweg','176',383,'63801','Klein-Magrau','15198059','',29,166,'Notiz f�r Bezugsperson: 18',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (19,11,'Bezugsperson19Vn','Bezugsperson19Na','08.01.1958','Bezugsperson Beruf: 19','Teichweg','178',383,'29715','Gro�-Lehnau','35983064','',38,169,'Notiz f�r Bezugsperson: 19',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (20,11,'Bezugsperson20Vn','Bezugsperson20Na','01.10.1951','Bezugsperson Beruf: 20','Karl-Marx-Str.','128',383,'19871','Klein-Magrau','75695152','',29,162,'Notiz f�r Bezugsperson: 20',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (21,12,'Bezugsperson21Vn','Bezugsperson21Na','12.11.1971','Bezugsperson Beruf: 21','Rosenweg','12',383,'40506','Klein-Magrau','24160757','',38,163,'Notiz f�r Bezugsperson: 21',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (22,12,'Bezugsperson22Vn','Bezugsperson22Na','11.10.1918','Bezugsperson Beruf: 22','Rosenweg','284',383,'24601','Klein-Magrau','48260115','',34,171,'Notiz f�r Bezugsperson: 22',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (23,12,'Bezugsperson23Vn','Bezugsperson23Na','06.05.1974','Bezugsperson Beruf: 23','Karl-Marx-Str.','132',383,'29538','Gro�-Lehnau','36094142','',39,167,'Notiz f�r Bezugsperson: 23',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (24,13,'Bezugsperson24Vn','Bezugsperson24Na','07.10.1973','Bezugsperson Beruf: 24','Teichweg','9',383,'73795','Gro�-Lehnau','85924532','',38,164,'Notiz f�r Bezugsperson: 24',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (25,14,'Bezugsperson25Vn','Bezugsperson25Na','27.02.1968','Bezugsperson Beruf: 25','Hinterm Markt','103',383,'67477','Unterhausen','59148840','',26,162,'Notiz f�r Bezugsperson: 25',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (26,15,'Bezugsperson26Vn','Bezugsperson26Na','06.11.1932','Bezugsperson Beruf: 26','M�llerstr.','238',383,'37185','Klein-Magrau','24709418','',30,162,'Notiz f�r Bezugsperson: 26',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (27,16,'Bezugsperson27Vn','Bezugsperson27Na','24.09.1943','Bezugsperson Beruf: 27','Am Rott','270',383,'77432','Gro�-Lehnau','43082652','',30,172,'Notiz f�r Bezugsperson: 27',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (28,16,'Bezugsperson28Vn','Bezugsperson28Na','25.10.1956','Bezugsperson Beruf: 28','M�llerstr.','264',383,'58723','Klein-Magrau','536392','',32,171,'Notiz f�r Bezugsperson: 28',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (29,17,'Bezugsperson29Vn','Bezugsperson29Na','16.02.1923','Bezugsperson Beruf: 29','Teichweg','95',383,'52530','Klein-Magrau','15571398','',36,168,'Notiz f�r Bezugsperson: 29',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (30,17,'Bezugsperson30Vn','Bezugsperson30Na','08.05.1921','Bezugsperson Beruf: 30','Teichweg','80',383,'81222','Unterhausen','34605314','',39,163,'Notiz f�r Bezugsperson: 30',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (31,18,'Bezugsperson31Vn','Bezugsperson31Na','06.05.1944','Bezugsperson Beruf: 31','Hinterm Markt','127',383,'17277','Klein-Magrau','74531747','',29,161,'Notiz f�r Bezugsperson: 31',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (32,18,'Bezugsperson32Vn','Bezugsperson32Na','14.04.1945','Bezugsperson Beruf: 32','Karl-Marx-Str.','257',383,'50856','Klein-Magrau','79054551','',34,166,'Notiz f�r Bezugsperson: 32',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (33,19,'Bezugsperson33Vn','Bezugsperson33Na','22.09.1921','Bezugsperson Beruf: 33','Karl-Marx-Str.','67',383,'30965','Gro�-Lehnau','27398453','',27,163,'Notiz f�r Bezugsperson: 33',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (34,19,'Bezugsperson34Vn','Bezugsperson34Na','16.10.1936','Bezugsperson Beruf: 34','Rosenweg','156',383,'41768','Klein-Magrau','42078589','',34,162,'Notiz f�r Bezugsperson: 34',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (35,20,'Bezugsperson35Vn','Bezugsperson35Na','02.06.1931','Bezugsperson Beruf: 35','Teichweg','55',383,'85589','Klein-Magrau','47917738','',33,172,'Notiz f�r Bezugsperson: 35',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (36,21,'Bezugsperson36Vn','Bezugsperson36Na','14.08.1947','Bezugsperson Beruf: 36','Teichweg','67',383,'79103','Unterhausen','75291672','',27,163,'Notiz f�r Bezugsperson: 36',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (37,22,'Bezugsperson37Vn','Bezugsperson37Na','10.03.1927','Bezugsperson Beruf: 37','Hinterm Markt','54',383,'76034','Gro�-Lehnau','56000856','',36,172,'Notiz f�r Bezugsperson: 37',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (38,22,'Bezugsperson38Vn','Bezugsperson38Na','19.10.1969','Bezugsperson Beruf: 38','M�llerstr.','239',383,'52801','Unterhausen','89666475','',34,164,'Notiz f�r Bezugsperson: 38',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (39,23,'Bezugsperson39Vn','Bezugsperson39Na','04.03.1917','Bezugsperson Beruf: 39','Am Rott','295',383,'39132','Unterhausen','13546684','',36,162,'Notiz f�r Bezugsperson: 39',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (40,23,'Bezugsperson40Vn','Bezugsperson40Na','25.12.1938','Bezugsperson Beruf: 40','Teichweg','150',383,'45873','Gro�-Lehnau','99375028','',27,171,'Notiz f�r Bezugsperson: 40',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (41,23,'Bezugsperson41Vn','Bezugsperson41Na','26.04.1922','Bezugsperson Beruf: 41','Am Rott','32',383,'68759','Gro�-Lehnau','17928646','',35,169,'Notiz f�r Bezugsperson: 41',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (42,24,'Bezugsperson42Vn','Bezugsperson42Na','21.12.1925','Bezugsperson Beruf: 42','Rosenweg','119',383,'24482','Klein-Magrau','13692432','',34,167,'Notiz f�r Bezugsperson: 42',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (43,24,'Bezugsperson43Vn','Bezugsperson43Na','10.02.1980','Bezugsperson Beruf: 43','Rosenweg','62',383,'35498','Unterhausen','98134793','',33,166,'Notiz f�r Bezugsperson: 43',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (44,24,'Bezugsperson44Vn','Bezugsperson44Na','05.10.1971','Bezugsperson Beruf: 44','Karl-Marx-Str.','275',383,'23075','Klein-Magrau','78146603','',27,161,'Notiz f�r Bezugsperson: 44',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (45,25,'Bezugsperson45Vn','Bezugsperson45Na','21.11.1954','Bezugsperson Beruf: 45','Hinterm Markt','197',383,'98302','Gro�-Lehnau','55065253','',33,168,'Notiz f�r Bezugsperson: 45',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (46,26,'Bezugsperson46Vn','Bezugsperson46Na','24.10.1925','Bezugsperson Beruf: 46','Teichweg','16',383,'23225','Unterhausen','65204260','',34,168,'Notiz f�r Bezugsperson: 46',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (47,26,'Bezugsperson47Vn','Bezugsperson47Na','18.10.1964','Bezugsperson Beruf: 47','Rosenweg','202',383,'95053','Unterhausen','26853730','',34,162,'Notiz f�r Bezugsperson: 47',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (48,27,'Bezugsperson48Vn','Bezugsperson48Na','17.10.1922','Bezugsperson Beruf: 48','Karl-Marx-Str.','232',383,'34445','Klein-Magrau','27495472','',36,169,'Notiz f�r Bezugsperson: 48',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (49,27,'Bezugsperson49Vn','Bezugsperson49Na','14.01.1955','Bezugsperson Beruf: 49','M�llerstr.','240',383,'62406','Klein-Magrau','82947696','',38,170,'Notiz f�r Bezugsperson: 49',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (50,28,'Bezugsperson50Vn','Bezugsperson50Na','22.05.1924','Bezugsperson Beruf: 50','Rosenweg','5',383,'50287','Unterhausen','85155890','',27,172,'Notiz f�r Bezugsperson: 50',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (51,29,'Bezugsperson51Vn','Bezugsperson51Na','03.02.1936','Bezugsperson Beruf: 51','Hinterm Markt','152',383,'35150','Unterhausen','25632242','',32,165,'Notiz f�r Bezugsperson: 51',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (52,29,'Bezugsperson52Vn','Bezugsperson52Na','17.08.1914','Bezugsperson Beruf: 52','Rosenweg','128',383,'61009','Gro�-Lehnau','63943249','',39,170,'Notiz f�r Bezugsperson: 52',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (53,29,'Bezugsperson53Vn','Bezugsperson53Na','10.04.1919','Bezugsperson Beruf: 53','Teichweg','292',383,'58392','Klein-Magrau','96209464','',33,160,'Notiz f�r Bezugsperson: 53',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (54,30,'Bezugsperson54Vn','Bezugsperson54Na','07.06.1924','Bezugsperson Beruf: 54','Rosenweg','156',383,'91180','Klein-Magrau','78354530','',37,166,'Notiz f�r Bezugsperson: 54',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (55,30,'Bezugsperson55Vn','Bezugsperson55Na','08.11.1956','Bezugsperson Beruf: 55','Karl-Marx-Str.','37',383,'91992','Klein-Magrau','55876363','',37,170,'Notiz f�r Bezugsperson: 55',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (56,31,'Bezugsperson56Vn','Bezugsperson56Na','21.09.1983','Bezugsperson Beruf: 56','Rosenweg','24',383,'67561','Unterhausen','6173247','',34,172,'Notiz f�r Bezugsperson: 56',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (57,31,'Bezugsperson57Vn','Bezugsperson57Na','11.06.1937','Bezugsperson Beruf: 57','M�llerstr.','87',383,'32787','Unterhausen','34272318','',33,165,'Notiz f�r Bezugsperson: 57',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (58,31,'Bezugsperson58Vn','Bezugsperson58Na','10.10.1979','Bezugsperson Beruf: 58','Am Rott','90',383,'53934','Gro�-Lehnau','62468357','',36,167,'Notiz f�r Bezugsperson: 58',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (59,32,'Bezugsperson59Vn','Bezugsperson59Na','08.10.1977','Bezugsperson Beruf: 59','Am Rott','115',383,'83005','Gro�-Lehnau','61033176','',27,169,'Notiz f�r Bezugsperson: 59',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (60,32,'Bezugsperson60Vn','Bezugsperson60Na','15.07.1982','Bezugsperson Beruf: 60','Karl-Marx-Str.','157',383,'72993','Klein-Magrau','2256211','',26,166,'Notiz f�r Bezugsperson: 60',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (61,33,'Bezugsperson61Vn','Bezugsperson61Na','04.05.1926','Bezugsperson Beruf: 61','Am Rott','209',383,'61479','Unterhausen','13578902','',35,171,'Notiz f�r Bezugsperson: 61',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (62,34,'Bezugsperson62Vn','Bezugsperson62Na','06.09.1916','Bezugsperson Beruf: 62','Hinterm Markt','182',383,'50366','Unterhausen','81587468','',35,168,'Notiz f�r Bezugsperson: 62',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (63,34,'Bezugsperson63Vn','Bezugsperson63Na','28.12.1960','Bezugsperson Beruf: 63','Karl-Marx-Str.','47',383,'95100','Klein-Magrau','10502056','',33,160,'Notiz f�r Bezugsperson: 63',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (64,35,'Bezugsperson64Vn','Bezugsperson64Na','07.07.1954','Bezugsperson Beruf: 64','Rosenweg','288',383,'46884','Unterhausen','62857894','',36,170,'Notiz f�r Bezugsperson: 64',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (65,35,'Bezugsperson65Vn','Bezugsperson65Na','09.05.1974','Bezugsperson Beruf: 65','Am Rott','118',383,'94906','Unterhausen','11904813','',35,170,'Notiz f�r Bezugsperson: 65',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (66,35,'Bezugsperson66Vn','Bezugsperson66Na','12.10.1923','Bezugsperson Beruf: 66','Karl-Marx-Str.','203',383,'28591','Gro�-Lehnau','41505598','',36,163,'Notiz f�r Bezugsperson: 66',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (67,36,'Bezugsperson67Vn','Bezugsperson67Na','19.05.1972','Bezugsperson Beruf: 67','Teichweg','53',383,'68289','Klein-Magrau','75164537','',35,163,'Notiz f�r Bezugsperson: 67',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (68,36,'Bezugsperson68Vn','Bezugsperson68Na','14.08.1959','Bezugsperson Beruf: 68','Teichweg','238',383,'67114','Unterhausen','64231796','',34,172,'Notiz f�r Bezugsperson: 68',213,215);

--
-- Table structure for table 'bezugspersongruppe'
--

CREATE TABLE bezugspersongruppe (
  id int(11) default NULL,
  bezugsp_id int(11) default NULL,
  gruppe_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'bezugspersongruppe'
--



--
-- Table structure for table 'code'
--

CREATE TABLE code (
  id int(11) default NULL,
  kat_id int(11) default NULL,
  kat_code char(8) default NULL,
  code char(8) default NULL,
  name char(160) default NULL,
  sort int(11) default NULL,
  mini int(11) default NULL,
  maxi int(11) default NULL,
  off int(11) default NULL,
  dm int(11) default NULL,
  dy int(11) default NULL,
  dok char(255) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'code'
--


INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (1,1,'verwtyp','s','Schl�ssel',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (2,1,'verwtyp','f','Fremdschl�ssel',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (3,1,'verwtyp','k','Kategorie',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (4,1,'verwtyp','b','Bereichskategorie',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (5,1,'verwtyp','p','Primitiv',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (6,30,'gs','1','m',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (7,30,'gs','2','w',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (8,2,'fsag','1','0-2',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (9,2,'fsag','2','3-5',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (10,2,'fsag','3','6-9',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (11,2,'fsag','4','10-13',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (12,2,'fsag','5','14-17',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (13,2,'fsag','6','18-20',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (14,2,'fsag','7','21-26',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (15,2,'fsag','8','vor d. Schw.',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (16,2,'fsag','9','pr�natal',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (17,2,'fsag','999','keine Angabe',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (18,3,'fsagel','1','bis 20',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (19,3,'fsagel','2','21-26',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (20,3,'fsagel','3','27-44',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (21,3,'fsagel','4','45-54',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (22,3,'fsagel','5','55-64',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (23,3,'fsagel','6','65-74',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (24,3,'fsagel','7','75-',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (25,3,'fsagel','999','keine Angabe',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (26,4,'fsfs','1','verheiratet, leibl. Eltern',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (27,4,'fsfs','2','unverheiratet, leibl. Eltern',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (28,4,'fsfs','3','wechselnd bei Km u. Kv',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (29,4,'fsfs','4','Elternteil u. Stiefelternteil',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (30,4,'fsfs','5','alleinerziehende Mutter',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (31,4,'fsfs','6','alleinerziehender Vater',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (32,4,'fsfs','7','Verwandte',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (33,4,'fsfs','8','Pflegefamilie',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (34,4,'fsfs','9','Adoptivfamilie',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (35,4,'fsfs','10','Heim',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (36,4,'fsfs','11','Wohngemeinschaft',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (37,4,'fsfs','12','eigene Wohnung',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (38,4,'fsfs','13','obdachlos',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (39,4,'fsfs','14','sonstige',14,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (40,4,'fsfs','999','keine Angabe',15,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (41,5,'fszm','1','ohne Empfehlung',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (42,5,'fszm','2','Klient/Bekannte',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (43,5,'fszm','3','ASD',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (44,5,'fszm','4','KJGD/KJPD',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (45,5,'fszm','5','Kita/Hort',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (46,5,'fszm','6','Schule',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (47,5,'fszm','7','Schulpsychologie',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (48,5,'fszm','8','Kinder-/Jugendbetreuung',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (49,5,'fszm','9','Medizinische Einrichtung',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (50,5,'fszm','10','Gericht',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (51,5,'fszm','11','�ffentlichkeitsarbeit',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (52,5,'fszm','12','Sonstige',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (53,5,'fszm','999','keine Angabe',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (54,6,'fsba','1','Entwicklungs-, Verhaltensauff. in d. Familie',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (55,6,'fsba','2','Entwicklungs-, Verhaltensauff. in d. Kita',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (56,6,'fsba','3','Entwicklungs-, Verhaltensauff. in d. Schule',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (57,6,'fsba','4','Entwicklungs-, Verhaltensauff. im sonst. Umfeld',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (58,6,'fsba','5','Entwickungs- , Verhaltensauff., sonstige',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (59,6,'fsba','6','Leistungsproblem in der Schule/Ausbildung',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (60,6,'fsba','7','Lebensproblem der Jugendlichen',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (61,6,'fsba','8','Abl�sungsproblem des Jugendlichen',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (62,6,'fsba','9','Krise der Jugendlichen',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (63,6,'fsba','10','sexueller Missbrauch',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (64,6,'fsba','11','�berforderung der Eltern',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (65,6,'fsba','12','Erziehungsunsicherheiten',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (66,6,'fsba','13','Familienkonflikt',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (67,6,'fsba','14','Paarkonflikt',14,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (68,6,'fsba','15','Trennungs- / Scheidungsproblem der Eltern',15,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (69,6,'fsba','16','Sorge- oder Umgangsrecht',16,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (70,6,'fsba','17','Begleiteter Umgang',17,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (71,6,'fsba','18','akute Krise des Ratsuchenden',18,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (72,6,'fsba','19','Begleitung vor u. nach Fremdunterbringung',19,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (73,6,'fsba','20','Stellungnahme KJHG-Psychotherapie',20,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (74,6,'fsba','21','Stellungnahme f�r anderen Dienst',21,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (75,6,'fsba','22','Gerichtsgutachten',22,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (76,6,'fsba','23','sonstiges',23,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (77,6,'fsba','999','keine Angabe',24,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (78,7,'fsbe','1','nicht berufst�tig',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (79,7,'fsbe','2','Vollzeit angestellt / ABM',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (80,7,'fsbe','3','Teilzeit angestellt / ABM',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (81,7,'fsbe','4','Schichtarbeit',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (82,7,'fsbe','5','selbst�ndig',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (83,7,'fsbe','6','arbeitslos',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (84,7,'fsbe','7','Sozialhilfe',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (85,7,'fsbe','8','berentet',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (86,7,'fsbe','9','in Ausbildung oder Umschulung',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (87,7,'fsbe','10','sonstige',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (88,7,'fsbe','999','keine Angabe',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (89,8,'fshe','1','Deutschland',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (90,8,'fshe','2','Europa',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (91,8,'fshe','3','Ost-Europa',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (92,8,'fshe','4','T�rkei',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (93,8,'fshe','5','arabische L�nder',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (94,8,'fshe','6','Schwarz-Afrika',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (95,8,'fshe','7','Asien',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (96,8,'fshe','8','Nordamerika',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (97,8,'fshe','9','Lateinamerika',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (98,8,'fshe','10','Australien',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (99,8,'fshe','11','andere L�nder',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (100,8,'fshe','999','keine Angabe',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (101,9,'fspbe','1','Krankheit, Behinderung',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (102,9,'fspbe','2','Alkohol-, Drogenkonsum',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (103,9,'fspbe','3','chronifizierte psychische Erkrankung',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (104,9,'fspbe','4','Opfer famili�rer Gewalt, sex. Missbrauchs',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (105,9,'fspbe','5','starke Traumatisierung (Krieg, Folter)',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (106,9,'fspbe','6','�berforderung',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (107,9,'fspbe','7','Isolation und Kontaktschwierigkeiten',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (108,9,'fspbe','8','Verschuldung',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (109,9,'fspbe','9','unzureichende Wohnverh�ltnisse',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (110,9,'fspbe','10','sonstige',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (111,9,'fspbe','999','keine Angabe',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (112,10,'fspbk','1','allg. Erziehungs-, Entwicklungsproblem',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (113,10,'fspbk','2','neurotische oder psychosomatische Reaktion',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (114,10,'fspbk','3','Vernachl�ssigung, Verwahrlosung',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (115,10,'fspbk','4','Opfer von Gewalt, Misshandlung',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (116,10,'fspbk','5','Sexueller Missbrauch (Opfer)',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (117,10,'fspbk','6','Alkohol-, Drogenkonsum',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (118,10,'fspbk','7','strafbares Verhalten',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (119,10,'fspbk','8','Schulleistungsproblem',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (120,10,'fspbk','9','Schulverweigerung',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (121,10,'fspbk','10','soziale Kontaktschwierigkeit, Isolation',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (122,10,'fspbk','11','aggressives Verhalten',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (123,10,'fspbk','12','Gewaltbereitschaft des Jugendlichen',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (124,10,'fspbk','13','berufliche Perspektive',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (125,10,'fspbk','14','Behinderung',14,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (126,10,'fspbk','15','Suizidgef�hrdung',15,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (127,10,'fspbk','16','Esst�rung',16,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (128,10,'fspbk','17','traumat. Verlust, Tod einer Bezugsperson',17,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (129,10,'fspbk','18','sonstige',18,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (130,10,'fspbk','999','keine Angabe',19,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (131,11,'fsle','1','Erziehungsberatung',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (132,11,'fsle','2','Trennungs-, Scheidungsberatung, Mediation, Umgangsberatung',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (133,11,'fsle','3','Begleiteter Umgang',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (134,11,'fsle','4','Familienberatung, -therapie',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (135,11,'fsle','5','Paarberatung, -therapie',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (136,11,'fsle','6','Einzelbetreuung / -therapie Kind',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (137,11,'fsle','7','Einzelbetreuung / -therapie Jugendlicher',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (138,11,'fsle','8','Einzelbetreuung / -therapie Erwachsener',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (139,11,'fsle','9','Gruppentherapie Kinder',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (140,11,'fsle','10','Gruppentherapie Jugendliche',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (141,11,'fsle','11','Gruppentherapie Erwachsene',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (142,11,'fsle','12','Arbeit im sozialen Umfeld',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (143,11,'fsle','13','spezieller Diagnostikauftrag',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (144,11,'fsle','14','Hilfeplanung, Hilfekonferenz',14,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (145,11,'fsle','15','fachliche Bescheinigung f�r Klienten',15,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (146,11,'fsle','16','Begleitung KJHG-Therapie',16,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (147,11,'fsle','17','Fachdienstliche Stellungnahme',17,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (148,11,'fsle','18','Gerichtsgutachten',18,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (149,11,'fsle','19','sonstige',19,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (150,11,'fsle','999','keine Angabe',20,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (151,12,'fskat','0','keine Angabe',1,0,0,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (152,12,'fskat','1','1-5',2,1,5,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (153,12,'fskat','2','6-10',3,6,10,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (154,12,'fskat','3','11-15',4,11,15,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (155,12,'fskat','4','16-20',5,16,20,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (156,12,'fskat','5','21-30',6,21,30,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (157,12,'fskat','6','31-40',7,31,40,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (158,12,'fskat','7','41-50',8,41,50,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (159,12,'fskat','8','mehr als 50',9,51,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (160,15,'klerv','1','Mutter',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (161,15,'klerv','2','Vater',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (162,15,'klerv','3','Geschwister',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (163,15,'klerv','4','Halbgeschw.',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (164,15,'klerv','5','Stiefmutter',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (165,15,'klerv','6','Stiefvater',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (166,15,'klerv','7','Grossmutter',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (167,15,'klerv','8','Grossvater',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (168,15,'klerv','9','verwandt',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (169,15,'klerv','10','Pflegemutter',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (170,15,'klerv','11','Pflegevater',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (171,15,'klerv','12','Adoptivmutter',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (172,15,'klerv','13','sonstige',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (173,15,'klerv','999','k. Angabe',14,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (174,16,'klinsta','1','ASD',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (175,16,'klinsta','2','KJGD/KJPD',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (176,16,'klinsta','3','Kita/Hort',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (177,16,'klinsta','4','Schule',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (178,16,'klinsta','5','Heim',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (179,16,'klinsta','6','Wohngemeinschaft',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (180,16,'klinsta','7','Freizeiteinr.',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (181,16,'klinsta','8','Arzt',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (182,16,'klinsta','9','Klinik',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (183,16,'klinsta','10','Gericht',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (184,16,'klinsta','11','Schulpsychologie',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (185,16,'klinsta','12','Sonstige',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (186,16,'klinsta','999','keine Angabe',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (187,13,'fsqualij','1','Schule',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (188,13,'fsqualij','2','Studium',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (189,13,'fsqualij','3','Lehre',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (190,13,'fsqualij','4','Arbeitslos',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (191,13,'fsqualij','5','berufst�tig',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (192,13,'fsqualij','5','Berufsf�rderung',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (193,13,'fsqualij','6','sonstige',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (194,13,'fsqualij','999','keine Angabe',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (195,14,'fsquali','1','Schule',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (196,14,'fsquali','2','ungelernt',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (197,14,'fsquali','3','Berufsausbildung',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (198,14,'fsquali','4','Facharbeiter',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (199,14,'fsquali','5','Hochschulabschluss',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (200,14,'fsquali','6','Umschulung',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (201,14,'fsquali','7','sonstige',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (202,14,'fsquali','999','keine Angabe',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (203,17,'status','i','im Dienst',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (204,17,'status','a','nicht im Dienst',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (205,18,'stzei','A','Stelle A',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (206,19,'benr','admin','Administrator',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (207,19,'benr','bearb','Fallbearbeiter',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (208,19,'benr','verw','Verwaltung',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (209,19,'benr','protokol','protokol',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (210,20,'stand','l','laufender Fall',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (211,20,'stand','zdA','zu den Akten',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (212,21,'notizbed','t','Notiz wichtig',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (213,21,'notizbed','f','Notiz',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (214,22,'vert','t','ist im Verteiler',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (215,22,'vert','f','nicht im Verteiler',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (216,23,'einrstat','ja','aktuelle Einrichtung',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (217,23,'einrstat','nein','fr�here Einrichtung',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (218,24,'rbz','0','Berlin',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (219,25,'kr','01','Mitte',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (220,25,'kr','02','Friedrichshain-Kreuzberg',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (221,25,'kr','03','Pankow',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (222,25,'kr','04','Charlottenburg-Wilmersdorf',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (223,25,'kr','05','Spandau',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (224,25,'kr','06','Steglitz-Zehlendorf',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (225,25,'kr','07','Tempelhof-Sch�neberg',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (226,25,'kr','08','Neuk�lln',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (227,25,'kr','09','Treptow-K�penick',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (228,25,'kr','10','Marzahn-Hellersdorf',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (229,25,'kr','11','Lichtenberg',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (230,25,'kr','12','Reinickendorf',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (231,26,'gm','000','N.N.',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (232,27,'gmt','000','N.N.',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (233,28,'traeg','1','Tr�ger der �ffentl. JGH',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (234,28,'traeg','2','Tr�ger der freien JGH',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (235,29,'bgr','1','Beratung wurde einvernehmlich beendet',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (236,29,'bgr','2','letzter Kontakt liegt mehr als 6 M. zur�ck',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (237,29,'bgr','3','Weiterverweisung',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (238,31,'ag','1','unter 3',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (239,31,'ag','2','3 - unter 6',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (240,31,'ag','3','6 - unter 9',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (241,31,'ag','4','9 - unter 12',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (242,31,'ag','5','12 - unter 15',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (243,31,'ag','6','15 - unter 18',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (244,31,'ag','7','18 - unter 21',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (245,31,'ag','8','21 - unter 24',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (246,31,'ag','9','24 - unter 27',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (247,32,'fs','01','bei Eltern',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (248,32,'fs','02','bei 1 Elternteil mit Stiefelternteil',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (249,32,'fs','03','bei alleinerziehendem Elternteil',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (250,32,'fs','04','bei Grosseltern, Verwandten',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (251,32,'fs','05','in einer Pflegestelle',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (252,32,'fs','06','in einem Heim',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (253,32,'fs','07','in einer Wohngemeinschaft',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (254,32,'fs','08','in eigener Wohnung',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (255,32,'fs','09','ohne feste Unterkunft',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (256,32,'fs','10','an unbekanntem Ort',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (257,33,'hke','1','deutsch',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (258,33,'hke','2','nicht-deutsch',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (259,33,'hke','3','unbekannt',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (260,35,'gsa','0','kein Geschwister',1,0,0,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (261,35,'gsa','1','1 Geschwister',2,1,1,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (262,35,'gsa','2','2 Geschwister',3,2,2,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (263,35,'gsa','3','3 Geschwister',4,3,3,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (264,35,'gsa','4','mehr als 3 Geschwister',5,4,20,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (265,36,'gsu','0','bekannt',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (266,36,'gsu','1','unbekannt',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (267,34,'zm','1','jungen Menschen selbst',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (268,34,'zm','2','Eltern gemeinsam',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (269,34,'zm','3','Mutter',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (270,34,'zm','4','Vater',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (271,34,'zm','5','soziale Dienste',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (272,34,'zm','6','Sonstige',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (273,37,'ba0','1','Entwicklungsauff�lligkeiten',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (274,37,'ba0','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (275,38,'ba1','1','Beziehungsprobleme',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (276,38,'ba1','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (277,39,'ba2','1','Schule-/Ausbildungsprobleme',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (278,39,'ba2','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (279,40,'ba3','1','Straftat d. Jugendl./jungen Vollj�hrigen',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (280,40,'ba3','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (281,41,'ba4','1','Suchtprobleme des jungen Menschen',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (282,41,'ba4','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (283,42,'ba5','1','Anzeichen f�r Kindesmisshandlung',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (284,42,'ba5','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (285,43,'ba6','1','Anzeichen f�r sexuellen Missbrauch',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (286,43,'ba6','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (287,44,'ba7','1','Trennung/Scheidung der Eltern',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (288,44,'ba7','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (289,45,'ba8','1','Wohnungsprobleme',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (290,45,'ba8','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (291,46,'ba9','1','sonstige Probleme in u. mit der Familie',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (292,46,'ba9','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (293,47,'schw','1','Erziehungs-/Familienberatung',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (294,47,'schw','2','Jugendberatung',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (295,47,'schw','3','Suchtberatung',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (296,48,'fbe0','1','allein',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (297,48,'fbe0','2','in der Gruppe',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (298,48,'fbe0','0','leer',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (299,49,'fbe1','1','allein',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (300,49,'fbe1','2','in der Gruppe',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (301,49,'fbe1','0','leer',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (302,50,'fbe2','1','in der Familie',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (303,50,'fbe2','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (304,51,'fbe3','1','im sozialen Umfeld',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (305,51,'fbe3','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (306,52,'mimetyp','txt','text/plain',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (307,52,'mimetyp','asc','text/plain',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (308,52,'mimetyp','html','text/html',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (309,52,'mimetyp','htm','text/html',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (310,52,'mimetyp','pdf','application/pdf',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (311,52,'mimetyp','ps','application/postscript',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (312,52,'mimetyp','doc','application/msword',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (313,52,'mimetyp','dot','application/msword',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (314,52,'mimetyp','wrd','application/msword',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (315,52,'mimetyp','rtf','application/rtf',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (316,52,'mimetyp','xls','application/x-msexcel',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (317,52,'mimetyp','sdw','application/soffice',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (318,52,'mimetyp','sxw','application/soffice',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (319,52,'mimetyp','sdc','application/vnd.stardivision.calc',14,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (320,52,'mimetyp','zip','application/zip',15,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (321,52,'mimetyp','gtar','application/x-gtar',16,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (322,52,'mimetyp','tgz','application/x-gtar',17,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (323,52,'mimetyp','gz','application/x-gzip',18,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (324,52,'mimetyp','tar','application/x-tar',19,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (325,52,'mimetyp','rtx','text/richtext',20,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (326,52,'mimetyp','gif','image/gif',21,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (327,52,'mimetyp','jpg','image/jpeg',22,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (328,52,'mimetyp','jpeg','image/jpeg',23,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (329,52,'mimetyp','jpe','image/jpeg',24,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (330,52,'mimetyp','tiff','image/tiff',25,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (331,52,'mimetyp','tif','image/tiff',26,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (332,52,'mimetyp','png','image/png',27,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (333,52,'mimetyp','bmp','image/bmp',28,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (334,53,'dokart','bnotiz','Beraternotiz',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (335,53,'dokart','Vm','Vermerk',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (336,53,'dokart','anotiz','Aktennotiz',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (337,53,'dokart','Brief','Brief',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (338,53,'dokart','Prot','Protokoll',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (339,53,'dokart','Dok','Dokument',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (340,53,'dokart','Antrag','Antrag',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (341,53,'dokart','Bericht','Bericht',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (342,53,'dokart','Stellung','Stellungnahme',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (343,53,'dokart','Befund','Befunddokument',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (344,53,'dokart','Gutacht','Gutachten',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (345,53,'dokart','Beschein','Bescheinigung',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (346,53,'dokart','Sonstig','Sonstiges',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (347,54,'teiln','Kinder','Kinder',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (348,54,'teiln','Jugendl','Jugendliche',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (349,54,'teiln','Eltern','Eltern',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (350,54,'teiln','V�ter','V�ter',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (351,54,'teiln','M�tter','M�tter',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (352,54,'teiln','Altgem','Altersgemischt',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (353,54,'teiln','Familien','Familien',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (354,54,'teiln','Erzieher','ErzieherInnen',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (355,54,'teiln','Lehrer','Lehrer',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (356,54,'teiln','Paare','Paare',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (357,54,'teiln','sonstige','sonstige',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (358,55,'grtyp','Eabend','Elternabend',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (359,55,'grtyp','Kurs','Kurs',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (360,55,'grtyp','Therapie','Therapiegruppe',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (361,55,'grtyp','Seminar','Seminar',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (362,55,'grtyp','Selbster','Selbsterfahrung',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (363,55,'grtyp','Superv','Supervision',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (364,55,'grtyp','sonstige','sonstige',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (365,56,'gfall','1','Nein',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (366,56,'gfall','2','Ja',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (367,57,'wohnbez','01','Mitte',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (368,57,'wohnbez','02','Friedrichshain-Kreuzberg',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (369,57,'wohnbez','03','Pankow',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (370,57,'wohnbez','04','Charlottenburg-Wilmersdorf',4,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (371,57,'wohnbez','05','Spandau',5,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (372,57,'wohnbez','06','Steglitz-Zehlendorf',6,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (373,57,'wohnbez','07','Tempelhof-Sch�neberg',7,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (374,57,'wohnbez','08','Neuk�ln',8,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (375,57,'wohnbez','09','Treptow-K�penick',9,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (376,57,'wohnbez','10','Marzahn-Hellersdorf',10,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (377,57,'wohnbez','11','Lichtenberg',11,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (378,57,'wohnbez','12','Reinickendorf',12,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (379,57,'wohnbez','13','au�erhalb Berlins',13,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (380,57,'wohnbez','999','keine Angabe',14,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (381,58,'dbsite','A','DBSite A',1,1,1000000000,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (382,59,'lage','0','innerhalb des Geltungsbereichs des Stra�enkatalogs',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (383,59,'lage','1','au�erhalb des Geltungsbereichs des Stra�enkatalogs',2,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (384,59,'lage','999','keine Angabe',3,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (385,60,'config','protocol','off',1,NULL,NULL,0,NULL,NULL,NULL,1097425701);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (386,18,'stzei','B','Stelle B',2,NULL,NULL,0,NULL,NULL,'',1097425715);

--
-- Table structure for table 'dokument'
--

CREATE TABLE dokument (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  betr varchar(255) default NULL,
  fname varchar(255) default NULL,
  art int(11) default NULL,
  vd int(11) default NULL,
  vm int(11) default NULL,
  vy int(11) default NULL,
  mtyp int(11) default NULL,
  dok blob,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'dokument'
--



--
-- Table structure for table 'einrichtung'
--

CREATE TABLE einrichtung (
  id int(11) default NULL,
  akte_id int(11) default NULL,
  na char(80) default NULL,
  tl1 char(25) default NULL,
  tl2 char(25) default NULL,
  insta int(11) default NULL,
  no char(255) default NULL,
  nobed int(11) default NULL,
  status int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'einrichtung'
--


INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (2,2,'Einrichtungsname2','88441410','',184,'Notiz f�r Bezugsperson: 2',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (3,2,'Einrichtungsname3','983642','',180,'Notiz f�r Bezugsperson: 3',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (4,4,'Einrichtungsname4','12607477','',175,'Notiz f�r Bezugsperson: 4',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (5,4,'Einrichtungsname5','4264763','',174,'Notiz f�r Bezugsperson: 5',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (6,5,'Einrichtungsname6','21032580','',183,'Notiz f�r Bezugsperson: 6',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (7,5,'Einrichtungsname7','75679969','',183,'Notiz f�r Bezugsperson: 7',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (8,7,'Einrichtungsname8','53460619','',183,'Notiz f�r Bezugsperson: 8',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (9,7,'Einrichtungsname9','75435624','',177,'Notiz f�r Bezugsperson: 9',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (10,10,'Einrichtungsname10','79319879','',181,'Notiz f�r Bezugsperson: 10',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (11,10,'Einrichtungsname11','56856496','',185,'Notiz f�r Bezugsperson: 11',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (12,12,'Einrichtungsname12','47620092','',185,'Notiz f�r Bezugsperson: 12',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (13,12,'Einrichtungsname13','12055171','',178,'Notiz f�r Bezugsperson: 13',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (14,14,'Einrichtungsname14','77008367','',178,'Notiz f�r Bezugsperson: 14',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (15,16,'Einrichtungsname15','13520201','',174,'Notiz f�r Bezugsperson: 15',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (16,18,'Einrichtungsname16','65758174','',178,'Notiz f�r Bezugsperson: 16',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (17,19,'Einrichtungsname17','95069872','',184,'Notiz f�r Bezugsperson: 17',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (18,21,'Einrichtungsname18','6760094','',181,'Notiz f�r Bezugsperson: 18',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (19,21,'Einrichtungsname19','76353575','',183,'Notiz f�r Bezugsperson: 19',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (20,24,'Einrichtungsname20','10784334','',180,'Notiz f�r Bezugsperson: 20',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (21,25,'Einrichtungsname21','12502841','',178,'Notiz f�r Bezugsperson: 21',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (22,25,'Einrichtungsname22','53657469','',183,'Notiz f�r Bezugsperson: 22',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (23,26,'Einrichtungsname23','65823313','',184,'Notiz f�r Bezugsperson: 23',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (24,26,'Einrichtungsname24','42069093','',181,'Notiz f�r Bezugsperson: 24',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (25,27,'Einrichtungsname25','97431119','',185,'Notiz f�r Bezugsperson: 25',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (26,28,'Einrichtungsname26','85887097','',174,'Notiz f�r Bezugsperson: 26',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (27,29,'Einrichtungsname27','13325006','',181,'Notiz f�r Bezugsperson: 27',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (28,29,'Einrichtungsname28','15826655','',181,'Notiz f�r Bezugsperson: 28',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (29,30,'Einrichtungsname29','2302651','',175,'Notiz f�r Bezugsperson: 29',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (30,30,'Einrichtungsname30','7344750','',177,'Notiz f�r Bezugsperson: 30',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (31,31,'Einrichtungsname31','68476641','',184,'Notiz f�r Bezugsperson: 31',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (32,31,'Einrichtungsname32','34146407','',181,'Notiz f�r Bezugsperson: 32',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (33,32,'Einrichtungsname33','94389906','',184,'Notiz f�r Bezugsperson: 33',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (34,32,'Einrichtungsname34','10286155','',176,'Notiz f�r Bezugsperson: 34',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (35,33,'Einrichtungsname35','44209102','',181,'Notiz f�r Bezugsperson: 35',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (36,34,'Einrichtungsname36','13245092','',175,'Notiz f�r Bezugsperson: 36',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (37,34,'Einrichtungsname37','18921346','',177,'Notiz f�r Bezugsperson: 37',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (38,35,'Einrichtungsname38','75205470','',174,'Notiz f�r Bezugsperson: 38',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (39,36,'Einrichtungsname39','99338171','',181,'Notiz f�r Bezugsperson: 39',213,216);

--
-- Table structure for table 'exportprotokoll'
--

CREATE TABLE exportprotokoll (
  id int(11) default NULL,
  mit_id int(11) default NULL,
  zeit int(11) default NULL,
  dbsite int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'exportprotokoll'
--



--
-- Table structure for table 'fachstat'
--

CREATE TABLE fachstat (
  id int(11) default NULL,
  mit_id int(11) default NULL,
  fall_id int(11) default NULL,
  fall_fn char(20) default NULL,
  jahr int(11) default NULL,
  stz int(11) default NULL,
  bz char(4) default NULL,
  gs int(11) default NULL,
  ag int(11) default NULL,
  fs int(11) default NULL,
  zm int(11) default NULL,
  qualij int(11) default NULL,
  hkm int(11) default NULL,
  hkv int(11) default NULL,
  bkm int(11) default NULL,
  bkv int(11) default NULL,
  qualikm int(11) default NULL,
  qualikv int(11) default NULL,
  agkm int(11) default NULL,
  agkv int(11) default NULL,
  ba1 int(11) default NULL,
  ba2 int(11) default NULL,
  pbe int(11) default NULL,
  pbk int(11) default NULL,
  kat int(11) default NULL,
  kkm int(11) default NULL,
  kkv int(11) default NULL,
  kki int(11) default NULL,
  kpa int(11) default NULL,
  kfa int(11) default NULL,
  ksoz int(11) default NULL,
  kleh int(11) default NULL,
  kerz int(11) default NULL,
  kkonf int(11) default NULL,
  kson int(11) default NULL,
  no char(255) default NULL,
  no2 char(255) default NULL,
  no3 char(255) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstat'
--


INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (2,5,2,'1-2003B',2003,386,'0061',7,13,28,45,191,97,96,83,80,196,201,18,20,63,75,109,113,36,3,0,1,7,1,6,6,7,2,3,'','','',1097425722);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (3,6,4,'2-2003B',2003,386,'0061',7,15,38,44,192,95,89,84,80,199,199,24,20,68,62,107,118,50,9,4,6,9,6,6,5,1,0,4,'','','',1097425731);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (4,6,5,'3-2003B',2003,386,'0061',6,14,27,52,192,95,92,86,82,200,196,23,22,58,67,103,112,39,5,1,9,8,6,5,2,1,0,2,'','','',1097425739);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (5,6,6,'1-2004B',2004,386,'0060',6,10,29,46,188,97,90,82,79,197,195,19,18,75,68,104,129,39,5,8,4,0,3,4,2,4,4,5,'','','',1097425748);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (6,5,7,'1-2002B',2002,386,'0063',6,16,31,48,187,97,98,79,84,200,200,23,18,56,62,108,117,31,1,9,0,0,7,2,2,1,6,3,'','','',1097425755);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (7,6,8,'2-2004A',2004,205,'0061',6,9,27,48,190,98,91,80,87,198,198,18,19,60,75,102,122,28,4,1,0,0,5,3,4,2,1,8,'','','',1097425764);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (8,7,9,'4-2003B',2003,386,'0063',7,12,35,46,191,97,95,85,83,195,200,18,20,72,60,101,121,38,6,1,3,4,7,0,3,3,2,9,'','','',1097425770);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (9,6,10,'2-2004B',2004,386,'0062',6,10,33,48,191,95,98,80,80,196,200,19,22,57,58,107,127,50,3,1,0,5,9,9,4,4,7,8,'','','',1097425777);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (10,6,11,'3-2004A',2004,205,'0060',7,15,36,42,189,96,89,83,87,195,200,20,22,56,64,108,121,55,9,5,6,5,6,8,4,8,0,4,'','','',1097425786);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (11,7,12,'3-2004B',2004,386,'0062',7,13,34,52,188,92,98,85,82,201,195,20,24,67,55,108,113,37,7,0,0,7,6,6,0,2,5,4,'','','',1097425792);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (12,5,13,'4-2004A',2004,205,'0063',7,14,32,44,188,91,92,78,85,195,200,22,18,56,76,104,129,37,0,3,2,2,7,7,9,3,0,4,'','','',1097425801);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (13,5,14,'1-2003A',2003,205,'0060',6,10,31,48,187,89,90,84,86,197,198,19,24,61,56,106,123,30,6,1,1,0,0,6,4,1,5,6,'','','',1097425807);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (14,6,15,'5-2003B',2003,386,'0063',7,10,26,41,191,96,93,80,82,200,195,22,19,62,55,106,118,50,4,2,3,9,7,9,6,2,4,4,'','','',1097425812);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (15,6,17,'2-2003A',2003,205,'0062',6,10,34,44,190,94,99,79,81,195,196,21,21,54,74,108,121,37,7,2,1,6,1,7,2,0,6,5,'','','',1097425822);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (16,7,18,'1-2002A',2002,205,'0060',6,14,34,46,190,98,93,83,78,198,198,19,19,54,56,102,122,37,1,3,4,6,2,0,5,6,1,9,'','','',1097425832);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (17,6,19,'6-2003B',2003,386,'0062',7,13,38,45,188,92,89,78,84,200,200,19,24,72,61,109,120,53,8,4,7,6,9,2,4,7,5,1,'','','',1097425841);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (18,5,20,'3-2003A',2003,205,'0062',6,9,36,46,189,96,96,85,84,201,198,22,18,76,63,103,129,53,5,1,7,8,4,6,3,6,5,8,'','','',1097425850);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (19,7,21,'6-2004A',2004,205,'0062',6,12,36,44,188,89,89,81,79,201,196,19,21,75,57,110,125,33,5,1,2,1,7,4,7,0,1,5,'','','',1097425859);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (20,7,22,'7-2003B',2003,386,'0061',7,10,29,42,189,99,98,84,87,199,195,19,23,63,69,110,116,57,3,4,8,6,6,8,3,9,2,8,'','','',1097425865);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (21,7,23,'2-2002B',2002,386,'0062',6,11,34,51,191,92,93,81,87,200,199,20,22,69,70,110,120,61,4,7,1,6,9,3,5,9,9,8,'','','',1097425872);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (22,6,24,'4-2003A',2003,205,'0061',7,16,30,47,187,97,94,81,80,196,195,18,20,70,65,103,120,46,3,9,4,4,6,8,1,3,6,2,'','','',1097425878);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (23,5,25,'7-2004A',2004,205,'0063',7,10,27,49,190,94,98,85,85,198,195,19,21,60,57,108,116,56,7,7,3,2,5,6,7,4,6,9,'','','',1097425885);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (24,6,26,'8-2003B',2003,386,'0061',6,12,31,45,191,92,90,78,82,200,198,22,23,56,57,104,128,50,6,0,8,2,8,5,7,2,7,5,'','','',1097425894);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (25,7,27,'9-2003B',2003,386,'0060',6,12,30,46,189,93,92,79,86,200,196,23,19,66,60,102,117,62,6,9,5,2,8,7,2,9,7,7,'','','',1097425906);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (26,5,28,'4-2004B',2004,386,'0063',7,13,36,49,187,92,97,80,83,195,200,18,23,58,60,108,113,45,3,4,2,5,2,8,7,5,2,7,'','','',1097425921);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (27,5,29,'10-2003B',2003,386,'0061',6,8,33,52,193,93,99,82,86,201,196,21,20,69,66,104,125,40,4,2,7,2,0,1,9,7,7,1,'','','',1097425929);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (28,6,30,'11-2003B',2003,386,'0061',7,13,38,41,189,97,90,78,78,195,200,22,18,64,70,108,124,29,9,2,0,0,2,5,0,9,0,2,'','','',1097425936);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (29,6,31,'5-2003A',2003,205,'0060',6,8,36,42,188,89,89,86,78,195,195,19,21,60,61,110,118,45,2,9,2,9,2,9,6,3,2,1,'','','',1097425944);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (30,7,32,'12-2003B',2003,386,'0061',7,10,36,51,193,96,95,80,85,198,196,22,18,75,76,105,114,53,5,9,2,9,6,9,6,4,3,0,'','','',1097425954);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (31,6,33,'8-2004A',2004,205,'0060',7,11,32,47,191,95,94,85,79,201,198,21,19,57,67,105,128,52,7,3,2,0,9,9,7,2,8,5,'','','',1097425962);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (32,7,34,'6-2003A',2003,205,'0063',7,14,28,42,192,95,89,84,79,200,197,21,24,67,64,102,122,56,2,5,7,6,3,8,9,0,9,7,'','','',1097425971);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (33,6,35,'5-2004B',2004,386,'0063',6,9,36,49,187,96,90,87,79,201,201,19,20,67,66,106,129,29,2,0,6,3,5,3,2,1,3,4,'','','',1097425977);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (34,5,36,'13-2003B',2003,386,'0061',6,14,31,49,189,99,99,83,78,196,200,21,20,66,71,101,118,42,3,0,5,1,8,4,9,7,4,1,'','','',1097425985);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (35,5,37,'6-2004B',2004,386,'0060',6,10,36,45,193,91,96,82,86,200,197,21,22,65,73,104,117,39,8,2,2,0,6,0,3,4,9,5,'','','',1097425993);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (36,5,39,'10-2004A',2004,205,'0061',7,9,36,44,188,94,89,78,82,196,199,20,24,65,63,103,127,35,4,2,2,4,5,0,3,3,6,6,'','','',1097426002);

--
-- Table structure for table 'fachstatelternproblem'
--

CREATE TABLE fachstatelternproblem (
  id int(11) default NULL,
  fstat_id int(11) default NULL,
  pbe int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstatelternproblem'
--


INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (2,2,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (3,3,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (4,3,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (5,3,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (6,4,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (7,4,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (8,5,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (9,5,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (10,6,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (11,6,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (12,6,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (13,6,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (14,7,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (15,7,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (16,7,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (17,7,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (18,8,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (19,8,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (20,9,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (21,10,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (22,10,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (23,10,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (24,11,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (25,12,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (26,12,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (27,12,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (28,13,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (29,13,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (30,14,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (31,15,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (32,15,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (33,16,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (34,17,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (35,17,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (36,17,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (37,18,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (38,18,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (39,18,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (40,18,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (41,19,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (42,20,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (43,21,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (44,22,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (45,22,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (46,22,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (47,23,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (48,24,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (49,24,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (50,24,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (51,24,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (52,25,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (53,25,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (54,25,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (55,25,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (56,26,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (57,27,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (58,28,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (59,28,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (60,28,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (61,29,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (62,29,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (63,29,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (64,30,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (65,30,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (66,30,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (67,30,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (68,31,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (69,31,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (70,31,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (71,31,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (72,32,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (73,32,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (74,32,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (75,33,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (76,33,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (77,34,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (78,34,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (79,34,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (80,34,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (81,35,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (82,35,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (83,36,111);

--
-- Table structure for table 'fachstatkindproblem'
--

CREATE TABLE fachstatkindproblem (
  id int(11) default NULL,
  fstat_id int(11) default NULL,
  pbk int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstatkindproblem'
--


INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (2,2,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (3,2,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (4,2,112);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (5,3,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (6,3,123);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (7,4,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (8,5,130);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (9,5,120);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (10,5,123);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (11,5,128);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (12,6,128);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (13,7,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (14,7,113);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (15,7,120);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (16,7,128);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (17,8,115);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (18,8,125);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (19,9,122);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (20,9,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (21,10,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (22,11,130);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (23,11,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (24,12,121);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (25,12,123);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (26,12,118);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (27,12,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (28,13,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (29,14,121);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (30,15,120);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (31,15,121);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (32,16,115);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (33,16,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (34,17,128);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (35,17,122);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (36,17,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (37,18,121);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (38,18,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (39,18,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (40,19,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (41,20,124);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (42,20,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (43,21,122);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (44,21,120);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (45,21,124);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (46,21,113);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (47,22,117);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (48,22,125);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (49,23,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (50,24,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (51,24,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (52,24,120);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (53,25,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (54,26,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (55,26,130);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (56,26,122);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (57,27,115);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (58,27,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (59,27,124);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (60,27,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (61,28,124);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (62,28,118);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (63,28,128);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (64,28,120);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (65,29,124);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (66,30,128);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (67,30,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (68,30,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (69,30,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (70,31,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (71,31,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (72,32,117);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (73,33,113);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (74,34,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (75,35,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (76,36,118);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (77,36,115);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (78,36,127);

--
-- Table structure for table 'fachstatlei'
--

CREATE TABLE fachstatlei (
  id int(11) default NULL,
  fstat_id int(11) default NULL,
  le int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstatlei'
--


INSERT INTO fachstatlei (id, fstat_id, le) VALUES (2,2,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (3,2,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (4,2,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (5,2,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (6,3,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (7,3,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (8,4,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (9,4,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (10,4,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (11,4,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (12,4,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (13,5,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (14,5,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (15,5,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (16,6,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (17,7,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (18,7,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (19,7,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (20,7,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (21,7,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (22,7,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (23,7,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (24,7,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (25,7,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (26,7,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (27,8,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (28,8,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (29,8,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (30,8,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (31,8,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (32,8,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (33,8,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (34,8,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (35,9,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (36,9,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (37,9,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (38,10,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (39,10,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (40,10,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (41,10,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (42,10,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (43,10,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (44,10,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (45,10,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (46,10,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (47,11,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (48,11,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (49,11,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (50,11,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (51,12,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (52,12,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (53,12,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (54,12,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (55,12,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (56,12,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (57,12,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (58,12,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (59,13,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (60,14,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (61,14,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (62,15,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (63,15,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (64,15,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (65,16,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (66,16,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (67,16,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (68,16,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (69,16,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (70,16,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (71,16,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (72,16,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (73,16,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (74,16,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (75,17,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (76,17,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (77,17,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (78,17,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (79,17,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (80,17,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (81,17,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (82,17,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (83,18,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (84,18,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (85,18,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (86,19,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (87,19,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (88,20,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (89,20,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (90,21,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (91,22,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (92,23,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (93,23,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (94,23,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (95,24,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (96,24,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (97,24,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (98,24,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (99,24,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (100,24,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (101,25,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (102,25,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (103,25,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (104,25,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (105,25,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (106,25,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (107,25,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (108,26,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (109,26,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (110,26,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (111,26,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (112,26,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (113,26,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (114,26,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (115,26,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (116,27,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (117,27,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (118,27,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (119,27,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (120,27,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (121,28,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (122,28,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (123,28,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (124,28,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (125,28,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (126,28,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (127,28,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (128,28,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (129,28,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (130,29,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (131,29,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (132,29,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (133,30,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (134,30,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (135,31,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (136,31,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (137,31,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (138,32,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (139,32,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (140,32,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (141,32,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (142,33,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (143,33,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (144,33,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (145,33,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (146,33,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (147,33,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (148,33,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (149,33,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (150,33,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (151,33,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (152,34,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (153,34,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (154,34,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (155,34,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (156,34,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (157,34,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (158,34,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (159,34,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (160,34,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (161,34,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (162,35,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (163,35,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (164,35,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (165,35,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (166,35,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (167,35,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (168,35,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (169,35,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (170,36,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (171,36,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (172,36,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (173,36,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (174,36,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (175,36,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (176,36,136);

--
-- Table structure for table 'fall'
--

CREATE TABLE fall (
  id int(11) default NULL,
  akte_id int(11) default NULL,
  fn char(30) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  zdad int(11) default NULL,
  zdam int(11) default NULL,
  zday int(11) default NULL,
  status int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fall'
--


INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (2,2,'1-2003B',28,7,2003,15,5,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (3,2,'1-2004A',25,7,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (4,3,'2-2003B',16,11,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (5,4,'3-2003B',2,2,2003,25,4,2003,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (6,5,'1-2004B',1,5,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (7,6,'1-2002B',12,12,2002,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (8,7,'2-2004A',2,7,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (9,8,'4-2003B',8,6,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (10,9,'2-2004B',2,6,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (11,10,'3-2004A',27,8,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (12,11,'3-2004B',15,6,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (13,12,'4-2004A',19,6,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (14,13,'1-2003A',17,1,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (15,14,'5-2003B',18,1,2003,16,8,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (16,14,'5-2004A',18,9,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (17,15,'2-2003A',27,4,2003,2,8,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (18,16,'1-2002A',4,12,2002,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (19,17,'6-2003B',10,7,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (20,18,'3-2003A',10,9,2003,22,8,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (21,19,'6-2004A',24,1,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (22,20,'7-2003B',27,7,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (23,21,'2-2002B',21,11,2002,6,9,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (24,22,'4-2003A',25,7,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (25,23,'7-2004A',23,3,2004,10,5,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (26,24,'8-2003B',20,1,2003,3,9,2003,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (27,25,'9-2003B',13,5,2003,17,4,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (28,26,'4-2004B',27,4,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (29,27,'10-2003B',6,11,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (30,28,'11-2003B',18,10,2003,20,2,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (31,29,'5-2003A',15,2,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (32,30,'12-2003B',8,9,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (33,31,'8-2004A',1,5,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (34,32,'6-2003A',21,12,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (35,33,'5-2004B',26,6,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (36,34,'13-2003B',9,6,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (37,35,'6-2004B',26,1,2004,28,2,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (38,35,'9-2004A',12,8,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (39,36,'10-2004A',4,10,2004,0,0,0,210);

--
-- Table structure for table 'fallgruppe'
--

CREATE TABLE fallgruppe (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  gruppe_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fallgruppe'
--



--
-- Table structure for table 'feld'
--

CREATE TABLE feld (
  id int(11) default NULL,
  tab_id int(11) default NULL,
  feld char(30) default NULL,
  name char(60) default NULL,
  inverse char(60) default NULL,
  typ char(20) default NULL,
  laenge int(11) default NULL,
  notnull int(11) default NULL,
  verwtyp int(11) default NULL,
  ftab_id int(11) default NULL,
  kat_id int(11) default NULL,
  kat_code char(8) default NULL,
  flag int(11) default NULL,
  dok char(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'feld'
--


INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (1,1,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (2,1,'vn','Vorname',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (3,1,'na','Name',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (4,1,'ben','Benutzer',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (5,1,'anr','Anrede',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (6,1,'tl1','Diensttelefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (7,1,'fax','Fax',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (8,1,'mail','Mail',NULL,'CHAR(50)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (9,1,'stat','Status',NULL,'INT',NULL,NULL,3,24,17,'status',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (10,1,'benr','Benutzungsrecht',NULL,'INT',NULL,NULL,3,24,19,'benr',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (11,1,'stz','Hauptdienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (12,1,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (13,1,'pass','Passwort',NULL,'CHAR(50)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (14,2,'nr','nr',NULL,'INT(11)',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (15,2,'zeit','zeit',NULL,'VARCHAR(17)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (16,2,'artdeszugriffs','artdeszugriffs',NULL,'longtext',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (17,2,'benutzerkennung','benutzerkennung',NULL,'VARCHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (18,2,'ipadresse','ipadresse',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (19,3,'str_nummer','Str_nummer',NULL,'CHAR(5)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (20,3,'str_name','Str_name',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (21,3,'hausnr','Hausnr',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (22,3,'bezirk','Bezirk',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (23,3,'plz','Plz',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (24,3,'Plraum','Planungsraum',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (25,4,'session_id','SessionID',NULL,'CHAR(50)',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (26,4,'time','Time',NULL,'CHAR(16)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (27,4,'user_name','UserName',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (28,5,'mit_id','Mitarbeiterid','neben_stz','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (29,5,'stz','Nebendienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (30,6,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (31,6,'vn','Vorname',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (32,6,'na','Name',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (33,6,'gb','Geburtsdatum',NULL,'CHAR(10)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (34,6,'ber','Ausbildung',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (35,6,'str','Strasse',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (36,6,'hsnr','Hausnummer',NULL,'CHAR(5)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (37,6,'plz','Postleitzahl',NULL,'CHAR(9)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (38,6,'planungsr','Planungsraum',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (39,6,'wohnbez','Wohnbezirk',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (40,6,'lage','inBerlin',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (41,6,'ort','Ort',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (42,6,'tl1','Telefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (43,6,'tl2','Diensttelefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (44,6,'fs','Familienstatus (lebt bei)',NULL,'INT',NULL,NULL,3,24,4,'fsfs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (45,6,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (46,6,'stzbg','Aufnahmedienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (47,6,'stzak','Aktuelle Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (48,6,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (49,7,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (50,7,'akte_id','Aktenid','faelle','INT',NULL,NULL,2,6,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (51,7,'fn','Fallnummer',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (52,7,'bgd','Beginn Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (53,7,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (54,7,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (55,7,'zdad','Abschluss Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (56,7,'zdam','Abschluss Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (57,7,'zday','Abschluss Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (58,7,'status','Fallstand',NULL,'INT',NULL,NULL,3,24,20,'stand',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (59,8,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (60,8,'fall_id','Fall_id','anmeldung','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (61,8,'von','angemeldet von',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (62,8,'ad','Anmeldetag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (63,8,'am','Anmeldemonat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (64,8,'ay','Anmeldejahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (65,8,'mtl','Telefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (66,8,'me','auf Empfehlung von',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (67,8,'zm','Zugangsart',NULL,'INT',NULL,NULL,3,24,5,'fszm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (68,8,'mg','Anmeldegrund',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (69,8,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (70,9,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (71,9,'akte_id','Aktenid','bezugspersonen','INT',NULL,NULL,2,6,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (72,9,'vn','Vorname',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (73,9,'na','Name',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (74,9,'gb','Geburtsdatum',NULL,'CHAR(10)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (75,9,'ber','Beruf',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (76,9,'str','Strasse',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (77,9,'hsnr','Hausnummer',NULL,'CHAR(5)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (78,9,'lage','inBerlin',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (79,9,'plz','Postleitzahl',NULL,'CHAR(9)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (80,9,'ort','Ort',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (81,9,'tl1','Telefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (82,9,'tl2','Diensttelefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (83,9,'fs','Familienstatus (lebt bei)',NULL,'INT',NULL,NULL,3,24,4,'fsfs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (84,9,'verw','Verwandschaftsgrad',NULL,'INT',NULL,NULL,3,24,15,'klerv',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (85,9,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (86,9,'nobed','Notizbedeutung',NULL,'INT',NULL,NULL,3,24,21,'notizbed',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (87,9,'vrt','im Verteiler',NULL,'INT',NULL,NULL,3,24,22,'vert',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (88,10,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (89,10,'akte_id','Aktenid','einrichtungen','INT',NULL,NULL,2,6,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (90,10,'na','Name',NULL,'CHAR(80)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (91,10,'tl1','Telefon1',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (92,10,'tl2','Telefon2',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (93,10,'insta','Einrichtungsart',NULL,'INT',NULL,NULL,3,24,16,'klinsta',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (94,10,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (95,10,'nobed','Notizbedeutung',NULL,'INT',NULL,NULL,3,24,21,'notizbed',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (96,10,'status','Aktueller Kontakt',NULL,'INT',NULL,NULL,3,24,23,'einrstat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (97,11,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (98,11,'fall_id','Fallid','leistungen','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (99,11,'mit_id','Mitarbeiterid','leistungen','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (100,11,'le','Leistungsart',NULL,'INT',NULL,NULL,3,24,11,'fsle',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (101,11,'bgd','Beginn Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (102,11,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (103,11,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (104,11,'ed','Ende Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (105,11,'em','Ende Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (106,11,'ey','Ende Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (107,11,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (108,12,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (109,12,'fall_id','Fallid','zustaendigkeiten','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (110,12,'mit_id','Mitarbeiterid','zustaendigkeiten','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (111,12,'bgd','Beginn Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (112,12,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (113,12,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (114,12,'ed','Ende Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (115,12,'em','Ende Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (116,12,'ey','Ende Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (117,13,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (118,13,'fall_id','Fallid','dokumente','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (119,13,'mit_id','Mitarbeiterid','dokumente','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (120,13,'betr','Betrifft',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (121,13,'fname','Dateiname',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (122,13,'art','Text ist',NULL,'INT',NULL,NULL,3,24,53,'dokart',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (123,13,'vd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (124,13,'vm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (125,13,'vy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (126,13,'mtyp','Mime Typ',NULL,'INT',NULL,NULL,3,24,52,'mimetyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (127,13,'dok','Dokument',NULL,'BLOB',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (128,13,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (129,14,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (130,14,'gruppe_id','Gruppeid','gruppendokumente','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (131,14,'mit_id','Mitarbeiterid','gruppendokumente','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (132,14,'betr','Betrifft',NULL,'CHAR(254)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (133,14,'fname','Dateiname',NULL,'CHAR(254)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (134,14,'art','Text ist',NULL,'INT',NULL,NULL,3,24,53,'dokart',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (135,14,'vd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (136,14,'vm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (137,14,'vy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (138,14,'mtyp','Mime Typ',NULL,'INT',NULL,NULL,3,24,52,'mimetyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (139,14,'dok','Dokument',NULL,'BLOB',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (140,14,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (141,15,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (142,15,'gn','Gruppennummer',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (143,15,'name','Name',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (144,15,'thema','Thema',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (145,15,'tzahl','Anzahl der Termine',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (146,15,'stzahl','Anzahl der Stunden',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (147,15,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (148,15,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (149,15,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (150,15,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (151,15,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (152,15,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (153,15,'teiln','Teilnehmer',NULL,'INT',NULL,NULL,3,24,54,'teiln',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (154,15,'grtyp','Gruppentyp',NULL,'INT',NULL,NULL,3,24,55,'grtyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (155,15,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (156,15,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (157,16,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (158,16,'fall_id','Fallid','gruppen','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (159,16,'gruppe_id','Gruppeid','faelle','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (160,16,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (161,16,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (162,16,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (163,16,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (164,16,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (165,16,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (166,16,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (167,17,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (168,17,'bezugsp_id','Bezugspersonid','gruppen','INT',NULL,NULL,2,9,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (169,17,'gruppe_id','Gruppeid','bezugspersonen','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (170,17,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (171,17,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (172,17,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (173,17,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (174,17,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (175,17,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (176,17,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (177,18,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (178,18,'mit_id','Mitarbeiterid','gruppen','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (179,18,'gruppe_id','Gruppeid','mitarbeiter','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (180,18,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (181,18,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (182,18,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (183,18,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (184,18,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (185,18,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (186,18,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (187,19,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (188,19,'mit_id','Mitarbeiterid','fachstatistiken','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (189,19,'fall_id','Fallid','fachstatistiken','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (190,19,'fall_fn','Fallnummer',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (191,19,'jahr','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (192,19,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (193,19,'bz','Region',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (194,19,'gs','Geschlecht',NULL,'INT',NULL,NULL,3,24,30,'gs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (195,19,'ag','Altersgruppe Kind',NULL,'INT',NULL,NULL,3,24,2,'fsag',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (196,19,'fs','Familienstatus (lebt bei)',NULL,'INT',NULL,NULL,3,24,4,'fsfs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (197,19,'zm','Zugangsart',NULL,'INT',NULL,NULL,3,24,5,'fszm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (198,19,'qualij','Qualifikation des/r Jugendlicher/n',NULL,'INT',NULL,NULL,3,24,13,'fsqualij',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (199,19,'hkm','Herkunft der Mutter',NULL,'INT',NULL,NULL,3,24,8,'fshe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (200,19,'hkv','Herkunft des Vaters',NULL,'INT',NULL,NULL,3,24,8,'fshe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (201,19,'bkm','Beruf der Mutter',NULL,'INT',NULL,NULL,3,24,7,'fsbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (202,19,'bkv','Beruf des Vaters',NULL,'INT',NULL,NULL,3,24,7,'fsbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (203,19,'qualikm','Qualifikation der Mutter',NULL,'INT',NULL,NULL,3,24,14,'fsquali',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (204,19,'qualikv','Qualifikation des Vater',NULL,'INT',NULL,NULL,3,24,14,'fsquali',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (205,19,'agkm','Altersgruppe der Mutter',NULL,'INT',NULL,NULL,3,24,3,'fsagel',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (206,19,'agkv','Altersgruppe des Vaters',NULL,'INT',NULL,NULL,3,24,3,'fsagel',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (207,19,'ba1','Vorstellungsanlass 1 bei der Anmeldung',NULL,'INT',NULL,NULL,3,24,6,'fsba',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (208,19,'ba2','Vorstellungsanlass 2 bei der Anmeldung',NULL,'INT',NULL,NULL,3,24,6,'fsba',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (209,19,'pbe','Hauptproblematik Eltern',NULL,'INT',NULL,NULL,3,24,9,'fspbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (210,19,'pbk','Hauptproblematik Kind/Jugendliche',NULL,'INT',NULL,NULL,3,24,10,'fspbk',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (211,19,'kat','Summe der Konsultationen insgesamt (a 50 Min.)',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (212,19,'kkm','Anzahl der Konsultationen Mutter',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (213,19,'kkv','Anzahl der Konsultationen Vater',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (214,19,'kki','Anzahl der Konsultationen Kind / Jugendlicher',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (215,19,'kpa','Anzahl der Konsultationen Paar',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (216,19,'kfa','Anzahl der Konsultationen Familie',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (217,19,'ksoz','Anzahl der Konsultationen Sozialarbeiter',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (218,19,'kleh','Anzahl der Konsultationen Lehrer',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (219,19,'kerz','Anzahl der Konsultationen Erzieher',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (220,19,'kkonf','Anzahl der Konsultationen Hilfebesprechung',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (221,19,'kson','Kontaktanzahl Sonstige',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (222,19,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (223,19,'no2','anders geartete Problemlagen Kind',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (224,19,'no3','anders geartete Problemlagen Eltern',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (225,19,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (226,20,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (227,20,'fstat_id','Fachstatistikid','leistungen','INT',NULL,NULL,2,19,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (228,20,'le','Leistungsart',NULL,'INT',NULL,NULL,3,24,11,'fsle',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (229,21,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (230,21,'fstat_id','Fachstatistikid','fachstatkindprobleme','INT',NULL,NULL,2,19,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (231,21,'pbk','Problemspektrum Kind',NULL,'INT',NULL,NULL,3,24,10,'fspbk',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (232,22,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (233,22,'fstat_id','Fachstatistikid','fachstatelternprobleme','INT',NULL,NULL,2,19,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (234,22,'pbe','Problemspektrum Eltern',NULL,'INT',NULL,NULL,3,24,9,'fspbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (235,23,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (236,23,'fall_id','Fallid','jgh_statistiken','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (237,23,'mit_id','Mitarbeiterid','jgh_statistiken','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (238,23,'fall_fn','Fallnummer',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (239,23,'gfall','Geschwisterfall',NULL,'INT',NULL,NULL,3,24,56,'gfall',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (240,23,'bezirksnr','Wohnbezirksnummer des Klienten',NULL,'INT',NULL,NULL,3,24,57,'wohnbez',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (241,23,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (242,23,'rbz','Regierungsbezirk',NULL,'INT',NULL,NULL,3,24,24,'rbz',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (243,23,'kr','Kreis',NULL,'INT',NULL,NULL,3,24,25,'kr',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (244,23,'gm','Gemeinde',NULL,'INT',NULL,NULL,3,24,26,'gm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (245,23,'gmt','Gemeindeteil',NULL,'INT',NULL,NULL,3,24,27,'gmt',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (246,23,'lnr','laufendeNummer',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (247,23,'traeg','Tr�ger',NULL,'INT',NULL,NULL,3,24,28,'traeg',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (248,23,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (249,23,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (250,23,'em','Ende Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (251,23,'ey','Ende Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (252,23,'bgr','Beendigungsgrund',NULL,'INT',NULL,NULL,3,24,29,'bgr',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (253,23,'gs','Geschlecht',NULL,'INT',NULL,NULL,3,24,30,'gs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (254,23,'ag','Altersgruppe',NULL,'INT',NULL,NULL,3,24,31,'ag',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (255,23,'fs','lebt bei',NULL,'INT',NULL,NULL,3,24,32,'fs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (256,23,'hke','Herkunft Eltern',NULL,'INT',NULL,NULL,3,24,33,'hke',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (257,23,'gsa','Geschwisterzahl',NULL,'INT',NULL,NULL,4,NULL,35,'gsa',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (258,23,'gsu','Geschwisterzahl unbekannt',NULL,'INT',NULL,NULL,3,24,36,'gsu',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (259,23,'zm','Kontaktaufnahme',NULL,'INT',NULL,NULL,3,24,34,'zm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (260,23,'ba0','Beratungsanlass 0',NULL,'INT',NULL,NULL,3,24,37,'ba0',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (261,23,'ba1','Beratungsanlass 1',NULL,'INT',NULL,NULL,3,24,38,'ba1',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (262,23,'ba2','Beratungsanlass 2',NULL,'INT',NULL,NULL,3,24,39,'ba2',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (263,23,'ba3','Beratungsanlass 3',NULL,'INT',NULL,NULL,3,24,40,'ba3',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (264,23,'ba4','Beratungsanlass 4',NULL,'INT',NULL,NULL,3,24,41,'ba4',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (265,23,'ba5','Beratungsanlass 5',NULL,'INT',NULL,NULL,3,24,42,'ba5',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (266,23,'ba6','Beratungsanlass 6',NULL,'INT',NULL,NULL,3,24,43,'ba6',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (267,23,'ba7','Beratungsanlass 7',NULL,'INT',NULL,NULL,3,24,44,'ba7',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (268,23,'ba8','Beratungsanlass 8',NULL,'INT',NULL,NULL,3,24,45,'ba8',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (269,23,'ba9','Beratungsanlass 9',NULL,'INT',NULL,NULL,3,24,46,'ba9',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (270,23,'schw','Beratungsschwerpunkt',NULL,'INT',NULL,NULL,3,24,47,'schw',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (271,23,'fbe0','Beratung Kind',NULL,'INT',NULL,NULL,3,24,48,'fbe0',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (272,23,'fbe1','Beratung Eltern',NULL,'INT',NULL,NULL,3,24,49,'fbe1',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (273,23,'fbe2','Beratung Familie',NULL,'INT',NULL,NULL,3,24,50,'fbe2',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (274,23,'fbe3','Beratung Umfeld',NULL,'INT',NULL,NULL,3,24,51,'fbe3',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (275,23,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (276,24,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (277,24,'kat_id','Kategorienid','codes','INT',NULL,NULL,2,25,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (278,24,'kat_code','Kategoriencode',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (279,24,'code','Code',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (280,24,'name','Name',NULL,'CHAR(160)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (281,24,'sort','Sortierreihenfolge',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (282,24,'mini','Bereichsminimum',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (283,24,'maxi','Bereichsmaximum',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (284,24,'off','Ung�ltig',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (285,24,'dm','Ung�ltig ab Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (286,24,'dy','Ung�ltig ab Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (287,24,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (288,24,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (289,25,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (290,25,'code','Code',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (291,25,'name','Name',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (292,25,'kat_id','Kategorienart','kategorien','INT',NULL,NULL,2,25,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (293,25,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (294,25,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (295,26,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (296,26,'mit_id','Mitarbeiterid','','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (297,26,'zeit','Exportzeitpunkt',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (298,26,'dbsite','Datenbanksite',NULL,'INT',NULL,NULL,3,24,58,'dbsite',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (299,27,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (300,27,'exp_id','Exportprotokollid','importprotokolle','INT',NULL,NULL,2,26,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (301,27,'mit_id','Mitarbeiterid','','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (302,27,'zeit','Importzeitpunkt',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (303,27,'dbsite','Datenbanksite',NULL,'INT',NULL,NULL,3,24,58,'dbsite',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (304,28,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (305,28,'tab_id','Tabelle','felder','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (306,28,'feld','Feldname',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (307,28,'name','Langname des Feldes',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (308,28,'inverse','Name f�r inverse Beziehung',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (309,28,'typ','Datenbanktyp',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (310,28,'laenge','Feldl�nge',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (311,28,'notnull','Nicht NULL',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (312,28,'verwtyp','Verwendungstyp',NULL,'INT',NULL,NULL,3,24,1,'verwtyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (313,28,'ftab_id','Fremdtabelle','inverse','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (314,28,'kat_id','Kategorienid','','INT',NULL,NULL,2,25,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (315,28,'kat_code','Kategoriencode',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (316,28,'flag','Flags',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (317,28,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (318,29,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (319,29,'tabelle','Tabellenname',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (320,29,'name','Langname der Tabelle',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (321,29,'klasse','Klassenname',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (322,29,'flag','Flags',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (323,29,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (324,30,'table_id','Tabellenid','iddaten','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (325,30,'table_name','Tabellenname',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (326,30,'dbsite','Datenbanksite',NULL,'INT',NULL,NULL,3,24,58,'dbsite',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (327,30,'minid','Minimale ID',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (328,30,'maxid','Maximale ID',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (329,30,'maxist','Maximale verwendete ID',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (330,31,'tab_id','Tabelle','schluessel','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (331,31,'feld_id','Feld','schluessel','INT',NULL,NULL,2,28,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (332,31,'seq','Laufende Nummer',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);

--
-- Table structure for table 'gruppe'
--

CREATE TABLE gruppe (
  id int(11) default NULL,
  gn char(20) default NULL,
  name char(255) default NULL,
  thema char(255) default NULL,
  tzahl int(11) default NULL,
  stzahl int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  teiln int(11) default NULL,
  grtyp int(11) default NULL,
  stz int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'gruppe'
--



--
-- Table structure for table 'gruppendokument'
--

CREATE TABLE gruppendokument (
  id int(11) default NULL,
  gruppe_id int(11) default NULL,
  mit_id int(11) default NULL,
  betr varchar(254) default NULL,
  fname varchar(254) default NULL,
  art int(11) default NULL,
  vd int(11) default NULL,
  vm int(11) default NULL,
  vy int(11) default NULL,
  mtyp int(11) default NULL,
  dok blob,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'gruppendokument'
--



--
-- Table structure for table 'importprotokoll'
--

CREATE TABLE importprotokoll (
  id int(11) default NULL,
  exp_id int(11) default NULL,
  mit_id int(11) default NULL,
  zeit int(11) default NULL,
  dbsite int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'importprotokoll'
--



--
-- Table structure for table 'jghstat'
--

CREATE TABLE jghstat (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  fall_fn char(20) default NULL,
  gfall int(11) default NULL,
  bezirksnr int(11) default NULL,
  stz int(11) default NULL,
  rbz int(11) default NULL,
  kr int(11) default NULL,
  gm int(11) default NULL,
  gmt int(11) default NULL,
  lnr int(11) default NULL,
  traeg int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  bgr int(11) default NULL,
  gs int(11) default NULL,
  ag int(11) default NULL,
  fs int(11) default NULL,
  hke int(11) default NULL,
  gsa int(11) default NULL,
  gsu int(11) default NULL,
  zm int(11) default NULL,
  ba0 int(11) default NULL,
  ba1 int(11) default NULL,
  ba2 int(11) default NULL,
  ba3 int(11) default NULL,
  ba4 int(11) default NULL,
  ba5 int(11) default NULL,
  ba6 int(11) default NULL,
  ba7 int(11) default NULL,
  ba8 int(11) default NULL,
  ba9 int(11) default NULL,
  schw int(11) default NULL,
  fbe0 int(11) default NULL,
  fbe1 int(11) default NULL,
  fbe2 int(11) default NULL,
  fbe3 int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'jghstat'
--


INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (2,2,5,'1-2003B',365,379,386,218,219,231,232,NULL,234,7,2003,10,2004,236,6,240,252,257,0,265,270,273,276,278,280,282,284,286,288,290,292,295,296,301,303,305,1097425724);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (3,4,6,'2-2003B',366,379,386,218,219,231,232,NULL,233,11,2003,10,2004,236,6,245,251,257,NULL,266,269,274,276,278,280,282,284,286,288,289,292,294,298,301,303,304,1097425733);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (4,5,6,'3-2003B',366,379,386,218,219,231,232,NULL,233,2,2003,10,2004,237,7,241,256,258,NULL,266,272,274,276,277,280,282,284,286,288,289,292,293,298,301,303,305,1097425741);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (5,6,6,'1-2004B',366,379,386,218,219,231,232,NULL,233,5,2004,10,2004,237,6,239,253,258,NULL,266,272,274,276,278,280,282,284,286,288,290,291,295,298,301,303,305,1097425750);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (6,7,5,'1-2002B',366,379,386,218,219,231,232,NULL,234,12,2002,10,2004,235,7,245,253,257,NULL,266,272,274,276,278,280,282,283,286,288,290,291,295,298,301,303,305,1097425757);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (7,8,6,'2-2004A',366,379,205,218,219,231,232,NULL,234,7,2004,10,2004,237,7,238,256,258,7,265,271,274,276,278,280,282,283,286,288,290,292,295,298,301,303,305,1097425766);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (8,9,7,'4-2003B',366,379,386,218,219,231,232,NULL,233,6,2003,10,2004,236,7,239,249,258,0,265,272,274,276,278,279,282,284,286,288,290,292,294,298,301,303,304,1097425772);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (9,10,6,'2-2004B',365,379,386,218,219,231,232,NULL,233,6,2004,10,2004,235,6,242,254,258,NULL,266,271,273,276,278,280,282,284,286,288,289,292,293,298,301,303,305,1097425779);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (10,11,6,'3-2004A',365,379,205,218,219,231,232,NULL,233,8,2004,10,2004,235,7,241,253,259,6,265,267,274,275,278,280,282,284,286,288,290,292,294,298,301,303,305,1097425787);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (11,12,7,'3-2004B',365,379,386,218,219,231,232,NULL,233,6,2004,10,2004,237,7,238,252,259,0,265,268,273,276,278,280,282,283,286,288,290,292,295,298,301,302,305,1097425794);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (12,13,5,'4-2004A',366,379,205,218,219,231,232,NULL,234,6,2004,10,2004,236,7,239,248,258,4,265,272,274,276,278,280,282,284,286,288,290,291,293,298,301,303,304,1097425803);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (13,14,5,'1-2003A',366,379,205,218,219,231,232,NULL,233,1,2003,10,2004,236,7,244,255,258,NULL,266,272,274,276,278,280,282,284,286,287,290,292,293,298,299,303,305,1097425808);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (14,15,6,'5-2003B',366,379,386,218,219,231,232,NULL,233,1,2003,10,2004,237,6,240,249,259,NULL,266,271,274,276,278,280,282,284,286,287,290,292,293,298,300,303,305,1097425814);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (15,17,6,'2-2003A',366,379,205,218,219,231,232,NULL,234,4,2003,10,2004,236,7,238,255,258,NULL,266,267,274,275,278,280,282,284,286,287,290,292,293,298,301,303,305,1097425825);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (16,18,7,'1-2002A',366,379,205,218,219,231,232,NULL,234,12,2002,10,2004,235,7,246,255,259,7,265,270,274,276,278,279,282,284,286,288,289,292,294,298,301,303,305,1097425834);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (17,19,6,'6-2003B',365,379,386,218,219,231,232,NULL,234,7,2003,10,2004,236,7,244,251,257,5,265,269,274,276,278,280,282,284,286,288,289,292,294,298,299,303,304,1097425843);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (18,20,5,'3-2003A',365,379,205,218,219,231,232,NULL,234,9,2003,10,2004,237,6,246,256,257,NULL,266,268,274,276,278,280,282,284,285,288,290,292,295,296,301,303,305,1097425851);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (19,21,7,'6-2004A',365,379,205,218,219,231,232,NULL,233,1,2004,10,2004,236,6,246,249,257,1,265,272,274,276,278,280,282,284,286,288,289,291,293,298,301,303,305,1097425861);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (20,22,7,'7-2003B',365,379,386,218,219,231,232,NULL,233,7,2003,10,2004,236,7,243,254,259,NULL,266,269,274,276,278,279,282,284,286,287,290,292,293,298,299,303,305,1097425867);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (21,23,7,'2-2002B',365,379,386,218,219,231,232,NULL,233,11,2002,10,2004,237,7,238,253,257,2,265,268,274,276,278,280,282,284,286,287,290,292,294,297,301,303,305,1097425873);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (22,24,6,'4-2003A',366,379,205,218,219,231,232,NULL,233,7,2003,10,2004,237,6,246,253,257,0,265,271,274,276,278,280,281,284,286,288,290,292,293,298,301,303,305,1097425880);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (23,25,5,'7-2004A',366,379,205,218,219,231,232,NULL,234,3,2004,10,2004,236,6,244,255,257,NULL,266,270,274,276,277,280,282,284,286,288,290,292,295,297,301,303,305,1097425887);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (24,26,6,'8-2003B',365,379,386,218,219,231,232,NULL,234,1,2003,10,2004,235,7,245,249,259,NULL,266,269,274,276,278,280,282,284,286,287,290,291,293,298,300,302,305,1097425896);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (25,27,7,'9-2003B',365,379,386,218,219,231,232,NULL,233,5,2003,10,2004,235,6,240,249,259,NULL,266,269,274,276,278,280,282,283,286,288,290,292,293,298,301,303,304,1097425909);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (26,28,5,'4-2004B',365,379,386,218,219,231,232,NULL,233,4,2004,10,2004,236,7,244,253,257,5,265,267,274,276,278,280,282,284,286,287,289,292,293,298,301,303,305,1097425924);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (27,29,5,'10-2003B',366,379,386,218,219,231,232,NULL,233,11,2003,10,2004,236,7,242,252,258,5,265,271,273,276,278,280,282,284,286,288,290,292,294,298,301,302,304,1097425931);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (28,30,6,'11-2003B',366,379,386,218,219,231,232,NULL,233,10,2003,10,2004,237,7,244,251,259,NULL,266,271,274,276,278,280,281,284,286,288,290,291,294,298,301,303,305,1097425938);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (29,31,6,'5-2003A',366,379,205,218,219,231,232,NULL,234,2,2003,10,2004,236,6,246,253,258,5,265,268,274,276,278,280,282,283,285,288,290,292,295,298,301,302,305,1097425946);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (30,32,7,'12-2003B',366,379,386,218,219,231,232,NULL,233,9,2003,10,2004,237,6,240,253,258,1,265,269,274,276,277,280,282,284,286,288,289,292,294,298,301,303,305,1097425956);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (31,33,6,'8-2004A',365,379,205,218,219,231,232,NULL,233,5,2004,10,2004,237,7,243,250,259,3,265,270,274,276,278,280,282,284,285,288,290,291,295,298,301,303,305,1097425964);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (32,34,7,'6-2003A',365,379,205,218,219,231,232,NULL,233,12,2003,10,2004,237,6,241,255,258,7,265,267,274,276,278,280,281,284,286,287,290,292,294,298,301,303,305,1097425973);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (33,35,6,'5-2004B',365,379,386,218,219,231,232,NULL,234,6,2004,10,2004,235,6,239,249,259,4,265,267,274,276,278,280,282,284,286,288,289,292,293,298,301,303,304,1097425979);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (34,36,5,'13-2003B',365,379,386,218,219,231,232,NULL,233,6,2003,10,2004,236,7,246,249,259,NULL,266,270,274,276,277,280,282,284,286,287,290,292,294,296,301,303,304,1097425987);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (35,37,5,'6-2004B',365,379,386,218,219,231,232,NULL,234,1,2004,10,2004,235,6,242,249,258,NULL,266,269,273,276,278,280,282,283,286,288,290,292,294,298,299,303,304,1097425995);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (36,39,5,'10-2004A',365,379,205,218,219,231,232,NULL,234,10,2004,10,2004,235,7,245,247,259,NULL,266,267,274,275,278,280,282,284,286,288,289,292,293,298,301,302,305,1097426004);

--
-- Table structure for table 'kategorie'
--

CREATE TABLE kategorie (
  id int(11) default NULL,
  code char(8) default NULL,
  name char(60) default NULL,
  kat_id int(11) default NULL,
  dok char(255) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'kategorie'
--


INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (1,'verwtyp','Feldverwendungstyp',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (2,'fsag','Altersgruppe Kind/Jugendliche',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (3,'fsagel','Altersgruppe Eltern',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (4,'fsfs','Lebensmittelpunkt des Kindes',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (5,'fszm','Zugangsweg',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (6,'fsba','Vorstellungsanlass bei der Anmeldung',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (7,'fsbe','Beruf der Eltern',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (8,'fshe','Herkunftsland der Eltern',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (9,'fspbe','Problemspektrum Eltern',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (10,'fspbk','Problemspektrum Kind, Jugendliche',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (11,'fsle','Erbrachte Leistungen',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (12,'fskat','Anzahl der Termine',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (13,'fsqualij','sozialer Status Jugendlicher, 14-27',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (14,'fsquali','Qualifikation der Eltern',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (15,'klerv','Verwandtschaftsgrad',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (16,'klinsta','Einrichtungskontakt',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (17,'status','Mitarbeiterstatus',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (18,'stzei','Dienststelle',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (19,'benr','Benutzungsrecht',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (20,'stand','Bearbeitungsstand',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (21,'notizbed','Notizbedeutung',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (22,'vert','im Verteiler',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (23,'einrstat','Aktueller Kontakt',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (24,'rbz','Regierungsbezirk',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (25,'kr','Kreis',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (26,'gm','Gemeinde',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (27,'gmt','Gemeindeteil',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (28,'traeg','Jugendhilfe-Tr�ger',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (29,'bgr','Beendigungsgrund',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (30,'gs','Geschlecht',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (31,'ag','Alter',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (32,'fs','Junger Mensch lebt bei',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (33,'hke','Staatsangeh�rigkeit',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (34,'zm','1. Kontakt durch',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (35,'gsa','Geschwisteranzahl',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (36,'gsu','Kenntnis der Geschwisterzahl',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (37,'ba0','Beratungsanlass 0',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (38,'ba1','Beratungsanlass 1',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (39,'ba2','Beratungsanlass 2',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (40,'ba3','Beratungsanlass 3',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (41,'ba4','Beratungsanlass 4',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (42,'ba5','Beratungsanlass 5',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (43,'ba6','Beratungsanlass 6',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (44,'ba7','Beratungsanlass 7',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (45,'ba8','Beratungsanlass 8',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (46,'ba9','Beratungsanlass 9',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (47,'schw','Beratungsschwerpunkt',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (48,'fbe0','beim jungen Menschen',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (49,'fbe1','bei den Eltern',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (50,'fbe2','in der Familie',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (51,'fbe3','im sozialen Umfeld',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (52,'mimetyp','Mime Typ',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (53,'dokart','Der Eintrag ist',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (54,'teiln','Teilnehmer/innnen',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (55,'grtyp','Gruppentyp',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (56,'gfall','Geschwisterfall',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (57,'wohnbez','Wohnbezirksnr des Klienten',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (58,'dbsite','Datenbank-Site',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (59,'lage','Lage innerhalb oder au�erhalb des Geltungsbereichs des Stra�',NULL,NULL,1097425701);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (60,'config','Konfigurationseinstellungen',NULL,NULL,1097425701);

--
-- Table structure for table 'leistung'
--

CREATE TABLE leistung (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  le int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  stz int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'leistung'
--


INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (2,2,7,138,28,7,2003,15,5,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (3,2,5,149,23,3,2004,15,5,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (4,2,5,137,26,1,2004,15,5,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (5,2,5,142,25,8,2003,15,5,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (6,3,7,135,25,7,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (7,4,6,136,16,11,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (8,5,7,138,2,2,2003,25,4,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (9,5,6,145,22,2,2003,25,4,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (10,5,6,144,16,3,2003,25,4,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (11,6,7,146,1,5,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (12,7,5,133,12,12,2002,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (13,8,7,140,2,7,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (14,9,5,142,8,6,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (15,10,6,133,2,6,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (16,11,5,143,27,8,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (17,12,6,135,15,6,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (18,13,7,148,19,6,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (19,14,6,135,17,1,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (20,15,5,143,18,1,2003,16,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (21,15,6,136,15,2,2004,16,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (22,15,6,135,3,3,2003,16,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (23,15,6,148,2,2,2003,16,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (24,15,6,139,6,7,2003,16,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (25,15,6,133,5,6,2003,16,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (26,16,5,146,18,9,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (27,17,5,146,27,4,2003,2,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (28,17,6,141,13,11,2003,2,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (29,18,6,133,4,12,2002,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (30,19,7,139,10,7,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (31,20,6,146,10,9,2003,22,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (32,20,5,131,13,6,2004,22,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (33,20,5,135,7,5,2004,22,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (34,20,5,142,23,9,2003,22,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (35,20,5,143,17,8,2004,22,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (36,21,6,136,24,1,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (37,22,7,141,27,7,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (38,23,5,149,21,11,2002,6,9,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (39,24,5,148,25,7,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (40,25,7,139,23,3,2004,10,5,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (41,26,7,136,20,1,2003,3,9,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (42,26,6,138,14,2,2003,3,9,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (43,26,6,132,14,2,2003,3,9,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (44,27,7,133,13,5,2003,17,4,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (45,27,7,144,5,4,2004,17,4,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (46,27,7,137,19,9,2003,17,4,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (47,27,7,135,25,2,2004,17,4,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (48,27,7,139,20,3,2004,17,4,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (49,28,5,137,27,4,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (50,29,7,143,6,11,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (51,30,7,148,18,10,2003,20,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (52,31,5,144,15,2,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (53,32,6,148,8,9,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (54,33,6,139,1,5,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (55,34,7,132,21,12,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (56,35,6,142,26,6,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (57,36,5,145,9,6,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (58,37,5,144,26,1,2004,28,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (59,37,5,147,11,2,2004,28,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (60,37,5,131,6,2,2004,28,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (61,38,5,132,12,8,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (62,39,7,140,4,10,2004,0,0,0,205);

--
-- Table structure for table 'mitarbeiter'
--

CREATE TABLE mitarbeiter (
  id int(11) default NULL,
  vn char(35) default NULL,
  na char(35) default NULL,
  ben char(25) default NULL,
  anr char(20) default NULL,
  tl1 char(25) default NULL,
  fax char(25) default NULL,
  mail char(50) default NULL,
  stat int(11) default NULL,
  benr int(11) default NULL,
  stz int(11) default NULL,
  zeit int(11) default NULL,
  pass char(50) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'mitarbeiter'
--


INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (1,'Admin','Administrator','Admin',NULL,NULL,NULL,NULL,203,206,205,1097425705,'4e7afebcfbae000b22c7c85e5560f89a2a0280b4');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (2,'Protokol2vn','Protokol2na','pr1',NULL,NULL,NULL,NULL,203,209,386,1097425715,'16bc8ed897088bc50fc6d41eddeb2928401dd942');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (3,'Protokol3vn','Protokol3na','pr2',NULL,NULL,NULL,NULL,203,209,205,1097425715,'e590beb38f2503444a9f9e2e6f0f61698890fb5e');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (4,'Verw4vn','Verw4na','verw',NULL,NULL,NULL,NULL,203,208,386,1097425716,'dad3d82ccef3940d682e7eb5c62e6ff5b1bb43aa');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (5,'Bearb5vn','Bearb5na','bearb1',NULL,NULL,NULL,NULL,203,207,205,1097425716,'bf46eb1252e630d57d7362ff9d1ded47c9f54763');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (6,'Bearb6vn','Bearb6na','bearb2',NULL,NULL,NULL,NULL,203,207,205,1097425716,'984cbfa8abac2ec5c2147d248bf1f12f1d663943');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (7,'Test','Tester','test',NULL,NULL,NULL,NULL,203,207,205,1097425717,'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3');

--
-- Table structure for table 'mitarbeitergruppe'
--

CREATE TABLE mitarbeitergruppe (
  id int(11) default NULL,
  mit_id int(11) default NULL,
  gruppe_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'mitarbeitergruppe'
--



--
-- Table structure for table 'mitstelle'
--

CREATE TABLE mitstelle (
  mit_id int(11) default NULL,
  stz int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'mitstelle'
--



--
-- Table structure for table 'protokoll'
--

CREATE TABLE protokoll (
  nr int(11) default NULL,
  zeit varchar(17) default NULL,
  artdeszugriffs longtext,
  benutzerkennung varchar(25) default NULL,
  ipadresse varchar(25) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'protokoll'
--



--
-- Table structure for table 'schluessel'
--

CREATE TABLE schluessel (
  tab_id int(11) default NULL,
  feld_id int(11) default NULL,
  seq int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'schluessel'
--



--
-- Table structure for table 'sessions'
--

CREATE TABLE sessions (
  session_id char(50) default NULL,
  time char(16) default NULL,
  user_name char(25) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'sessions'
--



--
-- Table structure for table 'strassenkat'
--

CREATE TABLE strassenkat (
  str_nummer char(5) default NULL,
  str_name char(60) default NULL,
  hausnr char(4) default NULL,
  bezirk int(11) default NULL,
  plz int(11) default NULL,
  Plraum char(4) default NULL,
  KEY str_name (str_name(10))
) TYPE=MyISAM;

--
-- Dumping data for table 'strassenkat'
--


INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','001',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','002',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','003',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','004',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','004A',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','005',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','008',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','012',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','016',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','017',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','018',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','019',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','020',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','021',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','022',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','023',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','023A',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','024',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','025',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','026',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','027',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','028',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','029',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','030',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','031',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','032',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','033',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','034',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','035',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','036',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','037',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','038',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','039',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','040',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','041',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','042',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','043',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','044',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00001','Aachener Str.','045',4,10713,'0027');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('20013','Aalemannkanal','112',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','---',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','---',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','---',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','---',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','001',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','004',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','005',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','007',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','007A',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','007D',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','007E',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009A',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009B',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009C',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009D',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009E',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009F',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009G',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009H',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','009J',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011A',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011B',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011C',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011D',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011E',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011F',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011G',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011H',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','011J',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013A',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013B',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013C',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013D',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013E',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013F',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013G',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013H',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013J',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013K',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013L',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','013M',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','014',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015A',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015B',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015C',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015D',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015E',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015F',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015G',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015H',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015J',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015K',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015L',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','015M',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','017',5,13587,'0101');
INSERT INTO strassenkat (str_nummer, str_name, hausnr, bezirk, plz, Plraum) VALUES ('00002','Aalemannufer','017A',5,13587,'0101');

--
-- Table structure for table 'tabelle'
--

CREATE TABLE tabelle (
  id int(11) default NULL,
  tabelle char(30) default NULL,
  name char(60) default NULL,
  klasse char(60) default NULL,
  flag int(11) default NULL,
  dok char(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'tabelle'
--


INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (1,'mitarbeiter','Mitarbeiter','Mitarbeiter',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (2,'protokoll','Protokoll','Protokoll',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (3,'strassenkat','Strassenkatalog','Strassenkatalog',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (4,'sessions','Session','Session',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (5,'mitstelle','Zuordnung Mitarbeiter-Dienststelle','MitarbeiterDienststelle',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (6,'akte','Akte','Akte',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (7,'fall','Fall','Fall',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (8,'anmeldung','Anmeldung','Anmeldung',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (9,'bezugsperson','Bezugsperson','Bezugsperson',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (10,'einrichtung','Kontakt mit Einrichtung','Einrichtungskontakt',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (11,'leistung','Leistung','Leistung',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (12,'zustaendigkeit','Zust�ndigkeit','Zustaendigkeit',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (13,'dokument','Dokument','Dokument',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (14,'gruppendokument','Zuordnung Gruppe-Dokument','Gruppendokument',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (15,'gruppe','Gruppe','Gruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (16,'fallgruppe','Zuordnung Fall-Gruppe','FallGruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (17,'bezugspersongruppe','Zuordnung Bezugsperson-Gruppe','BezugspersonGruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (18,'mitarbeitergruppe','Zuordnung Mitarbeiter-Gruppe','MitarbeiterGruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (19,'fachstat','Fachstatistik','Fachstatistik',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (20,'fachstatlei','Zuordnung Fachstatistik-Leistung','Fachstatistikleistung',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (21,'fachstatkindproblem','Zuordnung Fachstatistik-Problemspektrum Kind','Fachstatistikkindproblem',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (22,'fachstatelternproblem','Zuordnung Fachstatistik-Problemspektrum Eltern','Fachstatistikelternproblem',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (23,'jghstat','Jugendhilfestatistik','Jugendhilfestatistik',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (24,'code','Code','Code',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (25,'kategorie','Kategorie','Kategorie',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (26,'exportprotokoll','DB Exportprotokoll','Exportprotokoll',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (27,'importprotokoll','DB Importprotokoll','Importprotokoll',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (28,'feld','Feld','Feld',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (29,'tabelle','Tabelle','Tabelle',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (30,'tabid','Zuordnung Tabelle-ID-Bereiche','TabellenID',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (31,'schluessel','Schl�ssel','Schluessel',0,NULL);

--
-- Table structure for table 'tabid'
--

CREATE TABLE tabid (
  table_id int(11) default NULL,
  table_name char(30) default NULL,
  dbsite int(11) default NULL,
  minid int(11) default NULL,
  maxid int(11) default NULL,
  maxist int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'tabid'
--


INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (1,'mitarbeiter',381,1,1000000000,7);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (2,'protokoll',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (4,'sessions',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (6,'akte',381,1,1000000000,36);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (7,'fall',381,1,1000000000,39);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (8,'anmeldung',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (9,'bezugsperson',381,1,1000000000,68);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (10,'einrichtung',381,1,1000000000,39);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (11,'leistung',381,1,1000000000,62);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (12,'zustaendigkeit',381,1,1000000000,39);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (13,'dokument',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (14,'gruppendokument',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (15,'gruppe',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (16,'fallgruppe',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (17,'bezugspersongruppe',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (18,'mitarbeitergruppe',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (19,'fachstat',381,1,1000000000,36);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (20,'fachstatlei',381,1,1000000000,176);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (21,'fachstatkindproblem',381,1,1000000000,78);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (22,'fachstatelternproblem',381,1,1000000000,83);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (23,'jghstat',381,1,1000000000,36);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (24,'code',381,1,1000000000,386);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (25,'kategorie',381,1,1000000000,60);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (26,'exportprotokoll',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (27,'importprotokoll',381,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (28,'feld',381,1,1000000000,332);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (29,'tabelle',381,1,1000000000,31);

--
-- Table structure for table 'zustaendigkeit'
--

CREATE TABLE zustaendigkeit (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'zustaendigkeit'
--


INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (2,2,5,28,7,2003,15,5,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (3,3,7,25,7,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (4,4,6,16,11,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (5,5,6,2,2,2003,25,4,2003);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (6,6,6,1,5,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (7,7,5,12,12,2002,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (8,8,6,2,7,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (9,9,7,8,6,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (10,10,6,2,6,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (11,11,6,27,8,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (12,12,7,15,6,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (13,13,5,19,6,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (14,14,5,17,1,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (15,15,6,18,1,2003,16,8,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (16,16,5,18,9,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (17,17,6,27,4,2003,2,8,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (18,18,7,4,12,2002,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (19,19,6,10,7,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (20,20,5,10,9,2003,22,8,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (21,21,7,24,1,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (22,22,7,27,7,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (23,23,7,21,11,2002,6,9,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (24,24,6,25,7,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (25,25,5,23,3,2004,10,5,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (26,26,6,20,1,2003,3,9,2003);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (27,27,7,13,5,2003,17,4,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (28,28,5,27,4,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (29,29,5,6,11,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (30,30,6,18,10,2003,20,2,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (31,31,6,15,2,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (32,32,7,8,9,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (33,33,6,1,5,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (34,34,7,21,12,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (35,35,6,26,6,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (36,36,5,9,6,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (37,37,5,26,1,2004,28,2,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (38,38,5,12,8,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (39,39,5,4,10,2004,0,0,0);

