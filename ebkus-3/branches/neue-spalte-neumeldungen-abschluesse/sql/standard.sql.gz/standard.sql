-- MySQL dump 8.22
--
-- Host: localhost    Database: muster_efb_XX_init_XX
---------------------------------------------------------
-- Server version	3.23.55-Max-log

--
-- Table structure for table 'akte'
--

CREATE TABLE akte (
  id int(11) default NULL,
  vn char(35) default NULL,
  na char(35) default NULL,
  gb char(10) default NULL,
  ber char(30) default NULL,
  str char(35) default NULL,
  hsnr char(5) default NULL,
  plz char(9) default NULL,
  planungsr char(4) default NULL,
  wohnbez int(11) default NULL,
  lage int(11) default NULL,
  ort char(35) default NULL,
  tl1 char(25) default NULL,
  tl2 char(25) default NULL,
  fs int(11) default NULL,
  no char(255) default NULL,
  stzbg int(11) default NULL,
  stzak int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'akte'
--



--
-- Table structure for table 'anmeldung'
--

CREATE TABLE anmeldung (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  von char(35) default NULL,
  ad int(11) default NULL,
  am int(11) default NULL,
  ay int(11) default NULL,
  mtl char(25) default NULL,
  me char(35) default NULL,
  zm int(11) default NULL,
  mg char(255) default NULL,
  no char(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'anmeldung'
--



--
-- Table structure for table 'bezugsperson'
--

CREATE TABLE bezugsperson (
  id int(11) default NULL,
  akte_id int(11) default NULL,
  vn char(35) default NULL,
  na char(35) default NULL,
  gb char(10) default NULL,
  ber char(30) default NULL,
  str char(35) default NULL,
  hsnr char(5) default NULL,
  lage int(11) default NULL,
  plz char(9) default NULL,
  ort char(35) default NULL,
  tl1 char(25) default NULL,
  tl2 char(25) default NULL,
  fs int(11) default NULL,
  verw int(11) default NULL,
  no char(255) default NULL,
  nobed int(11) default NULL,
  vrt int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'bezugsperson'
--



--
-- Table structure for table 'bezugspersongruppe'
--

CREATE TABLE bezugspersongruppe (
  id int(11) default NULL,
  bezugsp_id int(11) default NULL,
  gruppe_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'bezugspersongruppe'
--



--
-- Table structure for table 'code'
--

CREATE TABLE code (
  id int(11) default NULL,
  kat_id int(11) default NULL,
  kat_code char(8) default NULL,
  code char(8) default NULL,
  name char(160) default NULL,
  sort int(11) default NULL,
  mini int(11) default NULL,
  maxi int(11) default NULL,
  off int(11) default NULL,
  dm int(11) default NULL,
  dy int(11) default NULL,
  dok char(255) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'code'
--


INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (1,1,'verwtyp','s','Schl�ssel',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (2,1,'verwtyp','f','Fremdschl�ssel',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (3,1,'verwtyp','k','Kategorie',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (4,1,'verwtyp','b','Bereichskategorie',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (5,1,'verwtyp','p','Primitiv',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (6,30,'gs','1','m',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (7,30,'gs','2','w',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (8,2,'fsag','1','0-2',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (9,2,'fsag','2','3-5',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (10,2,'fsag','3','6-9',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (11,2,'fsag','4','10-13',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (12,2,'fsag','5','14-17',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (13,2,'fsag','6','18-20',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (14,2,'fsag','7','21-26',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (15,2,'fsag','8','vor d. Schw.',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (16,2,'fsag','9','pr�natal',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (17,2,'fsag','999','keine Angabe',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (18,3,'fsagel','1','bis 20',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (19,3,'fsagel','2','21-26',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (20,3,'fsagel','3','27-44',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (21,3,'fsagel','4','45-54',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (22,3,'fsagel','5','55-64',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (23,3,'fsagel','6','65-74',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (24,3,'fsagel','7','75-',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (25,3,'fsagel','999','keine Angabe',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (26,4,'fsfs','1','verheiratet, leibl. Eltern',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (27,4,'fsfs','2','unverheiratet, leibl. Eltern',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (28,4,'fsfs','3','wechselnd bei Km u. Kv',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (29,4,'fsfs','4','Elternteil u. Stiefelternteil',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (30,4,'fsfs','5','alleinerziehende Mutter',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (31,4,'fsfs','6','alleinerziehender Vater',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (32,4,'fsfs','7','Verwandte',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (33,4,'fsfs','8','Pflegefamilie',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (34,4,'fsfs','9','Adoptivfamilie',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (35,4,'fsfs','10','Heim',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (36,4,'fsfs','11','Wohngemeinschaft',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (37,4,'fsfs','12','eigene Wohnung',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (38,4,'fsfs','13','obdachlos',13,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (39,4,'fsfs','14','sonstige',14,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (40,4,'fsfs','999','keine Angabe',15,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (41,5,'fszm','1','ohne Empfehlung',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (42,5,'fszm','2','Klient/Bekannte',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (43,5,'fszm','3','ASD',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (44,5,'fszm','4','KJGD/KJPD',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (45,5,'fszm','5','Kita/Hort',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (46,5,'fszm','6','Schule',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (47,5,'fszm','7','Schulpsychologie',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (48,5,'fszm','8','Kinder-/Jugendbetreuung',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (49,5,'fszm','9','Medizinische Einrichtung',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (50,5,'fszm','10','Gericht',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (51,5,'fszm','11','�ffentlichkeitsarbeit',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (52,5,'fszm','12','Sonstige',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (53,5,'fszm','999','keine Angabe',13,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (54,6,'fsba','1','Entwicklungs-, Verhaltensauff. in d. Familie',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (55,6,'fsba','2','Entwicklungs-, Verhaltensauff. in d. Kita',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (56,6,'fsba','3','Entwicklungs-, Verhaltensauff. in d. Schule',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (57,6,'fsba','4','Entwicklungs-, Verhaltensauff. im sonst. Umfeld',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (58,6,'fsba','5','Entwickungs- , Verhaltensauff., sonstige',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (59,6,'fsba','6','Leistungsproblem in der Schule/Ausbildung',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (60,6,'fsba','7','Lebensproblem der Jugendlichen',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (61,6,'fsba','8','Abl�sungsproblem des Jugendlichen',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (62,6,'fsba','9','Krise der Jugendlichen',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (63,6,'fsba','10','sexueller Missbrauch',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (64,6,'fsba','11','�berforderung der Eltern',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (65,6,'fsba','12','Erziehungsunsicherheiten',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (66,6,'fsba','13','Familienkonflikt',13,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (67,6,'fsba','14','Paarkonflikt',14,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (68,6,'fsba','15','Trennungs- / Scheidungsproblem der Eltern',15,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (69,6,'fsba','16','Sorge- oder Umgangsrecht',16,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (70,6,'fsba','17','Begleiteter Umgang',17,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (71,6,'fsba','18','akute Krise des Ratsuchenden',18,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (72,6,'fsba','19','Begleitung vor u. nach Fremdunterbringung',19,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (73,6,'fsba','20','Stellungnahme KJHG-Psychotherapie',20,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (74,6,'fsba','21','Stellungnahme f�r anderen Dienst',21,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (75,6,'fsba','22','Gerichtsgutachten',22,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (76,6,'fsba','23','sonstiges',23,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (77,6,'fsba','999','keine Angabe',24,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (78,7,'fsbe','1','nicht berufst�tig',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (79,7,'fsbe','2','Vollzeit angestellt / ABM',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (80,7,'fsbe','3','Teilzeit angestellt / ABM',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (81,7,'fsbe','4','Schichtarbeit',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (82,7,'fsbe','5','selbst�ndig',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (83,7,'fsbe','6','arbeitslos',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (84,7,'fsbe','7','Sozialhilfe',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (85,7,'fsbe','8','berentet',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (86,7,'fsbe','9','in Ausbildung oder Umschulung',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (87,7,'fsbe','10','sonstige',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (88,7,'fsbe','999','keine Angabe',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (89,8,'fshe','1','Deutschland',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (90,8,'fshe','2','Europa',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (91,8,'fshe','3','Ost-Europa',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (92,8,'fshe','4','T�rkei',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (93,8,'fshe','5','arabische L�nder',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (94,8,'fshe','6','Schwarz-Afrika',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (95,8,'fshe','7','Asien',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (96,8,'fshe','8','Nordamerika',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (97,8,'fshe','9','Lateinamerika',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (98,8,'fshe','10','Australien',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (99,8,'fshe','11','andere L�nder',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (100,8,'fshe','999','keine Angabe',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (101,9,'fspbe','1','Krankheit, Behinderung',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (102,9,'fspbe','2','Alkohol-, Drogenkonsum',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (103,9,'fspbe','3','chronifizierte psychische Erkrankung',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (104,9,'fspbe','4','Opfer famili�rer Gewalt, sex. Missbrauchs',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (105,9,'fspbe','5','starke Traumatisierung (Krieg, Folter)',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (106,9,'fspbe','6','�berforderung',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (107,9,'fspbe','7','Isolation und Kontaktschwierigkeiten',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (108,9,'fspbe','8','Verschuldung',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (109,9,'fspbe','9','unzureichende Wohnverh�ltnisse',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (110,9,'fspbe','10','sonstige',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (111,9,'fspbe','999','keine Angabe',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (112,10,'fspbk','1','allg. Erziehungs-, Entwicklungsproblem',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (113,10,'fspbk','2','neurotische oder psychosomatische Reaktion',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (114,10,'fspbk','3','Vernachl�ssigung, Verwahrlosung',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (115,10,'fspbk','4','Opfer von Gewalt, Misshandlung',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (116,10,'fspbk','5','Sexueller Missbrauch (Opfer)',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (117,10,'fspbk','6','Alkohol-, Drogenkonsum',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (118,10,'fspbk','7','strafbares Verhalten',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (119,10,'fspbk','8','Schulleistungsproblem',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (120,10,'fspbk','9','Schulverweigerung',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (121,10,'fspbk','10','soziale Kontaktschwierigkeit, Isolation',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (122,10,'fspbk','11','aggressives Verhalten',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (123,10,'fspbk','12','Gewaltbereitschaft des Jugendlichen',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (124,10,'fspbk','13','berufliche Perspektive',13,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (125,10,'fspbk','14','Behinderung',14,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (126,10,'fspbk','15','Suizidgef�hrdung',15,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (127,10,'fspbk','16','Esst�rung',16,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (128,10,'fspbk','17','traumat. Verlust, Tod einer Bezugsperson',17,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (129,10,'fspbk','18','sonstige',18,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (130,10,'fspbk','999','keine Angabe',19,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (131,11,'fsle','1','Erziehungsberatung',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (132,11,'fsle','2','Trennungs-, Scheidungsberatung, Mediation, Umgangsberatung',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (133,11,'fsle','3','Begleiteter Umgang',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (134,11,'fsle','4','Familienberatung, -therapie',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (135,11,'fsle','5','Paarberatung, -therapie',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (136,11,'fsle','6','Einzelbetreuung / -therapie Kind',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (137,11,'fsle','7','Einzelbetreuung / -therapie Jugendlicher',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (138,11,'fsle','8','Einzelbetreuung / -therapie Erwachsener',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (139,11,'fsle','9','Gruppentherapie Kinder',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (140,11,'fsle','10','Gruppentherapie Jugendliche',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (141,11,'fsle','11','Gruppentherapie Erwachsene',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (142,11,'fsle','12','Arbeit im sozialen Umfeld',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (143,11,'fsle','13','spezieller Diagnostikauftrag',13,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (144,11,'fsle','14','Hilfeplanung, Hilfekonferenz',14,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (145,11,'fsle','15','fachliche Bescheinigung f�r Klienten',15,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (146,11,'fsle','16','Begleitung KJHG-Therapie',16,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (147,11,'fsle','17','Fachdienstliche Stellungnahme',17,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (148,11,'fsle','18','Gerichtsgutachten',18,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (149,11,'fsle','19','sonstige',19,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (150,11,'fsle','999','keine Angabe',20,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (151,12,'fskat','0','keine Angabe',1,0,0,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (152,12,'fskat','1','1-5',2,1,5,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (153,12,'fskat','2','6-10',3,6,10,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (154,12,'fskat','3','11-15',4,11,15,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (155,12,'fskat','4','16-20',5,16,20,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (156,12,'fskat','5','21-30',6,21,30,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (157,12,'fskat','6','31-40',7,31,40,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (158,12,'fskat','7','41-50',8,41,50,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (159,12,'fskat','8','mehr als 50',9,51,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (160,15,'klerv','1','Mutter',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (161,15,'klerv','2','Vater',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (162,15,'klerv','3','Geschwister',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (163,15,'klerv','4','Halbgeschw.',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (164,15,'klerv','5','Stiefmutter',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (165,15,'klerv','6','Stiefvater',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (166,15,'klerv','7','Grossmutter',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (167,15,'klerv','8','Grossvater',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (168,15,'klerv','9','verwandt',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (169,15,'klerv','10','Pflegemutter',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (170,15,'klerv','11','Pflegevater',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (171,15,'klerv','12','Adoptivmutter',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (172,15,'klerv','13','sonstige',13,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (173,15,'klerv','999','k. Angabe',14,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (174,16,'klinsta','1','ASD',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (175,16,'klinsta','2','KJGD/KJPD',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (176,16,'klinsta','3','Kita/Hort',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (177,16,'klinsta','4','Schule',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (178,16,'klinsta','5','Heim',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (179,16,'klinsta','6','Wohngemeinschaft',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (180,16,'klinsta','7','Freizeiteinr.',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (181,16,'klinsta','8','Arzt',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (182,16,'klinsta','9','Klinik',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (183,16,'klinsta','10','Gericht',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (184,16,'klinsta','11','Schulpsychologie',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (185,16,'klinsta','12','Sonstige',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (186,16,'klinsta','999','keine Angabe',13,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (187,13,'fsqualij','1','Schule',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (188,13,'fsqualij','2','Studium',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (189,13,'fsqualij','3','Lehre',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (190,13,'fsqualij','4','Arbeitslos',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (191,13,'fsqualij','5','berufst�tig',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (192,13,'fsqualij','5','Berufsf�rderung',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (193,13,'fsqualij','6','sonstige',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (194,13,'fsqualij','999','keine Angabe',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (195,14,'fsquali','1','Schule',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (196,14,'fsquali','2','ungelernt',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (197,14,'fsquali','3','Berufsausbildung',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (198,14,'fsquali','4','Facharbeiter',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (199,14,'fsquali','5','Hochschulabschluss',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (200,14,'fsquali','6','Umschulung',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (201,14,'fsquali','7','sonstige',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (202,14,'fsquali','999','keine Angabe',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (203,17,'status','i','im Dienst',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (204,17,'status','a','nicht im Dienst',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (205,18,'stzei','A','EFB-Dienststelle',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (206,19,'benr','admin','Administrator',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (207,19,'benr','bearb','Fallbearbeiter',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (208,19,'benr','verw','Verwaltung',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (209,19,'benr','protokol','protokol',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (210,20,'stand','l','laufender Fall',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (211,20,'stand','zdA','zu den Akten',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (212,21,'notizbed','t','Notiz wichtig',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (213,21,'notizbed','f','Notiz',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (214,22,'vert','t','ist im Verteiler',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (215,22,'vert','f','nicht im Verteiler',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (216,23,'einrstat','ja','aktuelle Einrichtung',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (217,23,'einrstat','nein','fr�here Einrichtung',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (218,24,'rbz','0','Musterregierungsbezirk',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (219,25,'kr','01','Kreis1',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (220,25,'kr','02','Kreis2',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (221,25,'kr','03','Kreis3',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (222,26,'gm','000','N.N.',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (223,27,'gmt','000','N.N.',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (224,28,'traeg','1','Tr�ger der �ffentl. JGH',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (225,28,'traeg','2','Tr�ger der freien JGH',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (226,29,'bgr','1','Beratung wurde einvernehmlich beendet',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (227,29,'bgr','2','letzter Kontakt liegt mehr als 6 M. zur�ck',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (228,29,'bgr','3','Weiterverweisung',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (229,31,'ag','1','unter 3',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (230,31,'ag','2','3 - unter 6',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (231,31,'ag','3','6 - unter 9',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (232,31,'ag','4','9 - unter 12',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (233,31,'ag','5','12 - unter 15',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (234,31,'ag','6','15 - unter 18',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (235,31,'ag','7','18 - unter 21',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (236,31,'ag','8','21 - unter 24',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (237,31,'ag','9','24 - unter 27',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (238,32,'fs','01','bei Eltern',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (239,32,'fs','02','bei 1 Elternteil mit Stiefelternteil',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (240,32,'fs','03','bei alleinerziehendem Elternteil',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (241,32,'fs','04','bei Grosseltern, Verwandten',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (242,32,'fs','05','in einer Pflegestelle',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (243,32,'fs','06','in einem Heim',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (244,32,'fs','07','in einer Wohngemeinschaft',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (245,32,'fs','08','in eigener Wohnung',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (246,32,'fs','09','ohne feste Unterkunft',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (247,32,'fs','10','an unbekanntem Ort',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (248,33,'hke','1','deutsch',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (249,33,'hke','2','nicht-deutsch',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (250,33,'hke','3','unbekannt',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (251,35,'gsa','0','kein Geschwister',1,0,0,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (252,35,'gsa','1','1 Geschwister',2,1,1,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (253,35,'gsa','2','2 Geschwister',3,2,2,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (254,35,'gsa','3','3 Geschwister',4,3,3,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (255,35,'gsa','4','mehr als 3 Geschwister',5,4,20,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (256,36,'gsu','0','bekannt',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (257,36,'gsu','1','unbekannt',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (258,34,'zm','1','jungen Menschen selbst',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (259,34,'zm','2','Eltern gemeinsam',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (260,34,'zm','3','Mutter',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (261,34,'zm','4','Vater',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (262,34,'zm','5','soziale Dienste',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (263,34,'zm','6','Sonstige',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (264,37,'ba0','1','Entwicklungsauff�lligkeiten',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (265,37,'ba0','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (266,38,'ba1','1','Beziehungsprobleme',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (267,38,'ba1','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (268,39,'ba2','1','Schule-/Ausbildungsprobleme',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (269,39,'ba2','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (270,40,'ba3','1','Straftat d. Jugendl./jungen Vollj�hrigen',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (271,40,'ba3','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (272,41,'ba4','1','Suchtprobleme des jungen Menschen',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (273,41,'ba4','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (274,42,'ba5','1','Anzeichen f�r Kindesmisshandlung',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (275,42,'ba5','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (276,43,'ba6','1','Anzeichen f�r sexuellen Missbrauch',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (277,43,'ba6','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (278,44,'ba7','1','Trennung/Scheidung der Eltern',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (279,44,'ba7','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (280,45,'ba8','1','Wohnungsprobleme',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (281,45,'ba8','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (282,46,'ba9','1','sonstige Probleme in u. mit der Familie',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (283,46,'ba9','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (284,47,'schw','1','Erziehungs-/Familienberatung',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (285,47,'schw','2','Jugendberatung',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (286,47,'schw','3','Suchtberatung',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (287,48,'fbe0','1','allein',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (288,48,'fbe0','2','in der Gruppe',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (289,48,'fbe0','0','leer',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (290,49,'fbe1','1','allein',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (291,49,'fbe1','2','in der Gruppe',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (292,49,'fbe1','0','leer',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (293,50,'fbe2','1','in der Familie',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (294,50,'fbe2','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (295,51,'fbe3','1','im sozialen Umfeld',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (296,51,'fbe3','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (297,52,'mimetyp','txt','text/plain',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (298,52,'mimetyp','asc','text/plain',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (299,52,'mimetyp','html','text/html',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (300,52,'mimetyp','htm','text/html',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (301,52,'mimetyp','pdf','application/pdf',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (302,52,'mimetyp','ps','application/postscript',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (303,52,'mimetyp','doc','application/msword',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (304,52,'mimetyp','dot','application/msword',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (305,52,'mimetyp','wrd','application/msword',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (306,52,'mimetyp','rtf','application/rtf',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (307,52,'mimetyp','xls','application/x-msexcel',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (308,52,'mimetyp','sdw','application/soffice',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (309,52,'mimetyp','sxw','application/soffice',13,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (310,52,'mimetyp','sdc','application/vnd.stardivision.calc',14,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (311,52,'mimetyp','zip','application/zip',15,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (312,52,'mimetyp','gtar','application/x-gtar',16,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (313,52,'mimetyp','tgz','application/x-gtar',17,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (314,52,'mimetyp','gz','application/x-gzip',18,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (315,52,'mimetyp','tar','application/x-tar',19,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (316,52,'mimetyp','rtx','text/richtext',20,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (317,52,'mimetyp','gif','image/gif',21,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (318,52,'mimetyp','jpg','image/jpeg',22,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (319,52,'mimetyp','jpeg','image/jpeg',23,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (320,52,'mimetyp','jpe','image/jpeg',24,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (321,52,'mimetyp','tiff','image/tiff',25,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (322,52,'mimetyp','tif','image/tiff',26,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (323,52,'mimetyp','png','image/png',27,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (324,52,'mimetyp','bmp','image/bmp',28,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (325,53,'dokart','bnotiz','Beraternotiz',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (326,53,'dokart','Vm','Vermerk',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (327,53,'dokart','anotiz','Aktennotiz',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (328,53,'dokart','Brief','Brief',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (329,53,'dokart','Prot','Protokoll',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (330,53,'dokart','Dok','Dokument',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (331,53,'dokart','Antrag','Antrag',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (332,53,'dokart','Bericht','Bericht',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (333,53,'dokart','Stellung','Stellungnahme',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (334,53,'dokart','Befund','Befunddokument',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (335,53,'dokart','Gutacht','Gutachten',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (336,53,'dokart','Beschein','Bescheinigung',12,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (337,53,'dokart','Sonstig','Sonstiges',13,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (338,54,'teiln','Kinder','Kinder',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (339,54,'teiln','Jugendl','Jugendliche',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (340,54,'teiln','Eltern','Eltern',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (341,54,'teiln','V�ter','V�ter',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (342,54,'teiln','M�tter','M�tter',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (343,54,'teiln','Altgem','Altersgemischt',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (344,54,'teiln','Familien','Familien',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (345,54,'teiln','Erzieher','ErzieherInnen',8,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (346,54,'teiln','Lehrer','Lehrer',9,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (347,54,'teiln','Paare','Paare',10,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (348,54,'teiln','sonstige','sonstige',11,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (349,55,'grtyp','Eabend','Elternabend',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (350,55,'grtyp','Kurs','Kurs',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (351,55,'grtyp','Therapie','Therapiegruppe',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (352,55,'grtyp','Seminar','Seminar',4,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (353,55,'grtyp','Selbster','Selbsterfahrung',5,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (354,55,'grtyp','Superv','Supervision',6,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (355,55,'grtyp','sonstige','sonstige',7,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (356,56,'gfall','1','Nein',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (357,56,'gfall','2','Ja',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (358,57,'wohnbez','13','ausserhalb',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (359,57,'wohnbez','999','keine Angabe',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (360,58,'dbsite','A','DBSite A',1,1,1000000000,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (361,59,'lage','0','innerhalb des Geltungsbereichs des Stra�enkatalogs',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (362,59,'lage','1','au�erhalb des Geltungsbereichs des Stra�enkatalogs',2,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (363,59,'lage','999','keine Angabe',3,NULL,NULL,0,NULL,NULL,NULL,1093707918);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (364,60,'config','protocol','off',1,NULL,NULL,0,NULL,NULL,NULL,1093707918);

--
-- Table structure for table 'dokument'
--

CREATE TABLE dokument (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  betr varchar(255) default NULL,
  fname varchar(255) default NULL,
  art int(11) default NULL,
  vd int(11) default NULL,
  vm int(11) default NULL,
  vy int(11) default NULL,
  mtyp int(11) default NULL,
  dok blob,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'dokument'
--



--
-- Table structure for table 'einrichtung'
--

CREATE TABLE einrichtung (
  id int(11) default NULL,
  akte_id int(11) default NULL,
  na char(80) default NULL,
  tl1 char(25) default NULL,
  tl2 char(25) default NULL,
  insta int(11) default NULL,
  no char(255) default NULL,
  nobed int(11) default NULL,
  status int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'einrichtung'
--



--
-- Table structure for table 'exportprotokoll'
--

CREATE TABLE exportprotokoll (
  id int(11) default NULL,
  mit_id int(11) default NULL,
  zeit int(11) default NULL,
  dbsite int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'exportprotokoll'
--



--
-- Table structure for table 'fachstat'
--

CREATE TABLE fachstat (
  id int(11) default NULL,
  mit_id int(11) default NULL,
  fall_id int(11) default NULL,
  fall_fn char(20) default NULL,
  jahr int(11) default NULL,
  stz int(11) default NULL,
  bz char(4) default NULL,
  gs int(11) default NULL,
  ag int(11) default NULL,
  fs int(11) default NULL,
  zm int(11) default NULL,
  qualij int(11) default NULL,
  hkm int(11) default NULL,
  hkv int(11) default NULL,
  bkm int(11) default NULL,
  bkv int(11) default NULL,
  qualikm int(11) default NULL,
  qualikv int(11) default NULL,
  agkm int(11) default NULL,
  agkv int(11) default NULL,
  ba1 int(11) default NULL,
  ba2 int(11) default NULL,
  pbe int(11) default NULL,
  pbk int(11) default NULL,
  kat int(11) default NULL,
  kkm int(11) default NULL,
  kkv int(11) default NULL,
  kki int(11) default NULL,
  kpa int(11) default NULL,
  kfa int(11) default NULL,
  ksoz int(11) default NULL,
  kleh int(11) default NULL,
  kerz int(11) default NULL,
  kkonf int(11) default NULL,
  kson int(11) default NULL,
  no char(255) default NULL,
  no2 char(255) default NULL,
  no3 char(255) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstat'
--



--
-- Table structure for table 'fachstatelternproblem'
--

CREATE TABLE fachstatelternproblem (
  id int(11) default NULL,
  fstat_id int(11) default NULL,
  pbe int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstatelternproblem'
--



--
-- Table structure for table 'fachstatkindproblem'
--

CREATE TABLE fachstatkindproblem (
  id int(11) default NULL,
  fstat_id int(11) default NULL,
  pbk int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstatkindproblem'
--



--
-- Table structure for table 'fachstatlei'
--

CREATE TABLE fachstatlei (
  id int(11) default NULL,
  fstat_id int(11) default NULL,
  le int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstatlei'
--



--
-- Table structure for table 'fall'
--

CREATE TABLE fall (
  id int(11) default NULL,
  akte_id int(11) default NULL,
  fn char(30) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  zdad int(11) default NULL,
  zdam int(11) default NULL,
  zday int(11) default NULL,
  status int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fall'
--



--
-- Table structure for table 'fallgruppe'
--

CREATE TABLE fallgruppe (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  gruppe_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fallgruppe'
--



--
-- Table structure for table 'feld'
--

CREATE TABLE feld (
  id int(11) default NULL,
  tab_id int(11) default NULL,
  feld char(30) default NULL,
  name char(60) default NULL,
  inverse char(60) default NULL,
  typ char(20) default NULL,
  laenge int(11) default NULL,
  notnull int(11) default NULL,
  verwtyp int(11) default NULL,
  ftab_id int(11) default NULL,
  kat_id int(11) default NULL,
  kat_code char(8) default NULL,
  flag int(11) default NULL,
  dok char(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'feld'
--


INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (1,1,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (2,1,'vn','Vorname',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (3,1,'na','Name',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (4,1,'ben','Benutzer',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (5,1,'anr','Anrede',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (6,1,'tl1','Diensttelefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (7,1,'fax','Fax',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (8,1,'mail','Mail',NULL,'CHAR(50)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (9,1,'stat','Status',NULL,'INT',NULL,NULL,3,24,17,'status',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (10,1,'benr','Benutzungsrecht',NULL,'INT',NULL,NULL,3,24,19,'benr',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (11,1,'stz','Hauptdienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (12,1,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (13,1,'pass','Passwort',NULL,'CHAR(50)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (14,2,'nr','nr',NULL,'INT(11)',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (15,2,'zeit','zeit',NULL,'VARCHAR(17)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (16,2,'artdeszugriffs','artdeszugriffs',NULL,'longtext',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (17,2,'benutzerkennung','benutzerkennung',NULL,'VARCHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (18,2,'ipadresse','ipadresse',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (19,3,'str_nummer','Str_nummer',NULL,'CHAR(5)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (20,3,'str_name','Str_name',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (21,3,'hausnr','Hausnr',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (22,3,'bezirk','Bezirk',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (23,3,'plz','Plz',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (24,3,'Plraum','Planungsraum',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (25,4,'session_id','SessionID',NULL,'CHAR(50)',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (26,4,'time','Time',NULL,'CHAR(16)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (27,4,'user_name','UserName',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (28,5,'mit_id','Mitarbeiterid','neben_stz','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (29,5,'stz','Nebendienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (30,6,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (31,6,'vn','Vorname',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (32,6,'na','Name',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (33,6,'gb','Geburtsdatum',NULL,'CHAR(10)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (34,6,'ber','Ausbildung',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (35,6,'str','Strasse',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (36,6,'hsnr','Hausnummer',NULL,'CHAR(5)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (37,6,'plz','Postleitzahl',NULL,'CHAR(9)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (38,6,'planungsr','Planungsraum',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (39,6,'wohnbez','Wohnbezirk',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (40,6,'lage','inBerlin',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (41,6,'ort','Ort',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (42,6,'tl1','Telefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (43,6,'tl2','Diensttelefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (44,6,'fs','Familienstatus (lebt bei)',NULL,'INT',NULL,NULL,3,24,4,'fsfs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (45,6,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (46,6,'stzbg','Aufnahmedienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (47,6,'stzak','Aktuelle Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (48,6,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (49,7,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (50,7,'akte_id','Aktenid','faelle','INT',NULL,NULL,2,6,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (51,7,'fn','Fallnummer',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (52,7,'bgd','Beginn Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (53,7,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (54,7,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (55,7,'zdad','Abschluss Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (56,7,'zdam','Abschluss Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (57,7,'zday','Abschluss Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (58,7,'status','Fallstand',NULL,'INT',NULL,NULL,3,24,20,'stand',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (59,8,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (60,8,'fall_id','Fall_id','anmeldung','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (61,8,'von','angemeldet von',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (62,8,'ad','Anmeldetag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (63,8,'am','Anmeldemonat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (64,8,'ay','Anmeldejahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (65,8,'mtl','Telefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (66,8,'me','auf Empfehlung von',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (67,8,'zm','Zugangsart',NULL,'INT',NULL,NULL,3,24,5,'fszm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (68,8,'mg','Anmeldegrund',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (69,8,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (70,9,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (71,9,'akte_id','Aktenid','bezugspersonen','INT',NULL,NULL,2,6,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (72,9,'vn','Vorname',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (73,9,'na','Name',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (74,9,'gb','Geburtsdatum',NULL,'CHAR(10)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (75,9,'ber','Beruf',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (76,9,'str','Strasse',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (77,9,'hsnr','Hausnummer',NULL,'CHAR(5)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (78,9,'lage','inBerlin',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (79,9,'plz','Postleitzahl',NULL,'CHAR(9)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (80,9,'ort','Ort',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (81,9,'tl1','Telefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (82,9,'tl2','Diensttelefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (83,9,'fs','Familienstatus (lebt bei)',NULL,'INT',NULL,NULL,3,24,4,'fsfs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (84,9,'verw','Verwandschaftsgrad',NULL,'INT',NULL,NULL,3,24,15,'klerv',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (85,9,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (86,9,'nobed','Notizbedeutung',NULL,'INT',NULL,NULL,3,24,21,'notizbed',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (87,9,'vrt','im Verteiler',NULL,'INT',NULL,NULL,3,24,22,'vert',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (88,10,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (89,10,'akte_id','Aktenid','einrichtungen','INT',NULL,NULL,2,6,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (90,10,'na','Name',NULL,'CHAR(80)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (91,10,'tl1','Telefon1',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (92,10,'tl2','Telefon2',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (93,10,'insta','Einrichtungsart',NULL,'INT',NULL,NULL,3,24,16,'klinsta',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (94,10,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (95,10,'nobed','Notizbedeutung',NULL,'INT',NULL,NULL,3,24,21,'notizbed',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (96,10,'status','Aktueller Kontakt',NULL,'INT',NULL,NULL,3,24,23,'einrstat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (97,11,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (98,11,'fall_id','Fallid','leistungen','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (99,11,'mit_id','Mitarbeiterid','leistungen','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (100,11,'le','Leistungsart',NULL,'INT',NULL,NULL,3,24,11,'fsle',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (101,11,'bgd','Beginn Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (102,11,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (103,11,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (104,11,'ed','Ende Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (105,11,'em','Ende Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (106,11,'ey','Ende Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (107,11,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (108,12,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (109,12,'fall_id','Fallid','zustaendigkeiten','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (110,12,'mit_id','Mitarbeiterid','zustaendigkeiten','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (111,12,'bgd','Beginn Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (112,12,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (113,12,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (114,12,'ed','Ende Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (115,12,'em','Ende Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (116,12,'ey','Ende Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (117,13,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (118,13,'fall_id','Fallid','dokumente','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (119,13,'mit_id','Mitarbeiterid','dokumente','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (120,13,'betr','Betrifft',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (121,13,'fname','Dateiname',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (122,13,'art','Text ist',NULL,'INT',NULL,NULL,3,24,53,'dokart',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (123,13,'vd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (124,13,'vm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (125,13,'vy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (126,13,'mtyp','Mime Typ',NULL,'INT',NULL,NULL,3,24,52,'mimetyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (127,13,'dok','Dokument',NULL,'BLOB',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (128,13,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (129,14,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (130,14,'gruppe_id','Gruppeid','gruppendokumente','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (131,14,'mit_id','Mitarbeiterid','gruppendokumente','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (132,14,'betr','Betrifft',NULL,'CHAR(254)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (133,14,'fname','Dateiname',NULL,'CHAR(254)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (134,14,'art','Text ist',NULL,'INT',NULL,NULL,3,24,53,'dokart',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (135,14,'vd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (136,14,'vm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (137,14,'vy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (138,14,'mtyp','Mime Typ',NULL,'INT',NULL,NULL,3,24,52,'mimetyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (139,14,'dok','Dokument',NULL,'BLOB',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (140,14,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (141,15,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (142,15,'gn','Gruppennummer',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (143,15,'name','Name',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (144,15,'thema','Thema',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (145,15,'tzahl','Anzahl der Termine',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (146,15,'stzahl','Anzahl der Stunden',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (147,15,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (148,15,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (149,15,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (150,15,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (151,15,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (152,15,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (153,15,'teiln','Teilnehmer',NULL,'INT',NULL,NULL,3,24,54,'teiln',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (154,15,'grtyp','Gruppentyp',NULL,'INT',NULL,NULL,3,24,55,'grtyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (155,15,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (156,15,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (157,16,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (158,16,'fall_id','Fallid','gruppen','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (159,16,'gruppe_id','Gruppeid','faelle','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (160,16,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (161,16,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (162,16,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (163,16,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (164,16,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (165,16,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (166,16,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (167,17,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (168,17,'bezugsp_id','Bezugspersonid','gruppen','INT',NULL,NULL,2,9,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (169,17,'gruppe_id','Gruppeid','bezugspersonen','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (170,17,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (171,17,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (172,17,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (173,17,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (174,17,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (175,17,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (176,17,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (177,18,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (178,18,'mit_id','Mitarbeiterid','gruppen','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (179,18,'gruppe_id','Gruppeid','mitarbeiter','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (180,18,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (181,18,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (182,18,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (183,18,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (184,18,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (185,18,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (186,18,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (187,19,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (188,19,'mit_id','Mitarbeiterid','fachstatistiken','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (189,19,'fall_id','Fallid','fachstatistiken','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (190,19,'fall_fn','Fallnummer',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (191,19,'jahr','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (192,19,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (193,19,'bz','Region',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (194,19,'gs','Geschlecht',NULL,'INT',NULL,NULL,3,24,30,'gs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (195,19,'ag','Altersgruppe Kind',NULL,'INT',NULL,NULL,3,24,2,'fsag',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (196,19,'fs','Familienstatus (lebt bei)',NULL,'INT',NULL,NULL,3,24,4,'fsfs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (197,19,'zm','Zugangsart',NULL,'INT',NULL,NULL,3,24,5,'fszm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (198,19,'qualij','Qualifikation des/r Jugendlicher/n',NULL,'INT',NULL,NULL,3,24,13,'fsqualij',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (199,19,'hkm','Herkunft der Mutter',NULL,'INT',NULL,NULL,3,24,8,'fshe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (200,19,'hkv','Herkunft des Vaters',NULL,'INT',NULL,NULL,3,24,8,'fshe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (201,19,'bkm','Beruf der Mutter',NULL,'INT',NULL,NULL,3,24,7,'fsbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (202,19,'bkv','Beruf des Vaters',NULL,'INT',NULL,NULL,3,24,7,'fsbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (203,19,'qualikm','Qualifikation der Mutter',NULL,'INT',NULL,NULL,3,24,14,'fsquali',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (204,19,'qualikv','Qualifikation des Vater',NULL,'INT',NULL,NULL,3,24,14,'fsquali',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (205,19,'agkm','Altersgruppe der Mutter',NULL,'INT',NULL,NULL,3,24,3,'fsagel',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (206,19,'agkv','Altersgruppe des Vaters',NULL,'INT',NULL,NULL,3,24,3,'fsagel',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (207,19,'ba1','Vorstellungsanlass 1 bei der Anmeldung',NULL,'INT',NULL,NULL,3,24,6,'fsba',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (208,19,'ba2','Vorstellungsanlass 2 bei der Anmeldung',NULL,'INT',NULL,NULL,3,24,6,'fsba',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (209,19,'pbe','Hauptproblematik Eltern',NULL,'INT',NULL,NULL,3,24,9,'fspbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (210,19,'pbk','Hauptproblematik Kind/Jugendliche',NULL,'INT',NULL,NULL,3,24,10,'fspbk',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (211,19,'kat','Summe der Konsultationen insgesamt (a 50 Min.)',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (212,19,'kkm','Anzahl der Konsultationen Mutter',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (213,19,'kkv','Anzahl der Konsultationen Vater',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (214,19,'kki','Anzahl der Konsultationen Kind / Jugendlicher',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (215,19,'kpa','Anzahl der Konsultationen Paar',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (216,19,'kfa','Anzahl der Konsultationen Familie',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (217,19,'ksoz','Anzahl der Konsultationen Sozialarbeiter',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (218,19,'kleh','Anzahl der Konsultationen Lehrer',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (219,19,'kerz','Anzahl der Konsultationen Erzieher',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (220,19,'kkonf','Anzahl der Konsultationen Hilfebesprechung',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (221,19,'kson','Kontaktanzahl Sonstige',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (222,19,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (223,19,'no2','anders geartete Problemlagen Kind',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (224,19,'no3','anders geartete Problemlagen Eltern',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (225,19,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (226,20,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (227,20,'fstat_id','Fachstatistikid','leistungen','INT',NULL,NULL,2,19,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (228,20,'le','Leistungsart',NULL,'INT',NULL,NULL,3,24,11,'fsle',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (229,21,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (230,21,'fstat_id','Fachstatistikid','fachstatkindprobleme','INT',NULL,NULL,2,19,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (231,21,'pbk','Problemspektrum Kind',NULL,'INT',NULL,NULL,3,24,10,'fspbk',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (232,22,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (233,22,'fstat_id','Fachstatistikid','fachstatelternprobleme','INT',NULL,NULL,2,19,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (234,22,'pbe','Problemspektrum Eltern',NULL,'INT',NULL,NULL,3,24,9,'fspbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (235,23,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (236,23,'fall_id','Fallid','jgh_statistiken','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (237,23,'mit_id','Mitarbeiterid','jgh_statistiken','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (238,23,'fall_fn','Fallnummer',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (239,23,'gfall','Geschwisterfall',NULL,'INT',NULL,NULL,3,24,56,'gfall',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (240,23,'bezirksnr','Wohnbezirksnummer des Klienten',NULL,'INT',NULL,NULL,3,24,57,'wohnbez',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (241,23,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (242,23,'rbz','Regierungsbezirk',NULL,'INT',NULL,NULL,3,24,24,'rbz',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (243,23,'kr','Kreis',NULL,'INT',NULL,NULL,3,24,25,'kr',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (244,23,'gm','Gemeinde',NULL,'INT',NULL,NULL,3,24,26,'gm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (245,23,'gmt','Gemeindeteil',NULL,'INT',NULL,NULL,3,24,27,'gmt',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (246,23,'lnr','laufendeNummer',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (247,23,'traeg','Tr�ger',NULL,'INT',NULL,NULL,3,24,28,'traeg',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (248,23,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (249,23,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (250,23,'em','Ende Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (251,23,'ey','Ende Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (252,23,'bgr','Beendigungsgrund',NULL,'INT',NULL,NULL,3,24,29,'bgr',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (253,23,'gs','Geschlecht',NULL,'INT',NULL,NULL,3,24,30,'gs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (254,23,'ag','Altersgruppe',NULL,'INT',NULL,NULL,3,24,31,'ag',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (255,23,'fs','lebt bei',NULL,'INT',NULL,NULL,3,24,32,'fs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (256,23,'hke','Herkunft Eltern',NULL,'INT',NULL,NULL,3,24,33,'hke',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (257,23,'gsa','Geschwisterzahl',NULL,'INT',NULL,NULL,4,NULL,35,'gsa',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (258,23,'gsu','Geschwisterzahl unbekannt',NULL,'INT',NULL,NULL,3,24,36,'gsu',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (259,23,'zm','Kontaktaufnahme',NULL,'INT',NULL,NULL,3,24,34,'zm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (260,23,'ba0','Beratungsanlass 0',NULL,'INT',NULL,NULL,3,24,37,'ba0',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (261,23,'ba1','Beratungsanlass 1',NULL,'INT',NULL,NULL,3,24,38,'ba1',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (262,23,'ba2','Beratungsanlass 2',NULL,'INT',NULL,NULL,3,24,39,'ba2',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (263,23,'ba3','Beratungsanlass 3',NULL,'INT',NULL,NULL,3,24,40,'ba3',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (264,23,'ba4','Beratungsanlass 4',NULL,'INT',NULL,NULL,3,24,41,'ba4',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (265,23,'ba5','Beratungsanlass 5',NULL,'INT',NULL,NULL,3,24,42,'ba5',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (266,23,'ba6','Beratungsanlass 6',NULL,'INT',NULL,NULL,3,24,43,'ba6',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (267,23,'ba7','Beratungsanlass 7',NULL,'INT',NULL,NULL,3,24,44,'ba7',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (268,23,'ba8','Beratungsanlass 8',NULL,'INT',NULL,NULL,3,24,45,'ba8',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (269,23,'ba9','Beratungsanlass 9',NULL,'INT',NULL,NULL,3,24,46,'ba9',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (270,23,'schw','Beratungsschwerpunkt',NULL,'INT',NULL,NULL,3,24,47,'schw',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (271,23,'fbe0','Beratung Kind',NULL,'INT',NULL,NULL,3,24,48,'fbe0',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (272,23,'fbe1','Beratung Eltern',NULL,'INT',NULL,NULL,3,24,49,'fbe1',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (273,23,'fbe2','Beratung Familie',NULL,'INT',NULL,NULL,3,24,50,'fbe2',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (274,23,'fbe3','Beratung Umfeld',NULL,'INT',NULL,NULL,3,24,51,'fbe3',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (275,23,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (276,24,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (277,24,'kat_id','Kategorienid','codes','INT',NULL,NULL,2,25,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (278,24,'kat_code','Kategoriencode',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (279,24,'code','Code',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (280,24,'name','Name',NULL,'CHAR(160)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (281,24,'sort','Sortierreihenfolge',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (282,24,'mini','Bereichsminimum',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (283,24,'maxi','Bereichsmaximum',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (284,24,'off','Ung�ltig',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (285,24,'dm','Ung�ltig ab Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (286,24,'dy','Ung�ltig ab Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (287,24,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (288,24,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (289,25,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (290,25,'code','Code',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (291,25,'name','Name',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (292,25,'kat_id','Kategorienart','kategorien','INT',NULL,NULL,2,25,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (293,25,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (294,25,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (295,26,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (296,26,'mit_id','Mitarbeiterid','','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (297,26,'zeit','Exportzeitpunkt',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (298,26,'dbsite','Datenbanksite',NULL,'INT',NULL,NULL,3,24,58,'dbsite',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (299,27,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (300,27,'exp_id','Exportprotokollid','importprotokolle','INT',NULL,NULL,2,26,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (301,27,'mit_id','Mitarbeiterid','','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (302,27,'zeit','Importzeitpunkt',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (303,27,'dbsite','Datenbanksite',NULL,'INT',NULL,NULL,3,24,58,'dbsite',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (304,28,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (305,28,'tab_id','Tabelle','felder','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (306,28,'feld','Feldname',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (307,28,'name','Langname des Feldes',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (308,28,'inverse','Name f�r inverse Beziehung',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (309,28,'typ','Datenbanktyp',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (310,28,'laenge','Feldl�nge',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (311,28,'notnull','Nicht NULL',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (312,28,'verwtyp','Verwendungstyp',NULL,'INT',NULL,NULL,3,24,1,'verwtyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (313,28,'ftab_id','Fremdtabelle','inverse','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (314,28,'kat_id','Kategorienid','','INT',NULL,NULL,2,25,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (315,28,'kat_code','Kategoriencode',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (316,28,'flag','Flags',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (317,28,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (318,29,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (319,29,'tabelle','Tabellenname',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (320,29,'name','Langname der Tabelle',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (321,29,'klasse','Klassenname',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (322,29,'flag','Flags',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (323,29,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (324,30,'table_id','Tabellenid','iddaten','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (325,30,'table_name','Tabellenname',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (326,30,'dbsite','Datenbanksite',NULL,'INT',NULL,NULL,3,24,58,'dbsite',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (327,30,'minid','Minimale ID',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (328,30,'maxid','Maximale ID',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (329,30,'maxist','Maximale verwendete ID',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (330,31,'tab_id','Tabelle','schluessel','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (331,31,'feld_id','Feld','schluessel','INT',NULL,NULL,2,28,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (332,31,'seq','Laufende Nummer',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);

--
-- Table structure for table 'gruppe'
--

CREATE TABLE gruppe (
  id int(11) default NULL,
  gn char(20) default NULL,
  name char(255) default NULL,
  thema char(255) default NULL,
  tzahl int(11) default NULL,
  stzahl int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  teiln int(11) default NULL,
  grtyp int(11) default NULL,
  stz int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'gruppe'
--



--
-- Table structure for table 'gruppendokument'
--

CREATE TABLE gruppendokument (
  id int(11) default NULL,
  gruppe_id int(11) default NULL,
  mit_id int(11) default NULL,
  betr varchar(254) default NULL,
  fname varchar(254) default NULL,
  art int(11) default NULL,
  vd int(11) default NULL,
  vm int(11) default NULL,
  vy int(11) default NULL,
  mtyp int(11) default NULL,
  dok blob,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'gruppendokument'
--



--
-- Table structure for table 'importprotokoll'
--

CREATE TABLE importprotokoll (
  id int(11) default NULL,
  exp_id int(11) default NULL,
  mit_id int(11) default NULL,
  zeit int(11) default NULL,
  dbsite int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'importprotokoll'
--



--
-- Table structure for table 'jghstat'
--

CREATE TABLE jghstat (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  fall_fn char(20) default NULL,
  gfall int(11) default NULL,
  bezirksnr int(11) default NULL,
  stz int(11) default NULL,
  rbz int(11) default NULL,
  kr int(11) default NULL,
  gm int(11) default NULL,
  gmt int(11) default NULL,
  lnr int(11) default NULL,
  traeg int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  bgr int(11) default NULL,
  gs int(11) default NULL,
  ag int(11) default NULL,
  fs int(11) default NULL,
  hke int(11) default NULL,
  gsa int(11) default NULL,
  gsu int(11) default NULL,
  zm int(11) default NULL,
  ba0 int(11) default NULL,
  ba1 int(11) default NULL,
  ba2 int(11) default NULL,
  ba3 int(11) default NULL,
  ba4 int(11) default NULL,
  ba5 int(11) default NULL,
  ba6 int(11) default NULL,
  ba7 int(11) default NULL,
  ba8 int(11) default NULL,
  ba9 int(11) default NULL,
  schw int(11) default NULL,
  fbe0 int(11) default NULL,
  fbe1 int(11) default NULL,
  fbe2 int(11) default NULL,
  fbe3 int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'jghstat'
--



--
-- Table structure for table 'kategorie'
--

CREATE TABLE kategorie (
  id int(11) default NULL,
  code char(8) default NULL,
  name char(60) default NULL,
  kat_id int(11) default NULL,
  dok char(255) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'kategorie'
--


INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (1,'verwtyp','Feldverwendungstyp',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (2,'fsag','Altersgruppe Kind/Jugendliche',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (3,'fsagel','Altersgruppe Eltern',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (4,'fsfs','Lebensmittelpunkt des Kindes',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (5,'fszm','Zugangsweg',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (6,'fsba','Vorstellungsanlass bei der Anmeldung',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (7,'fsbe','Beruf der Eltern',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (8,'fshe','Herkunftsland der Eltern',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (9,'fspbe','Problemspektrum Eltern',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (10,'fspbk','Problemspektrum Kind, Jugendliche',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (11,'fsle','Erbrachte Leistungen',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (12,'fskat','Anzahl der Termine',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (13,'fsqualij','sozialer Status Jugendlicher, 14-27',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (14,'fsquali','Qualifikation der Eltern',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (15,'klerv','Verwandtschaftsgrad',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (16,'klinsta','Einrichtungskontakt',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (17,'status','Mitarbeiterstatus',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (18,'stzei','Dienststelle',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (19,'benr','Benutzungsrecht',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (20,'stand','Bearbeitungsstand',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (21,'notizbed','Notizbedeutung',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (22,'vert','im Verteiler',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (23,'einrstat','Aktueller Kontakt',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (24,'rbz','Regierungsbezirk',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (25,'kr','Kreis',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (26,'gm','Gemeinde',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (27,'gmt','Gemeindeteil',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (28,'traeg','Jugendhilfe-Tr�ger',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (29,'bgr','Beendigungsgrund',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (30,'gs','Geschlecht',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (31,'ag','Alter',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (32,'fs','Junger Mensch lebt bei',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (33,'hke','Staatsangeh�rigkeit',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (34,'zm','1. Kontakt durch',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (35,'gsa','Geschwisteranzahl',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (36,'gsu','Kenntnis der Geschwisterzahl',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (37,'ba0','Beratungsanlass 0',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (38,'ba1','Beratungsanlass 1',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (39,'ba2','Beratungsanlass 2',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (40,'ba3','Beratungsanlass 3',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (41,'ba4','Beratungsanlass 4',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (42,'ba5','Beratungsanlass 5',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (43,'ba6','Beratungsanlass 6',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (44,'ba7','Beratungsanlass 7',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (45,'ba8','Beratungsanlass 8',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (46,'ba9','Beratungsanlass 9',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (47,'schw','Beratungsschwerpunkt',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (48,'fbe0','beim jungen Menschen',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (49,'fbe1','bei den Eltern',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (50,'fbe2','in der Familie',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (51,'fbe3','im sozialen Umfeld',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (52,'mimetyp','Mime Typ',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (53,'dokart','Der Eintrag ist',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (54,'teiln','Teilnehmer/innnen',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (55,'grtyp','Gruppentyp',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (56,'gfall','Geschwisterfall',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (57,'wohnbez','Wohnbezirksnr des Klienten',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (58,'dbsite','Datenbank-Site',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (59,'lage','Lage innerhalb oder au�erhalb des Geltungsbereichs des Stra�',NULL,NULL,1093707918);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (60,'config','Konfigurationseinstellungen',NULL,NULL,1093707918);

--
-- Table structure for table 'leistung'
--

CREATE TABLE leistung (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  le int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  stz int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'leistung'
--



--
-- Table structure for table 'mitarbeiter'
--

CREATE TABLE mitarbeiter (
  id int(11) default NULL,
  vn char(35) default NULL,
  na char(35) default NULL,
  ben char(25) default NULL,
  anr char(20) default NULL,
  tl1 char(25) default NULL,
  fax char(25) default NULL,
  mail char(50) default NULL,
  stat int(11) default NULL,
  benr int(11) default NULL,
  stz int(11) default NULL,
  zeit int(11) default NULL,
  pass char(50) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'mitarbeiter'
--


INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (1,'Admin','Administrator','Admin',NULL,NULL,NULL,NULL,203,206,205,1093707925,'4e7afebcfbae000b22c7c85e5560f89a2a0280b4');

--
-- Table structure for table 'mitarbeitergruppe'
--

CREATE TABLE mitarbeitergruppe (
  id int(11) default NULL,
  mit_id int(11) default NULL,
  gruppe_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'mitarbeitergruppe'
--



--
-- Table structure for table 'mitstelle'
--

CREATE TABLE mitstelle (
  mit_id int(11) default NULL,
  stz int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'mitstelle'
--



--
-- Table structure for table 'protokoll'
--

CREATE TABLE protokoll (
  nr int(11) default NULL,
  zeit varchar(17) default NULL,
  artdeszugriffs longtext,
  benutzerkennung varchar(25) default NULL,
  ipadresse varchar(25) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'protokoll'
--



--
-- Table structure for table 'schluessel'
--

CREATE TABLE schluessel (
  tab_id int(11) default NULL,
  feld_id int(11) default NULL,
  seq int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'schluessel'
--



--
-- Table structure for table 'sessions'
--

CREATE TABLE sessions (
  session_id char(50) default NULL,
  time char(16) default NULL,
  user_name char(25) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'sessions'
--



--
-- Table structure for table 'strassenkat'
--

CREATE TABLE strassenkat (
  str_nummer char(5) default NULL,
  str_name char(60) default NULL,
  hausnr char(4) default NULL,
  bezirk int(11) default NULL,
  plz int(11) default NULL,
  Plraum char(4) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'strassenkat'
--



--
-- Table structure for table 'tabelle'
--

CREATE TABLE tabelle (
  id int(11) default NULL,
  tabelle char(30) default NULL,
  name char(60) default NULL,
  klasse char(60) default NULL,
  flag int(11) default NULL,
  dok char(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'tabelle'
--


INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (1,'mitarbeiter','Mitarbeiter','Mitarbeiter',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (2,'protokoll','Protokoll','Protokoll',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (3,'strassenkat','Strassenkatalog','Strassenkatalog',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (4,'sessions','Session','Session',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (5,'mitstelle','Zuordnung Mitarbeiter-Dienststelle','MitarbeiterDienststelle',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (6,'akte','Akte','Akte',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (7,'fall','Fall','Fall',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (8,'anmeldung','Anmeldung','Anmeldung',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (9,'bezugsperson','Bezugsperson','Bezugsperson',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (10,'einrichtung','Kontakt mit Einrichtung','Einrichtungskontakt',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (11,'leistung','Leistung','Leistung',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (12,'zustaendigkeit','Zust�ndigkeit','Zustaendigkeit',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (13,'dokument','Dokument','Dokument',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (14,'gruppendokument','Zuordnung Gruppe-Dokument','Gruppendokument',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (15,'gruppe','Gruppe','Gruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (16,'fallgruppe','Zuordnung Fall-Gruppe','FallGruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (17,'bezugspersongruppe','Zuordnung Bezugsperson-Gruppe','BezugspersonGruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (18,'mitarbeitergruppe','Zuordnung Mitarbeiter-Gruppe','MitarbeiterGruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (19,'fachstat','Fachstatistik','Fachstatistik',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (20,'fachstatlei','Zuordnung Fachstatistik-Leistung','Fachstatistikleistung',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (21,'fachstatkindproblem','Zuordnung Fachstatistik-Problemspektrum Kind','Fachstatistikkindproblem',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (22,'fachstatelternproblem','Zuordnung Fachstatistik-Problemspektrum Eltern','Fachstatistikelternproblem',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (23,'jghstat','Jugendhilfestatistik','Jugendhilfestatistik',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (24,'code','Code','Code',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (25,'kategorie','Kategorie','Kategorie',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (26,'exportprotokoll','DB Exportprotokoll','Exportprotokoll',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (27,'importprotokoll','DB Importprotokoll','Importprotokoll',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (28,'feld','Feld','Feld',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (29,'tabelle','Tabelle','Tabelle',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (30,'tabid','Zuordnung Tabelle-ID-Bereiche','TabellenID',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (31,'schluessel','Schl�ssel','Schluessel',0,NULL);

--
-- Table structure for table 'tabid'
--

CREATE TABLE tabid (
  table_id int(11) default NULL,
  table_name char(30) default NULL,
  dbsite int(11) default NULL,
  minid int(11) default NULL,
  maxid int(11) default NULL,
  maxist int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'tabid'
--


INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (1,'mitarbeiter',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (2,'protokoll',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (4,'sessions',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (6,'akte',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (7,'fall',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (8,'anmeldung',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (9,'bezugsperson',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (10,'einrichtung',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (11,'leistung',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (12,'zustaendigkeit',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (13,'dokument',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (14,'gruppendokument',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (15,'gruppe',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (16,'fallgruppe',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (17,'bezugspersongruppe',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (18,'mitarbeitergruppe',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (19,'fachstat',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (20,'fachstatlei',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (21,'fachstatkindproblem',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (22,'fachstatelternproblem',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (23,'jghstat',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (24,'code',360,1,1000000000,364);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (25,'kategorie',360,1,1000000000,60);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (26,'exportprotokoll',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (27,'importprotokoll',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (28,'feld',360,1,1000000000,332);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (29,'tabelle',360,1,1000000000,31);

--
-- Table structure for table 'zustaendigkeit'
--

CREATE TABLE zustaendigkeit (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'zustaendigkeit'
--



