-- MySQL dump 8.22
--
-- Host: localhost    Database: demo_XX_init_XX
---------------------------------------------------------
-- Server version	3.23.55-Max-log

--
-- Table structure for table 'akte'
--

CREATE TABLE akte (
  id int(11) default NULL,
  vn char(35) default NULL,
  na char(35) default NULL,
  gb char(10) default NULL,
  ber char(30) default NULL,
  str char(35) default NULL,
  hsnr char(5) default NULL,
  plz char(9) default NULL,
  planungsr char(4) default NULL,
  wohnbez int(11) default NULL,
  lage int(11) default NULL,
  ort char(35) default NULL,
  tl1 char(25) default NULL,
  tl2 char(25) default NULL,
  fs int(11) default NULL,
  no char(255) default NULL,
  stzbg int(11) default NULL,
  stzak int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'akte'
--


INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (2,'Klient2Vn','Klient2Na','24.08.1985','Ausbildung von Nr.: 2',NULL,NULL,NULL,'9999',359,363,'Gro�-Lehnau','45152791','',38,'Das sind alles Beispieldaten f�r Form 2',205,205,1097425408);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (3,'Klient3Vn','Klient3Na','27.05.1999','Ausbildung von Nr.: 3','M�llerstr.','287','21127','0063',358,362,'Unterhausen','20262353','',28,'Das sind alles Beispieldaten f�r Form 3',365,365,1097425411);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (4,'Klient4Vn','Klient4Na','27.06.1989','Ausbildung von Nr.: 4','Rosenweg','222','96567','0063',358,362,'Klein-Magrau','11868420','',38,'Das sind alles Beispieldaten f�r Form 4',365,365,1097425420);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (5,'Klient5Vn','Klient5Na','15.07.1992','Ausbildung von Nr.: 5','Rosenweg','10','57921','0061',358,362,'Unterhausen','32742585','',39,'Das sind alles Beispieldaten f�r Form 5',365,365,1097425427);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (6,'Klient6Vn','Klient6Na','13.05.1989','Ausbildung von Nr.: 6','Teichweg','162','97670','0060',358,362,'Gro�-Lehnau','79332804','',33,'Das sind alles Beispieldaten f�r Form 6',365,365,1097425433);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (7,'Klient7Vn','Klient7Na','07.12.1997','Ausbildung von Nr.: 7','Teichweg','208','99046','0061',358,362,'Gro�-Lehnau','3710542','',35,'Das sind alles Beispieldaten f�r Form 7',205,205,1097425441);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (8,'Klient8Vn','Klient8Na','04.02.1996','Ausbildung von Nr.: 8','Am Rott','164','82761','0063',358,362,'Unterhausen','11543101','',35,'Das sind alles Beispieldaten f�r Form 8',365,365,1097425449);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (9,'Klient9Vn','Klient9Na','14.05.2000','Ausbildung von Nr.: 9','Hinterm Markt','22','28896','0062',358,362,'Klein-Magrau','41218686','',39,'Das sind alles Beispieldaten f�r Form 9',365,365,1097425466);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (10,'Klient10Vn','Klient10Na','18.02.2002','Ausbildung von Nr.: 10','Rosenweg','181','39503','0062',358,362,'Klein-Magrau','64627721','',27,'Das sind alles Beispieldaten f�r Form 10',365,365,1097425480);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (11,'Klient11Vn','Klient11Na','16.02.1995','Ausbildung von Nr.: 11','Am Rott','284','59454','0061',358,362,'Unterhausen','15864072','',39,'Das sind alles Beispieldaten f�r Form 11',365,365,1097425482);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (12,'Klient12Vn','Klient12Na','09.08.1990','Ausbildung von Nr.: 12','Am Rott','22','37381','0063',358,362,'Unterhausen','66891899','',29,'Das sind alles Beispieldaten f�r Form 12',205,205,1097425490);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (13,'Klient13Vn','Klient13Na','03.09.1998','Ausbildung von Nr.: 13','Am Rott','258','60997','0062',358,362,'Klein-Magrau','57894471','',36,'Das sind alles Beispieldaten f�r Form 13',365,365,1097425498);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (14,'Klient14Vn','Klient14Na','16.09.2002','Ausbildung von Nr.: 14','Karl-Marx-Str.','190','85756','0060',358,362,'Gro�-Lehnau','14733861','',36,'Das sind alles Beispieldaten f�r Form 14',365,365,1097425507);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (15,'Klient15Vn','Klient15Na','13.11.1982','Ausbildung von Nr.: 15','Am Rott','31','71200','0062',358,362,'Klein-Magrau','75836077','',32,'Das sind alles Beispieldaten f�r Form 15',205,205,1097425515);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (16,'Klient16Vn','Klient16Na','04.12.1993','Ausbildung von Nr.: 16','Am Rott','121','18347','0061',358,362,'Gro�-Lehnau','49035573','',27,'Das sind alles Beispieldaten f�r Form 16',205,205,1097425524);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (17,'Klient17Vn','Klient17Na','17.07.1998','Ausbildung von Nr.: 17','Teichweg','218','66079','0062',358,362,'Gro�-Lehnau','27735006','',33,'Das sind alles Beispieldaten f�r Form 17',365,365,1097425531);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (18,'Klient18Vn','Klient18Na','22.05.2002','Ausbildung von Nr.: 18','Karl-Marx-Str.','111','33448','0063',358,362,'Unterhausen','96850409','',32,'Das sind alles Beispieldaten f�r Form 18',365,365,1097425540);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (19,'Klient19Vn','Klient19Na','13.07.1986','Ausbildung von Nr.: 19','M�llerstr.','229','34553','0062',358,362,'Klein-Magrau','46396214','',32,'Das sind alles Beispieldaten f�r Form 19',205,205,1097425555);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (20,'Klient20Vn','Klient20Na','23.04.2000','Ausbildung von Nr.: 20','Teichweg','7','28351','0063',358,362,'Klein-Magrau','88590521','',32,'Das sind alles Beispieldaten f�r Form 20',365,365,1097425562);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (21,'Klient21Vn','Klient21Na','28.08.1986','Ausbildung von Nr.: 21','Teichweg','85','56964','0062',358,362,'Unterhausen','62206978','',33,'Das sind alles Beispieldaten f�r Form 21',365,365,1097425572);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (22,'Klient22Vn','Klient22Na','17.01.1994','Ausbildung von Nr.: 22','Teichweg','34','69327','0060',358,362,'Gro�-Lehnau','31807901','',35,'Das sind alles Beispieldaten f�r Form 22',205,205,1097425579);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (23,'Klient23Vn','Klient23Na','08.07.1992','Ausbildung von Nr.: 23','Hinterm Markt','39','74751','0062',358,362,'Klein-Magrau','93805343','',31,'Das sind alles Beispieldaten f�r Form 23',365,365,1097425589);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (24,'Klient24Vn','Klient24Na','08.06.1999','Ausbildung von Nr.: 24','Am Rott','170','41098','0062',358,362,'Klein-Magrau','91892368','',27,'Das sind alles Beispieldaten f�r Form 24',365,365,1097425592);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (25,'Klient25Vn','Klient25Na','09.07.1995','Ausbildung von Nr.: 25','Am Rott','23','63039','0061',358,362,'Unterhausen','2097019','',36,'Das sind alles Beispieldaten f�r Form 25',365,365,1097425599);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (26,'Klient26Vn','Klient26Na','11.10.2000','Ausbildung von Nr.: 26','Hinterm Markt','235','91529','0062',358,362,'Unterhausen','80776891','',27,'Das sind alles Beispieldaten f�r Form 26',205,205,1097425605);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (27,'Klient27Vn','Klient27Na','08.03.1996','Ausbildung von Nr.: 27','Am Rott','162','43203','0063',358,362,'Unterhausen','5156573','',33,'Das sind alles Beispieldaten f�r Form 27',365,365,1097425613);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (28,'Klient28Vn','Klient28Na','12.10.2001','Ausbildung von Nr.: 28','Am Rott','153','94532','0061',358,362,'Klein-Magrau','74012137','',31,'Das sind alles Beispieldaten f�r Form 28',365,365,1097425628);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (29,'Klient29Vn','Klient29Na','10.04.1995','Ausbildung von Nr.: 29','M�llerstr.','225','62771','0061',358,362,'Unterhausen','91203273','',35,'Das sind alles Beispieldaten f�r Form 29',365,365,1097425638);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (30,'Klient30Vn','Klient30Na','19.10.1996','Ausbildung von Nr.: 30','M�llerstr.','198','86553','0061',358,362,'Gro�-Lehnau','84906810','',30,'Das sind alles Beispieldaten f�r Form 30',365,365,1097425646);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (31,'Klient31Vn','Klient31Na','19.10.1998','Ausbildung von Nr.: 31','Karl-Marx-Str.','234','88759','0060',358,362,'Gro�-Lehnau','69932785','',31,'Das sind alles Beispieldaten f�r Form 31',205,205,1097425650);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (32,'Klient32Vn','Klient32Na','08.07.2002','Ausbildung von Nr.: 32','Teichweg','9','35987','0061',358,362,'Unterhausen','16057816','',32,'Das sind alles Beispieldaten f�r Form 32',205,205,1097425657);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (33,'Klient33Vn','Klient33Na','01.06.1993','Ausbildung von Nr.: 33','Hinterm Markt','288','18368','0063',358,362,'Klein-Magrau','29905694','',36,'Das sind alles Beispieldaten f�r Form 33',205,205,1097425665);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (34,'Klient34Vn','Klient34Na','27.02.1983','Ausbildung von Nr.: 34',NULL,NULL,NULL,'9999',359,363,'Gro�-Lehnau','91964427','',33,'Das sind alles Beispieldaten f�r Form 34',205,205,1097425681);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (35,'Klient35Vn','Klient35Na','03.03.1992','Ausbildung von Nr.: 35','Teichweg','240','35780','0062',358,362,'Unterhausen','66366882','',30,'Das sind alles Beispieldaten f�r Form 35',365,365,1097425683);
INSERT INTO akte (id, vn, na, gb, ber, str, hsnr, plz, planungsr, wohnbez, lage, ort, tl1, tl2, fs, no, stzbg, stzak, zeit) VALUES (36,'Klient36Vn','Klient36Na','03.09.1990','Ausbildung von Nr.: 36','Am Rott','184','57763','0062',358,362,'Klein-Magrau','31095985','',38,'Das sind alles Beispieldaten f�r Form 36',365,365,1097425691);

--
-- Table structure for table 'anmeldung'
--

CREATE TABLE anmeldung (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  von char(35) default NULL,
  ad int(11) default NULL,
  am int(11) default NULL,
  ay int(11) default NULL,
  mtl char(25) default NULL,
  me char(35) default NULL,
  zm int(11) default NULL,
  mg char(255) default NULL,
  no char(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'anmeldung'
--



--
-- Table structure for table 'bezugsperson'
--

CREATE TABLE bezugsperson (
  id int(11) default NULL,
  akte_id int(11) default NULL,
  vn char(35) default NULL,
  na char(35) default NULL,
  gb char(10) default NULL,
  ber char(30) default NULL,
  str char(35) default NULL,
  hsnr char(5) default NULL,
  lage int(11) default NULL,
  plz char(9) default NULL,
  ort char(35) default NULL,
  tl1 char(25) default NULL,
  tl2 char(25) default NULL,
  fs int(11) default NULL,
  verw int(11) default NULL,
  no char(255) default NULL,
  nobed int(11) default NULL,
  vrt int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'bezugsperson'
--


INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (2,2,'Bezugsperson2Vn','Bezugsperson2Na','18.05.1928','Bezugsperson Beruf: 2','Rosenweg','105',362,'78585','Gro�-Lehnau','25092751','',35,165,'Notiz f�r Bezugsperson: 2',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (3,2,'Bezugsperson3Vn','Bezugsperson3Na','05.02.1921','Bezugsperson Beruf: 3','Am Rott','54',362,'65591','Gro�-Lehnau','82572013','',26,172,'Notiz f�r Bezugsperson: 3',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (4,3,'Bezugsperson4Vn','Bezugsperson4Na','21.05.1957','Bezugsperson Beruf: 4','M�llerstr.','46',362,'89533','Unterhausen','48259032','',31,165,'Notiz f�r Bezugsperson: 4',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (5,3,'Bezugsperson5Vn','Bezugsperson5Na','25.01.1920','Bezugsperson Beruf: 5','Teichweg','7',362,'99920','Klein-Magrau','45721837','',34,165,'Notiz f�r Bezugsperson: 5',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (6,3,'Bezugsperson6Vn','Bezugsperson6Na','08.04.1941','Bezugsperson Beruf: 6','Karl-Marx-Str.','41',362,'83397','Unterhausen','56029824','',37,165,'Notiz f�r Bezugsperson: 6',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (7,4,'Bezugsperson7Vn','Bezugsperson7Na','17.06.1971','Bezugsperson Beruf: 7','Hinterm Markt','240',362,'36220','Gro�-Lehnau','12802116','',38,161,'Notiz f�r Bezugsperson: 7',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (8,4,'Bezugsperson8Vn','Bezugsperson8Na','08.08.1961','Bezugsperson Beruf: 8','Am Rott','123',362,'88056','Gro�-Lehnau','58712311','',30,164,'Notiz f�r Bezugsperson: 8',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (9,5,'Bezugsperson9Vn','Bezugsperson9Na','04.12.1924','Bezugsperson Beruf: 9','Rosenweg','40',362,'83915','Klein-Magrau','24900699','',37,166,'Notiz f�r Bezugsperson: 9',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (10,5,'Bezugsperson10Vn','Bezugsperson10Na','05.12.1927','Bezugsperson Beruf: 10','Teichweg','254',362,'19050','Unterhausen','2411784','',27,172,'Notiz f�r Bezugsperson: 10',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (11,5,'Bezugsperson11Vn','Bezugsperson11Na','17.01.1911','Bezugsperson Beruf: 11','Teichweg','110',362,'45339','Gro�-Lehnau','16360747','',28,170,'Notiz f�r Bezugsperson: 11',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (12,6,'Bezugsperson12Vn','Bezugsperson12Na','01.09.1929','Bezugsperson Beruf: 12','Karl-Marx-Str.','58',362,'29238','Klein-Magrau','47518076','',33,169,'Notiz f�r Bezugsperson: 12',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (13,7,'Bezugsperson13Vn','Bezugsperson13Na','04.04.1970','Bezugsperson Beruf: 13','Karl-Marx-Str.','170',362,'33660','Unterhausen','24420481','',39,172,'Notiz f�r Bezugsperson: 13',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (14,7,'Bezugsperson14Vn','Bezugsperson14Na','16.11.1912','Bezugsperson Beruf: 14','Teichweg','79',362,'99367','Klein-Magrau','12121732','',39,171,'Notiz f�r Bezugsperson: 14',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (15,8,'Bezugsperson15Vn','Bezugsperson15Na','24.01.1974','Bezugsperson Beruf: 15','Teichweg','60',362,'48152','Gro�-Lehnau','25423591','',31,169,'Notiz f�r Bezugsperson: 15',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (16,8,'Bezugsperson16Vn','Bezugsperson16Na','24.06.1940','Bezugsperson Beruf: 16','Karl-Marx-Str.','36',362,'64602','Unterhausen','36646322','',38,164,'Notiz f�r Bezugsperson: 16',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (17,9,'Bezugsperson17Vn','Bezugsperson17Na','06.10.1983','Bezugsperson Beruf: 17','Teichweg','95',362,'23038','Unterhausen','75771465','',28,160,'Notiz f�r Bezugsperson: 17',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (18,9,'Bezugsperson18Vn','Bezugsperson18Na','23.04.1982','Bezugsperson Beruf: 18','Karl-Marx-Str.','25',362,'53509','Klein-Magrau','49941322','',38,161,'Notiz f�r Bezugsperson: 18',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (19,9,'Bezugsperson19Vn','Bezugsperson19Na','11.08.1972','Bezugsperson Beruf: 19','Rosenweg','169',362,'44630','Klein-Magrau','14491843','',27,160,'Notiz f�r Bezugsperson: 19',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (20,10,'Bezugsperson20Vn','Bezugsperson20Na','07.09.1977','Bezugsperson Beruf: 20','Am Rott','98',362,'43302','Klein-Magrau','68940635','',33,162,'Notiz f�r Bezugsperson: 20',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (21,10,'Bezugsperson21Vn','Bezugsperson21Na','17.04.1958','Bezugsperson Beruf: 21','Karl-Marx-Str.','153',362,'17417','Gro�-Lehnau','13744385','',35,163,'Notiz f�r Bezugsperson: 21',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (22,10,'Bezugsperson22Vn','Bezugsperson22Na','12.08.1930','Bezugsperson Beruf: 22','Hinterm Markt','2',362,'67297','Klein-Magrau','274754','',30,161,'Notiz f�r Bezugsperson: 22',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (23,11,'Bezugsperson23Vn','Bezugsperson23Na','05.08.1965','Bezugsperson Beruf: 23','Hinterm Markt','160',362,'52473','Klein-Magrau','28764934','',35,171,'Notiz f�r Bezugsperson: 23',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (24,11,'Bezugsperson24Vn','Bezugsperson24Na','21.03.1978','Bezugsperson Beruf: 24','Karl-Marx-Str.','68',362,'45751','Klein-Magrau','35339048','',28,167,'Notiz f�r Bezugsperson: 24',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (25,12,'Bezugsperson25Vn','Bezugsperson25Na','21.08.1982','Bezugsperson Beruf: 25','M�llerstr.','81',362,'64607','Gro�-Lehnau','98087663','',36,161,'Notiz f�r Bezugsperson: 25',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (26,13,'Bezugsperson26Vn','Bezugsperson26Na','28.11.1980','Bezugsperson Beruf: 26','Rosenweg','271',362,'76846','Unterhausen','63870336','',31,165,'Notiz f�r Bezugsperson: 26',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (27,14,'Bezugsperson27Vn','Bezugsperson27Na','26.01.1927','Bezugsperson Beruf: 27','Am Rott','43',362,'96286','Klein-Magrau','61586722','',29,162,'Notiz f�r Bezugsperson: 27',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (28,14,'Bezugsperson28Vn','Bezugsperson28Na','28.04.1981','Bezugsperson Beruf: 28','Am Rott','21',362,'26336','Gro�-Lehnau','71867275','',38,161,'Notiz f�r Bezugsperson: 28',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (29,14,'Bezugsperson29Vn','Bezugsperson29Na','03.03.1969','Bezugsperson Beruf: 29','Hinterm Markt','88',362,'91839','Klein-Magrau','74215854','',34,170,'Notiz f�r Bezugsperson: 29',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (30,15,'Bezugsperson30Vn','Bezugsperson30Na','11.09.1984','Bezugsperson Beruf: 30','Teichweg','12',362,'77600','Gro�-Lehnau','5450426','',29,170,'Notiz f�r Bezugsperson: 30',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (31,15,'Bezugsperson31Vn','Bezugsperson31Na','26.02.1915','Bezugsperson Beruf: 31','M�llerstr.','28',362,'68277','Gro�-Lehnau','84505944','',32,161,'Notiz f�r Bezugsperson: 31',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (32,16,'Bezugsperson32Vn','Bezugsperson32Na','06.09.1931','Bezugsperson Beruf: 32','Rosenweg','283',362,'97026','Gro�-Lehnau','33025980','',27,168,'Notiz f�r Bezugsperson: 32',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (33,17,'Bezugsperson33Vn','Bezugsperson33Na','24.09.1954','Bezugsperson Beruf: 33','Hinterm Markt','241',362,'49573','Unterhausen','38988201','',32,170,'Notiz f�r Bezugsperson: 33',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (34,17,'Bezugsperson34Vn','Bezugsperson34Na','10.03.1979','Bezugsperson Beruf: 34','Am Rott','271',362,'73713','Gro�-Lehnau','27833025','',28,165,'Notiz f�r Bezugsperson: 34',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (35,17,'Bezugsperson35Vn','Bezugsperson35Na','13.07.1982','Bezugsperson Beruf: 35','Rosenweg','88',362,'84380','Unterhausen','26768512','',28,161,'Notiz f�r Bezugsperson: 35',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (36,18,'Bezugsperson36Vn','Bezugsperson36Na','14.04.1926','Bezugsperson Beruf: 36','Teichweg','172',362,'35004','Unterhausen','58695007','',36,162,'Notiz f�r Bezugsperson: 36',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (37,18,'Bezugsperson37Vn','Bezugsperson37Na','26.07.1939','Bezugsperson Beruf: 37','Am Rott','88',362,'41193','Gro�-Lehnau','62236637','',30,165,'Notiz f�r Bezugsperson: 37',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (38,18,'Bezugsperson38Vn','Bezugsperson38Na','09.09.1918','Bezugsperson Beruf: 38','M�llerstr.','209',362,'49833','Klein-Magrau','20568498','',33,172,'Notiz f�r Bezugsperson: 38',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (39,19,'Bezugsperson39Vn','Bezugsperson39Na','13.04.1975','Bezugsperson Beruf: 39','Karl-Marx-Str.','282',362,'39590','Klein-Magrau','25401370','',31,172,'Notiz f�r Bezugsperson: 39',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (40,19,'Bezugsperson40Vn','Bezugsperson40Na','28.12.1924','Bezugsperson Beruf: 40','Am Rott','227',362,'85284','Unterhausen','7372468','',27,171,'Notiz f�r Bezugsperson: 40',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (41,19,'Bezugsperson41Vn','Bezugsperson41Na','08.11.1959','Bezugsperson Beruf: 41','Am Rott','157',362,'58225','Klein-Magrau','64742948','',31,166,'Notiz f�r Bezugsperson: 41',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (42,20,'Bezugsperson42Vn','Bezugsperson42Na','17.10.1921','Bezugsperson Beruf: 42','Rosenweg','191',362,'45620','Gro�-Lehnau','71940933','',31,168,'Notiz f�r Bezugsperson: 42',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (43,20,'Bezugsperson43Vn','Bezugsperson43Na','06.12.1975','Bezugsperson Beruf: 43','Karl-Marx-Str.','229',362,'46720','Unterhausen','40216159','',38,168,'Notiz f�r Bezugsperson: 43',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (44,21,'Bezugsperson44Vn','Bezugsperson44Na','17.12.1936','Bezugsperson Beruf: 44','Karl-Marx-Str.','260',362,'49669','Klein-Magrau','48823174','',38,161,'Notiz f�r Bezugsperson: 44',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (45,21,'Bezugsperson45Vn','Bezugsperson45Na','21.02.1919','Bezugsperson Beruf: 45','Karl-Marx-Str.','17',362,'88744','Gro�-Lehnau','61770798','',33,163,'Notiz f�r Bezugsperson: 45',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (46,22,'Bezugsperson46Vn','Bezugsperson46Na','13.06.1945','Bezugsperson Beruf: 46','M�llerstr.','175',362,'80577','Klein-Magrau','11389904','',36,168,'Notiz f�r Bezugsperson: 46',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (47,23,'Bezugsperson47Vn','Bezugsperson47Na','24.03.1958','Bezugsperson Beruf: 47','Am Rott','81',362,'38380','Unterhausen','96320444','',35,169,'Notiz f�r Bezugsperson: 47',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (48,24,'Bezugsperson48Vn','Bezugsperson48Na','15.10.1971','Bezugsperson Beruf: 48','Am Rott','3',362,'46316','Gro�-Lehnau','39656999','',28,160,'Notiz f�r Bezugsperson: 48',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (49,25,'Bezugsperson49Vn','Bezugsperson49Na','22.01.1924','Bezugsperson Beruf: 49','Rosenweg','207',362,'42671','Unterhausen','61252660','',30,167,'Notiz f�r Bezugsperson: 49',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (50,25,'Bezugsperson50Vn','Bezugsperson50Na','03.10.1953','Bezugsperson Beruf: 50','Rosenweg','115',362,'60532','Klein-Magrau','74332233','',27,165,'Notiz f�r Bezugsperson: 50',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (51,25,'Bezugsperson51Vn','Bezugsperson51Na','19.04.1914','Bezugsperson Beruf: 51','Rosenweg','137',362,'78427','Unterhausen','28699331','',26,163,'Notiz f�r Bezugsperson: 51',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (52,26,'Bezugsperson52Vn','Bezugsperson52Na','02.10.1967','Bezugsperson Beruf: 52','Teichweg','64',362,'99032','Unterhausen','23816371','',34,172,'Notiz f�r Bezugsperson: 52',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (53,26,'Bezugsperson53Vn','Bezugsperson53Na','06.04.1930','Bezugsperson Beruf: 53','Karl-Marx-Str.','38',362,'92047','Unterhausen','91189855','',30,169,'Notiz f�r Bezugsperson: 53',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (54,27,'Bezugsperson54Vn','Bezugsperson54Na','15.11.1927','Bezugsperson Beruf: 54','Rosenweg','240',362,'58823','Klein-Magrau','14305818','',36,162,'Notiz f�r Bezugsperson: 54',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (55,27,'Bezugsperson55Vn','Bezugsperson55Na','16.09.1964','Bezugsperson Beruf: 55','Hinterm Markt','270',362,'28629','Klein-Magrau','52977939','',34,165,'Notiz f�r Bezugsperson: 55',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (56,27,'Bezugsperson56Vn','Bezugsperson56Na','13.04.1970','Bezugsperson Beruf: 56','Teichweg','237',362,'62036','Unterhausen','64315713','',34,168,'Notiz f�r Bezugsperson: 56',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (57,28,'Bezugsperson57Vn','Bezugsperson57Na','21.01.1979','Bezugsperson Beruf: 57','M�llerstr.','156',362,'96796','Klein-Magrau','34673160','',38,168,'Notiz f�r Bezugsperson: 57',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (58,28,'Bezugsperson58Vn','Bezugsperson58Na','26.07.1933','Bezugsperson Beruf: 58','Rosenweg','173',362,'66304','Klein-Magrau','91461535','',28,167,'Notiz f�r Bezugsperson: 58',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (59,28,'Bezugsperson59Vn','Bezugsperson59Na','10.01.1928','Bezugsperson Beruf: 59','M�llerstr.','26',362,'70677','Unterhausen','93578896','',33,161,'Notiz f�r Bezugsperson: 59',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (60,29,'Bezugsperson60Vn','Bezugsperson60Na','13.06.1966','Bezugsperson Beruf: 60','M�llerstr.','260',362,'90229','Unterhausen','38070628','',30,160,'Notiz f�r Bezugsperson: 60',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (61,29,'Bezugsperson61Vn','Bezugsperson61Na','04.08.1981','Bezugsperson Beruf: 61','Hinterm Markt','271',362,'81788','Gro�-Lehnau','59127789','',34,167,'Notiz f�r Bezugsperson: 61',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (62,29,'Bezugsperson62Vn','Bezugsperson62Na','15.02.1971','Bezugsperson Beruf: 62','Rosenweg','119',362,'30437','Gro�-Lehnau','811232','',32,162,'Notiz f�r Bezugsperson: 62',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (63,30,'Bezugsperson63Vn','Bezugsperson63Na','05.06.1934','Bezugsperson Beruf: 63','Rosenweg','71',362,'64172','Unterhausen','56708895','',37,163,'Notiz f�r Bezugsperson: 63',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (64,30,'Bezugsperson64Vn','Bezugsperson64Na','09.11.1976','Bezugsperson Beruf: 64','Am Rott','251',362,'76626','Gro�-Lehnau','64570967','',39,165,'Notiz f�r Bezugsperson: 64',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (65,31,'Bezugsperson65Vn','Bezugsperson65Na','13.08.1966','Bezugsperson Beruf: 65','Am Rott','156',362,'48415','Unterhausen','13926170','',34,162,'Notiz f�r Bezugsperson: 65',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (66,31,'Bezugsperson66Vn','Bezugsperson66Na','28.11.1966','Bezugsperson Beruf: 66','Teichweg','62',362,'40307','Klein-Magrau','73041122','',34,172,'Notiz f�r Bezugsperson: 66',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (67,31,'Bezugsperson67Vn','Bezugsperson67Na','11.05.1933','Bezugsperson Beruf: 67','Rosenweg','195',362,'98703','Unterhausen','49669477','',27,166,'Notiz f�r Bezugsperson: 67',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (68,32,'Bezugsperson68Vn','Bezugsperson68Na','15.08.1953','Bezugsperson Beruf: 68','Teichweg','107',362,'58452','Klein-Magrau','36893160','',35,164,'Notiz f�r Bezugsperson: 68',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (69,33,'Bezugsperson69Vn','Bezugsperson69Na','25.10.1957','Bezugsperson Beruf: 69','Hinterm Markt','293',362,'90749','Unterhausen','2793668','',27,168,'Notiz f�r Bezugsperson: 69',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (70,33,'Bezugsperson70Vn','Bezugsperson70Na','16.01.1975','Bezugsperson Beruf: 70','Rosenweg','98',362,'93456','Klein-Magrau','62860845','',39,165,'Notiz f�r Bezugsperson: 70',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (71,33,'Bezugsperson71Vn','Bezugsperson71Na','22.05.1939','Bezugsperson Beruf: 71','Hinterm Markt','101',362,'75362','Klein-Magrau','69088007','',32,172,'Notiz f�r Bezugsperson: 71',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (72,34,'Bezugsperson72Vn','Bezugsperson72Na','01.12.1949','Bezugsperson Beruf: 72','M�llerstr.','232',362,'35872','Unterhausen','97189676','',31,160,'Notiz f�r Bezugsperson: 72',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (73,34,'Bezugsperson73Vn','Bezugsperson73Na','14.08.1962','Bezugsperson Beruf: 73','M�llerstr.','245',362,'27211','Klein-Magrau','30566266','',37,162,'Notiz f�r Bezugsperson: 73',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (74,34,'Bezugsperson74Vn','Bezugsperson74Na','20.02.1981','Bezugsperson Beruf: 74','Karl-Marx-Str.','27',362,'69842','Gro�-Lehnau','18826691','',32,169,'Notiz f�r Bezugsperson: 74',213,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (75,35,'Bezugsperson75Vn','Bezugsperson75Na','08.03.1917','Bezugsperson Beruf: 75','M�llerstr.','257',362,'38398','Klein-Magrau','71018693','',28,162,'Notiz f�r Bezugsperson: 75',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (76,35,'Bezugsperson76Vn','Bezugsperson76Na','10.04.1921','Bezugsperson Beruf: 76','Karl-Marx-Str.','121',362,'77446','Unterhausen','25420492','',30,165,'Notiz f�r Bezugsperson: 76',212,215);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (77,36,'Bezugsperson77Vn','Bezugsperson77Na','15.05.1912','Bezugsperson Beruf: 77','Rosenweg','15',362,'78863','Gro�-Lehnau','53853024','',38,171,'Notiz f�r Bezugsperson: 77',213,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (78,36,'Bezugsperson78Vn','Bezugsperson78Na','27.04.1950','Bezugsperson Beruf: 78','Hinterm Markt','121',362,'98864','Klein-Magrau','5717034','',35,172,'Notiz f�r Bezugsperson: 78',212,214);
INSERT INTO bezugsperson (id, akte_id, vn, na, gb, ber, str, hsnr, lage, plz, ort, tl1, tl2, fs, verw, no, nobed, vrt) VALUES (79,36,'Bezugsperson79Vn','Bezugsperson79Na','06.07.1913','Bezugsperson Beruf: 79','Teichweg','213',362,'98819','Gro�-Lehnau','82294109','',29,165,'Notiz f�r Bezugsperson: 79',213,215);

--
-- Table structure for table 'bezugspersongruppe'
--

CREATE TABLE bezugspersongruppe (
  id int(11) default NULL,
  bezugsp_id int(11) default NULL,
  gruppe_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'bezugspersongruppe'
--



--
-- Table structure for table 'code'
--

CREATE TABLE code (
  id int(11) default NULL,
  kat_id int(11) default NULL,
  kat_code char(8) default NULL,
  code char(8) default NULL,
  name char(160) default NULL,
  sort int(11) default NULL,
  mini int(11) default NULL,
  maxi int(11) default NULL,
  off int(11) default NULL,
  dm int(11) default NULL,
  dy int(11) default NULL,
  dok char(255) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'code'
--


INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (1,1,'verwtyp','s','Schl�ssel',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (2,1,'verwtyp','f','Fremdschl�ssel',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (3,1,'verwtyp','k','Kategorie',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (4,1,'verwtyp','b','Bereichskategorie',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (5,1,'verwtyp','p','Primitiv',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (6,30,'gs','1','m',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (7,30,'gs','2','w',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (8,2,'fsag','1','0-2',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (9,2,'fsag','2','3-5',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (10,2,'fsag','3','6-9',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (11,2,'fsag','4','10-13',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (12,2,'fsag','5','14-17',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (13,2,'fsag','6','18-20',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (14,2,'fsag','7','21-26',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (15,2,'fsag','8','vor d. Schw.',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (16,2,'fsag','9','pr�natal',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (17,2,'fsag','999','keine Angabe',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (18,3,'fsagel','1','bis 20',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (19,3,'fsagel','2','21-26',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (20,3,'fsagel','3','27-44',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (21,3,'fsagel','4','45-54',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (22,3,'fsagel','5','55-64',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (23,3,'fsagel','6','65-74',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (24,3,'fsagel','7','75-',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (25,3,'fsagel','999','keine Angabe',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (26,4,'fsfs','1','verheiratet, leibl. Eltern',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (27,4,'fsfs','2','unverheiratet, leibl. Eltern',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (28,4,'fsfs','3','wechselnd bei Km u. Kv',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (29,4,'fsfs','4','Elternteil u. Stiefelternteil',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (30,4,'fsfs','5','alleinerziehende Mutter',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (31,4,'fsfs','6','alleinerziehender Vater',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (32,4,'fsfs','7','Verwandte',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (33,4,'fsfs','8','Pflegefamilie',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (34,4,'fsfs','9','Adoptivfamilie',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (35,4,'fsfs','10','Heim',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (36,4,'fsfs','11','Wohngemeinschaft',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (37,4,'fsfs','12','eigene Wohnung',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (38,4,'fsfs','13','obdachlos',13,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (39,4,'fsfs','14','sonstige',14,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (40,4,'fsfs','999','keine Angabe',15,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (41,5,'fszm','1','ohne Empfehlung',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (42,5,'fszm','2','Klient/Bekannte',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (43,5,'fszm','3','ASD',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (44,5,'fszm','4','KJGD/KJPD',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (45,5,'fszm','5','Kita/Hort',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (46,5,'fszm','6','Schule',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (47,5,'fszm','7','Schulpsychologie',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (48,5,'fszm','8','Kinder-/Jugendbetreuung',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (49,5,'fszm','9','Medizinische Einrichtung',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (50,5,'fszm','10','Gericht',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (51,5,'fszm','11','�ffentlichkeitsarbeit',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (52,5,'fszm','12','Sonstige',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (53,5,'fszm','999','keine Angabe',13,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (54,6,'fsba','1','Entwicklungs-, Verhaltensauff. in d. Familie',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (55,6,'fsba','2','Entwicklungs-, Verhaltensauff. in d. Kita',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (56,6,'fsba','3','Entwicklungs-, Verhaltensauff. in d. Schule',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (57,6,'fsba','4','Entwicklungs-, Verhaltensauff. im sonst. Umfeld',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (58,6,'fsba','5','Entwickungs- , Verhaltensauff., sonstige',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (59,6,'fsba','6','Leistungsproblem in der Schule/Ausbildung',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (60,6,'fsba','7','Lebensproblem der Jugendlichen',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (61,6,'fsba','8','Abl�sungsproblem des Jugendlichen',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (62,6,'fsba','9','Krise der Jugendlichen',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (63,6,'fsba','10','sexueller Missbrauch',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (64,6,'fsba','11','�berforderung der Eltern',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (65,6,'fsba','12','Erziehungsunsicherheiten',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (66,6,'fsba','13','Familienkonflikt',13,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (67,6,'fsba','14','Paarkonflikt',14,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (68,6,'fsba','15','Trennungs- / Scheidungsproblem der Eltern',15,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (69,6,'fsba','16','Sorge- oder Umgangsrecht',16,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (70,6,'fsba','17','Begleiteter Umgang',17,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (71,6,'fsba','18','akute Krise des Ratsuchenden',18,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (72,6,'fsba','19','Begleitung vor u. nach Fremdunterbringung',19,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (73,6,'fsba','20','Stellungnahme KJHG-Psychotherapie',20,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (74,6,'fsba','21','Stellungnahme f�r anderen Dienst',21,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (75,6,'fsba','22','Gerichtsgutachten',22,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (76,6,'fsba','23','sonstiges',23,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (77,6,'fsba','999','keine Angabe',24,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (78,7,'fsbe','1','nicht berufst�tig',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (79,7,'fsbe','2','Vollzeit angestellt / ABM',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (80,7,'fsbe','3','Teilzeit angestellt / ABM',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (81,7,'fsbe','4','Schichtarbeit',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (82,7,'fsbe','5','selbst�ndig',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (83,7,'fsbe','6','arbeitslos',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (84,7,'fsbe','7','Sozialhilfe',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (85,7,'fsbe','8','berentet',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (86,7,'fsbe','9','in Ausbildung oder Umschulung',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (87,7,'fsbe','10','sonstige',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (88,7,'fsbe','999','keine Angabe',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (89,8,'fshe','1','Deutschland',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (90,8,'fshe','2','Europa',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (91,8,'fshe','3','Ost-Europa',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (92,8,'fshe','4','T�rkei',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (93,8,'fshe','5','arabische L�nder',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (94,8,'fshe','6','Schwarz-Afrika',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (95,8,'fshe','7','Asien',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (96,8,'fshe','8','Nordamerika',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (97,8,'fshe','9','Lateinamerika',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (98,8,'fshe','10','Australien',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (99,8,'fshe','11','andere L�nder',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (100,8,'fshe','999','keine Angabe',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (101,9,'fspbe','1','Krankheit, Behinderung',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (102,9,'fspbe','2','Alkohol-, Drogenkonsum',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (103,9,'fspbe','3','chronifizierte psychische Erkrankung',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (104,9,'fspbe','4','Opfer famili�rer Gewalt, sex. Missbrauchs',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (105,9,'fspbe','5','starke Traumatisierung (Krieg, Folter)',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (106,9,'fspbe','6','�berforderung',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (107,9,'fspbe','7','Isolation und Kontaktschwierigkeiten',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (108,9,'fspbe','8','Verschuldung',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (109,9,'fspbe','9','unzureichende Wohnverh�ltnisse',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (110,9,'fspbe','10','sonstige',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (111,9,'fspbe','999','keine Angabe',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (112,10,'fspbk','1','allg. Erziehungs-, Entwicklungsproblem',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (113,10,'fspbk','2','neurotische oder psychosomatische Reaktion',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (114,10,'fspbk','3','Vernachl�ssigung, Verwahrlosung',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (115,10,'fspbk','4','Opfer von Gewalt, Misshandlung',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (116,10,'fspbk','5','Sexueller Missbrauch (Opfer)',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (117,10,'fspbk','6','Alkohol-, Drogenkonsum',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (118,10,'fspbk','7','strafbares Verhalten',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (119,10,'fspbk','8','Schulleistungsproblem',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (120,10,'fspbk','9','Schulverweigerung',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (121,10,'fspbk','10','soziale Kontaktschwierigkeit, Isolation',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (122,10,'fspbk','11','aggressives Verhalten',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (123,10,'fspbk','12','Gewaltbereitschaft des Jugendlichen',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (124,10,'fspbk','13','berufliche Perspektive',13,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (125,10,'fspbk','14','Behinderung',14,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (126,10,'fspbk','15','Suizidgef�hrdung',15,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (127,10,'fspbk','16','Esst�rung',16,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (128,10,'fspbk','17','traumat. Verlust, Tod einer Bezugsperson',17,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (129,10,'fspbk','18','sonstige',18,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (130,10,'fspbk','999','keine Angabe',19,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (131,11,'fsle','1','Erziehungsberatung',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (132,11,'fsle','2','Trennungs-, Scheidungsberatung, Mediation, Umgangsberatung',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (133,11,'fsle','3','Begleiteter Umgang',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (134,11,'fsle','4','Familienberatung, -therapie',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (135,11,'fsle','5','Paarberatung, -therapie',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (136,11,'fsle','6','Einzelbetreuung / -therapie Kind',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (137,11,'fsle','7','Einzelbetreuung / -therapie Jugendlicher',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (138,11,'fsle','8','Einzelbetreuung / -therapie Erwachsener',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (139,11,'fsle','9','Gruppentherapie Kinder',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (140,11,'fsle','10','Gruppentherapie Jugendliche',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (141,11,'fsle','11','Gruppentherapie Erwachsene',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (142,11,'fsle','12','Arbeit im sozialen Umfeld',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (143,11,'fsle','13','spezieller Diagnostikauftrag',13,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (144,11,'fsle','14','Hilfeplanung, Hilfekonferenz',14,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (145,11,'fsle','15','fachliche Bescheinigung f�r Klienten',15,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (146,11,'fsle','16','Begleitung KJHG-Therapie',16,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (147,11,'fsle','17','Fachdienstliche Stellungnahme',17,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (148,11,'fsle','18','Gerichtsgutachten',18,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (149,11,'fsle','19','sonstige',19,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (150,11,'fsle','999','keine Angabe',20,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (151,12,'fskat','0','keine Angabe',1,0,0,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (152,12,'fskat','1','1-5',2,1,5,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (153,12,'fskat','2','6-10',3,6,10,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (154,12,'fskat','3','11-15',4,11,15,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (155,12,'fskat','4','16-20',5,16,20,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (156,12,'fskat','5','21-30',6,21,30,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (157,12,'fskat','6','31-40',7,31,40,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (158,12,'fskat','7','41-50',8,41,50,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (159,12,'fskat','8','mehr als 50',9,51,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (160,15,'klerv','1','Mutter',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (161,15,'klerv','2','Vater',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (162,15,'klerv','3','Geschwister',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (163,15,'klerv','4','Halbgeschw.',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (164,15,'klerv','5','Stiefmutter',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (165,15,'klerv','6','Stiefvater',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (166,15,'klerv','7','Grossmutter',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (167,15,'klerv','8','Grossvater',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (168,15,'klerv','9','verwandt',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (169,15,'klerv','10','Pflegemutter',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (170,15,'klerv','11','Pflegevater',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (171,15,'klerv','12','Adoptivmutter',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (172,15,'klerv','13','sonstige',13,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (173,15,'klerv','999','k. Angabe',14,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (174,16,'klinsta','1','ASD',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (175,16,'klinsta','2','KJGD/KJPD',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (176,16,'klinsta','3','Kita/Hort',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (177,16,'klinsta','4','Schule',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (178,16,'klinsta','5','Heim',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (179,16,'klinsta','6','Wohngemeinschaft',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (180,16,'klinsta','7','Freizeiteinr.',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (181,16,'klinsta','8','Arzt',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (182,16,'klinsta','9','Klinik',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (183,16,'klinsta','10','Gericht',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (184,16,'klinsta','11','Schulpsychologie',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (185,16,'klinsta','12','Sonstige',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (186,16,'klinsta','999','keine Angabe',13,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (187,13,'fsqualij','1','Schule',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (188,13,'fsqualij','2','Studium',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (189,13,'fsqualij','3','Lehre',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (190,13,'fsqualij','4','Arbeitslos',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (191,13,'fsqualij','5','berufst�tig',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (192,13,'fsqualij','5','Berufsf�rderung',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (193,13,'fsqualij','6','sonstige',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (194,13,'fsqualij','999','keine Angabe',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (195,14,'fsquali','1','Schule',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (196,14,'fsquali','2','ungelernt',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (197,14,'fsquali','3','Berufsausbildung',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (198,14,'fsquali','4','Facharbeiter',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (199,14,'fsquali','5','Hochschulabschluss',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (200,14,'fsquali','6','Umschulung',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (201,14,'fsquali','7','sonstige',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (202,14,'fsquali','999','keine Angabe',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (203,17,'status','i','im Dienst',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (204,17,'status','a','nicht im Dienst',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (205,18,'stzei','A','Stelle A',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (206,19,'benr','admin','Administrator',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (207,19,'benr','bearb','Fallbearbeiter',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (208,19,'benr','verw','Verwaltung',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (209,19,'benr','protokol','protokol',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (210,20,'stand','l','laufender Fall',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (211,20,'stand','zdA','zu den Akten',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (212,21,'notizbed','t','Notiz wichtig',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (213,21,'notizbed','f','Notiz',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (214,22,'vert','t','ist im Verteiler',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (215,22,'vert','f','nicht im Verteiler',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (216,23,'einrstat','ja','aktuelle Einrichtung',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (217,23,'einrstat','nein','fr�here Einrichtung',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (218,24,'rbz','0','Musterregierungsbezirk',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (219,25,'kr','01','Kreis1',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (220,25,'kr','02','Kreis2',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (221,25,'kr','03','Kreis3',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (222,26,'gm','000','N.N.',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (223,27,'gmt','000','N.N.',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (224,28,'traeg','1','Tr�ger der �ffentl. JGH',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (225,28,'traeg','2','Tr�ger der freien JGH',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (226,29,'bgr','1','Beratung wurde einvernehmlich beendet',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (227,29,'bgr','2','letzter Kontakt liegt mehr als 6 M. zur�ck',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (228,29,'bgr','3','Weiterverweisung',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (229,31,'ag','1','unter 3',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (230,31,'ag','2','3 - unter 6',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (231,31,'ag','3','6 - unter 9',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (232,31,'ag','4','9 - unter 12',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (233,31,'ag','5','12 - unter 15',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (234,31,'ag','6','15 - unter 18',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (235,31,'ag','7','18 - unter 21',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (236,31,'ag','8','21 - unter 24',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (237,31,'ag','9','24 - unter 27',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (238,32,'fs','01','bei Eltern',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (239,32,'fs','02','bei 1 Elternteil mit Stiefelternteil',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (240,32,'fs','03','bei alleinerziehendem Elternteil',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (241,32,'fs','04','bei Grosseltern, Verwandten',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (242,32,'fs','05','in einer Pflegestelle',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (243,32,'fs','06','in einem Heim',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (244,32,'fs','07','in einer Wohngemeinschaft',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (245,32,'fs','08','in eigener Wohnung',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (246,32,'fs','09','ohne feste Unterkunft',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (247,32,'fs','10','an unbekanntem Ort',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (248,33,'hke','1','deutsch',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (249,33,'hke','2','nicht-deutsch',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (250,33,'hke','3','unbekannt',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (251,35,'gsa','0','kein Geschwister',1,0,0,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (252,35,'gsa','1','1 Geschwister',2,1,1,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (253,35,'gsa','2','2 Geschwister',3,2,2,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (254,35,'gsa','3','3 Geschwister',4,3,3,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (255,35,'gsa','4','mehr als 3 Geschwister',5,4,20,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (256,36,'gsu','0','bekannt',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (257,36,'gsu','1','unbekannt',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (258,34,'zm','1','jungen Menschen selbst',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (259,34,'zm','2','Eltern gemeinsam',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (260,34,'zm','3','Mutter',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (261,34,'zm','4','Vater',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (262,34,'zm','5','soziale Dienste',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (263,34,'zm','6','Sonstige',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (264,37,'ba0','1','Entwicklungsauff�lligkeiten',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (265,37,'ba0','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (266,38,'ba1','1','Beziehungsprobleme',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (267,38,'ba1','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (268,39,'ba2','1','Schule-/Ausbildungsprobleme',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (269,39,'ba2','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (270,40,'ba3','1','Straftat d. Jugendl./jungen Vollj�hrigen',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (271,40,'ba3','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (272,41,'ba4','1','Suchtprobleme des jungen Menschen',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (273,41,'ba4','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (274,42,'ba5','1','Anzeichen f�r Kindesmisshandlung',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (275,42,'ba5','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (276,43,'ba6','1','Anzeichen f�r sexuellen Missbrauch',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (277,43,'ba6','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (278,44,'ba7','1','Trennung/Scheidung der Eltern',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (279,44,'ba7','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (280,45,'ba8','1','Wohnungsprobleme',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (281,45,'ba8','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (282,46,'ba9','1','sonstige Probleme in u. mit der Familie',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (283,46,'ba9','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (284,47,'schw','1','Erziehungs-/Familienberatung',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (285,47,'schw','2','Jugendberatung',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (286,47,'schw','3','Suchtberatung',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (287,48,'fbe0','1','allein',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (288,48,'fbe0','2','in der Gruppe',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (289,48,'fbe0','0','leer',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (290,49,'fbe1','1','allein',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (291,49,'fbe1','2','in der Gruppe',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (292,49,'fbe1','0','leer',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (293,50,'fbe2','1','in der Familie',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (294,50,'fbe2','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (295,51,'fbe3','1','im sozialen Umfeld',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (296,51,'fbe3','0','leer',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (297,52,'mimetyp','txt','text/plain',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (298,52,'mimetyp','asc','text/plain',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (299,52,'mimetyp','html','text/html',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (300,52,'mimetyp','htm','text/html',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (301,52,'mimetyp','pdf','application/pdf',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (302,52,'mimetyp','ps','application/postscript',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (303,52,'mimetyp','doc','application/msword',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (304,52,'mimetyp','dot','application/msword',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (305,52,'mimetyp','wrd','application/msword',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (306,52,'mimetyp','rtf','application/rtf',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (307,52,'mimetyp','xls','application/x-msexcel',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (308,52,'mimetyp','sdw','application/soffice',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (309,52,'mimetyp','sxw','application/soffice',13,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (310,52,'mimetyp','sdc','application/vnd.stardivision.calc',14,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (311,52,'mimetyp','zip','application/zip',15,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (312,52,'mimetyp','gtar','application/x-gtar',16,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (313,52,'mimetyp','tgz','application/x-gtar',17,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (314,52,'mimetyp','gz','application/x-gzip',18,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (315,52,'mimetyp','tar','application/x-tar',19,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (316,52,'mimetyp','rtx','text/richtext',20,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (317,52,'mimetyp','gif','image/gif',21,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (318,52,'mimetyp','jpg','image/jpeg',22,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (319,52,'mimetyp','jpeg','image/jpeg',23,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (320,52,'mimetyp','jpe','image/jpeg',24,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (321,52,'mimetyp','tiff','image/tiff',25,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (322,52,'mimetyp','tif','image/tiff',26,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (323,52,'mimetyp','png','image/png',27,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (324,52,'mimetyp','bmp','image/bmp',28,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (325,53,'dokart','bnotiz','Beraternotiz',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (326,53,'dokart','Vm','Vermerk',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (327,53,'dokart','anotiz','Aktennotiz',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (328,53,'dokart','Brief','Brief',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (329,53,'dokart','Prot','Protokoll',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (330,53,'dokart','Dok','Dokument',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (331,53,'dokart','Antrag','Antrag',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (332,53,'dokart','Bericht','Bericht',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (333,53,'dokart','Stellung','Stellungnahme',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (334,53,'dokart','Befund','Befunddokument',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (335,53,'dokart','Gutacht','Gutachten',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (336,53,'dokart','Beschein','Bescheinigung',12,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (337,53,'dokart','Sonstig','Sonstiges',13,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (338,54,'teiln','Kinder','Kinder',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (339,54,'teiln','Jugendl','Jugendliche',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (340,54,'teiln','Eltern','Eltern',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (341,54,'teiln','V�ter','V�ter',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (342,54,'teiln','M�tter','M�tter',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (343,54,'teiln','Altgem','Altersgemischt',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (344,54,'teiln','Familien','Familien',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (345,54,'teiln','Erzieher','ErzieherInnen',8,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (346,54,'teiln','Lehrer','Lehrer',9,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (347,54,'teiln','Paare','Paare',10,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (348,54,'teiln','sonstige','sonstige',11,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (349,55,'grtyp','Eabend','Elternabend',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (350,55,'grtyp','Kurs','Kurs',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (351,55,'grtyp','Therapie','Therapiegruppe',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (352,55,'grtyp','Seminar','Seminar',4,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (353,55,'grtyp','Selbster','Selbsterfahrung',5,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (354,55,'grtyp','Superv','Supervision',6,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (355,55,'grtyp','sonstige','sonstige',7,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (356,56,'gfall','1','Nein',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (357,56,'gfall','2','Ja',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (358,57,'wohnbez','13','ausserhalb',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (359,57,'wohnbez','999','keine Angabe',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (360,58,'dbsite','A','DBSite A',1,1,1000000000,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (361,59,'lage','0','innerhalb des Geltungsbereichs des Stra�enkatalogs',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (362,59,'lage','1','au�erhalb des Geltungsbereichs des Stra�enkatalogs',2,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (363,59,'lage','999','keine Angabe',3,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (364,60,'config','protocol','off',1,NULL,NULL,0,NULL,NULL,NULL,1097425384);
INSERT INTO code (id, kat_id, kat_code, code, name, sort, mini, maxi, off, dm, dy, dok, zeit) VALUES (365,18,'stzei','B','Stelle B',2,NULL,NULL,0,NULL,NULL,'',1097425396);

--
-- Table structure for table 'dokument'
--

CREATE TABLE dokument (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  betr varchar(255) default NULL,
  fname varchar(255) default NULL,
  art int(11) default NULL,
  vd int(11) default NULL,
  vm int(11) default NULL,
  vy int(11) default NULL,
  mtyp int(11) default NULL,
  dok blob,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'dokument'
--



--
-- Table structure for table 'einrichtung'
--

CREATE TABLE einrichtung (
  id int(11) default NULL,
  akte_id int(11) default NULL,
  na char(80) default NULL,
  tl1 char(25) default NULL,
  tl2 char(25) default NULL,
  insta int(11) default NULL,
  no char(255) default NULL,
  nobed int(11) default NULL,
  status int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'einrichtung'
--


INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (2,2,'Einrichtungsname2','97199064','',185,'Notiz f�r Bezugsperson: 2',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (3,4,'Einrichtungsname3','36058830','',176,'Notiz f�r Bezugsperson: 3',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (4,4,'Einrichtungsname4','52934368','',182,'Notiz f�r Bezugsperson: 4',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (5,7,'Einrichtungsname5','39690977','',182,'Notiz f�r Bezugsperson: 5',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (6,7,'Einrichtungsname6','67941946','',175,'Notiz f�r Bezugsperson: 6',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (7,10,'Einrichtungsname7','38380090','',183,'Notiz f�r Bezugsperson: 7',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (8,12,'Einrichtungsname8','1930891','',183,'Notiz f�r Bezugsperson: 8',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (9,13,'Einrichtungsname9','17374776','',185,'Notiz f�r Bezugsperson: 9',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (10,13,'Einrichtungsname10','62217248','',183,'Notiz f�r Bezugsperson: 10',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (11,14,'Einrichtungsname11','8138070','',185,'Notiz f�r Bezugsperson: 11',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (12,14,'Einrichtungsname12','39094953','',183,'Notiz f�r Bezugsperson: 12',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (13,15,'Einrichtungsname13','2561820','',178,'Notiz f�r Bezugsperson: 13',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (14,15,'Einrichtungsname14','55202792','',181,'Notiz f�r Bezugsperson: 14',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (15,16,'Einrichtungsname15','4638955','',184,'Notiz f�r Bezugsperson: 15',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (16,16,'Einrichtungsname16','35919287','',183,'Notiz f�r Bezugsperson: 16',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (17,17,'Einrichtungsname17','41541026','',181,'Notiz f�r Bezugsperson: 17',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (18,18,'Einrichtungsname18','4554434','',179,'Notiz f�r Bezugsperson: 18',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (19,19,'Einrichtungsname19','43115123','',176,'Notiz f�r Bezugsperson: 19',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (20,19,'Einrichtungsname20','77731435','',182,'Notiz f�r Bezugsperson: 20',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (21,21,'Einrichtungsname21','14041322','',176,'Notiz f�r Bezugsperson: 21',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (22,21,'Einrichtungsname22','73809448','',175,'Notiz f�r Bezugsperson: 22',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (23,22,'Einrichtungsname23','90951867','',180,'Notiz f�r Bezugsperson: 23',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (24,22,'Einrichtungsname24','67765469','',176,'Notiz f�r Bezugsperson: 24',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (25,24,'Einrichtungsname25','82352720','',176,'Notiz f�r Bezugsperson: 25',212,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (26,24,'Einrichtungsname26','64149125','',176,'Notiz f�r Bezugsperson: 26',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (27,27,'Einrichtungsname27','94891168','',180,'Notiz f�r Bezugsperson: 27',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (28,31,'Einrichtungsname28','80215612','',183,'Notiz f�r Bezugsperson: 28',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (29,31,'Einrichtungsname29','60511061','',181,'Notiz f�r Bezugsperson: 29',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (30,33,'Einrichtungsname30','40327133','',174,'Notiz f�r Bezugsperson: 30',213,217);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (31,34,'Einrichtungsname31','32952333','',184,'Notiz f�r Bezugsperson: 31',213,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (32,34,'Einrichtungsname32','6268446','',182,'Notiz f�r Bezugsperson: 32',212,216);
INSERT INTO einrichtung (id, akte_id, na, tl1, tl2, insta, no, nobed, status) VALUES (33,36,'Einrichtungsname33','81360010','',174,'Notiz f�r Bezugsperson: 33',213,217);

--
-- Table structure for table 'exportprotokoll'
--

CREATE TABLE exportprotokoll (
  id int(11) default NULL,
  mit_id int(11) default NULL,
  zeit int(11) default NULL,
  dbsite int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'exportprotokoll'
--



--
-- Table structure for table 'fachstat'
--

CREATE TABLE fachstat (
  id int(11) default NULL,
  mit_id int(11) default NULL,
  fall_id int(11) default NULL,
  fall_fn char(20) default NULL,
  jahr int(11) default NULL,
  stz int(11) default NULL,
  bz char(4) default NULL,
  gs int(11) default NULL,
  ag int(11) default NULL,
  fs int(11) default NULL,
  zm int(11) default NULL,
  qualij int(11) default NULL,
  hkm int(11) default NULL,
  hkv int(11) default NULL,
  bkm int(11) default NULL,
  bkv int(11) default NULL,
  qualikm int(11) default NULL,
  qualikv int(11) default NULL,
  agkm int(11) default NULL,
  agkv int(11) default NULL,
  ba1 int(11) default NULL,
  ba2 int(11) default NULL,
  pbe int(11) default NULL,
  pbk int(11) default NULL,
  kat int(11) default NULL,
  kkm int(11) default NULL,
  kkv int(11) default NULL,
  kki int(11) default NULL,
  kpa int(11) default NULL,
  kfa int(11) default NULL,
  ksoz int(11) default NULL,
  kleh int(11) default NULL,
  kerz int(11) default NULL,
  kkonf int(11) default NULL,
  kson int(11) default NULL,
  no char(255) default NULL,
  no2 char(255) default NULL,
  no3 char(255) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstat'
--


INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (2,5,2,'1-2002A',2002,205,'0060',7,11,29,51,190,96,95,82,80,201,201,24,23,73,55,103,128,29,1,8,6,2,0,3,5,4,0,0,'','','',1097425404);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (3,6,4,'1-2004B',2004,365,'0063',6,8,37,48,192,92,98,86,84,199,201,19,20,60,69,101,128,46,5,1,1,8,6,9,0,7,6,3,'','','',1097425415);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (4,5,5,'2-2004B',2004,365,'0063',7,12,36,42,192,95,97,87,79,195,196,24,20,61,62,101,124,49,9,1,4,9,8,2,5,3,3,5,'','','',1097425423);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (5,6,6,'3-2004B',2004,365,'0061',7,16,37,44,191,92,91,78,81,196,198,19,24,70,73,102,117,42,7,7,3,8,0,6,2,1,0,8,'','','',1097425430);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (6,6,7,'4-2004B',2004,365,'0060',7,16,28,52,192,90,95,87,79,196,201,18,23,68,59,105,126,37,2,7,3,1,4,2,4,8,2,4,'','','',1097425436);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (7,7,8,'2-2002A',2002,205,'0061',6,13,30,43,188,89,93,86,79,201,199,19,23,55,60,105,126,26,1,0,6,7,2,2,2,0,0,6,'','','',1097425445);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (8,5,9,'5-2004B',2004,365,'0063',7,10,26,51,187,94,91,85,79,197,198,19,23,74,66,109,116,44,4,0,6,2,3,9,8,8,2,2,'','','',1097425452);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (9,6,10,'1-2003B',2003,365,'0062',6,13,30,45,188,93,97,79,78,200,201,23,20,66,72,104,116,38,2,5,1,0,8,1,7,6,8,0,'','','',1097425460);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (10,5,11,'6-2004B',2004,365,'0062',6,8,29,45,193,95,92,82,82,195,200,21,18,67,61,102,128,31,0,3,5,1,1,5,3,1,4,8,'','','',1097425473);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (11,7,12,'2-2003B',2003,365,'0061',6,11,28,41,193,98,96,87,82,195,197,23,24,58,63,101,121,28,1,0,0,3,4,5,0,5,4,6,'','','',1097425486);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (12,6,13,'2-2004A',2004,205,'0063',6,13,39,49,187,97,98,85,84,196,198,18,22,65,59,110,117,39,8,5,2,0,3,3,8,4,0,6,'','','',1097425494);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (13,5,14,'7-2004B',2004,365,'0062',7,9,27,49,193,95,94,82,83,197,198,24,18,64,70,103,113,43,4,1,2,6,8,3,7,3,4,5,'','','',1097425501);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (14,7,15,'3-2003B',2003,365,'0060',6,10,34,51,187,94,99,78,83,197,199,23,21,71,62,101,124,57,6,7,7,5,8,6,9,5,2,2,'','','',1097425510);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (15,6,16,'1-2003A',2003,205,'0062',7,11,32,49,189,94,92,79,84,198,195,21,20,62,72,109,122,46,4,3,2,7,9,1,4,8,2,6,'','','',1097425519);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (16,7,17,'3-2002A',2002,205,'0061',7,16,29,44,188,92,99,79,80,198,201,24,23,70,70,101,126,56,3,9,1,6,4,8,6,8,3,8,'','','',1097425526);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (17,7,18,'8-2004B',2004,365,'0062',7,14,36,44,190,93,92,81,78,196,196,24,23,60,76,102,114,51,0,9,6,3,2,3,4,7,9,8,'','','',1097425534);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (18,6,19,'4-2003B',2003,365,'0063',6,11,39,50,188,95,97,83,78,196,201,21,21,72,58,109,114,28,7,2,2,1,0,6,1,3,3,3,'','','',1097425543);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (19,7,20,'3-2004A',2004,205,'0062',6,14,26,44,192,93,97,83,84,198,198,19,23,59,59,106,115,36,3,3,5,0,1,2,6,9,6,1,'','','',1097425551);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (20,5,21,'5-2003B',2003,365,'0063',6,8,37,44,190,99,90,79,78,195,196,20,19,60,67,102,120,45,5,2,4,1,0,3,9,6,8,7,'','','',1097425559);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (21,5,22,'1-2002B',2002,365,'0062',7,14,36,42,192,98,89,78,86,197,197,24,23,72,62,107,125,37,6,9,1,1,1,5,4,0,3,7,'','','',1097425569);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (22,7,23,'2-2003A',2003,205,'0060',7,14,28,47,190,89,89,78,84,200,196,22,21,69,61,105,123,42,1,9,5,1,5,8,1,2,3,7,'','','',1097425577);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (23,7,24,'6-2003B',2003,365,'0062',7,12,38,45,190,98,99,82,82,199,201,23,19,55,68,108,116,43,4,2,6,6,6,6,0,2,7,4,'','','',1097425584);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (24,7,25,'9-2004B',2004,365,'0062',6,13,35,51,188,92,90,78,82,196,201,21,20,67,69,108,116,41,9,3,1,1,8,6,4,7,1,1,'','','',1097425595);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (25,6,26,'10-2004B',2004,365,'0061',7,8,36,41,190,99,90,82,80,196,198,22,23,55,71,107,116,39,0,2,1,7,5,8,0,3,6,7,'','','',1097425601);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (26,5,27,'4-2004A',2004,205,'0062',6,9,38,49,189,91,90,80,86,198,197,23,19,69,64,103,112,36,0,5,5,2,4,9,7,0,0,4,'','','',1097425608);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (27,7,28,'11-2004B',2004,365,'0063',7,11,31,44,192,99,96,78,80,195,198,24,23,61,56,110,129,40,5,1,4,1,4,2,5,6,8,4,'','','',1097425617);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (28,5,29,'7-2003B',2003,365,'0061',7,9,31,48,190,90,99,83,87,198,200,20,21,60,74,110,119,43,7,6,4,1,5,3,4,5,5,3,'','','',1097425625);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (29,7,30,'2-2002B',2002,365,'0061',7,8,34,49,192,98,94,86,85,200,199,22,18,67,71,105,115,55,2,8,0,9,8,7,3,5,4,9,'','','',1097425635);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (30,5,31,'3-2002B',2002,365,'0061',6,11,30,43,191,92,97,80,84,199,198,24,20,72,72,101,117,38,3,2,1,5,0,3,6,6,7,5,'','','',1097425644);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (31,5,32,'3-2003A',2003,205,'0060',7,8,26,46,190,97,89,78,80,201,201,22,18,58,74,110,118,31,1,2,6,8,0,3,4,4,1,2,'','','',1097425653);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (32,5,33,'5-2004A',2004,205,'0061',6,13,35,50,189,89,89,84,79,196,195,24,18,57,58,105,128,47,9,9,1,8,8,2,0,2,5,3,'','','',1097425660);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (33,5,34,'4-2003A',2003,205,'0063',7,11,27,47,192,96,93,82,78,197,197,20,23,76,54,110,122,41,6,7,0,7,0,8,3,1,7,2,'','','',1097425668);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (34,5,35,'8-2003B',2003,365,'0061',7,16,33,48,191,98,92,87,87,197,200,22,19,73,55,104,122,29,2,0,6,9,3,0,5,2,2,0,'','','',1097425677);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (35,6,37,'12-2004B',2004,365,'0062',7,12,28,49,191,94,89,84,86,201,196,20,24,59,66,109,124,59,9,9,4,5,9,5,2,9,6,1,'','','',1097425686);
INSERT INTO fachstat (id, mit_id, fall_id, fall_fn, jahr, stz, bz, gs, ag, fs, zm, qualij, hkm, hkv, bkm, bkv, qualikm, qualikv, agkm, agkv, ba1, ba2, pbe, pbk, kat, kkm, kkv, kki, kpa, kfa, ksoz, kleh, kerz, kkonf, kson, no, no2, no3, zeit) VALUES (36,7,38,'13-2004B',2004,365,'0062',7,14,36,44,187,98,95,83,85,196,201,24,21,62,69,101,118,36,1,0,5,1,8,7,2,2,7,3,'','','',1097425694);

--
-- Table structure for table 'fachstatelternproblem'
--

CREATE TABLE fachstatelternproblem (
  id int(11) default NULL,
  fstat_id int(11) default NULL,
  pbe int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstatelternproblem'
--


INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (2,2,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (3,3,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (4,3,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (5,3,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (6,3,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (7,4,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (8,5,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (9,5,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (10,5,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (11,5,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (12,6,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (13,6,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (14,6,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (15,6,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (16,7,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (17,7,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (18,8,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (19,8,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (20,8,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (21,8,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (22,9,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (23,10,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (24,10,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (25,10,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (26,10,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (27,11,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (28,11,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (29,11,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (30,12,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (31,12,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (32,12,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (33,13,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (34,13,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (35,13,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (36,14,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (37,15,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (38,15,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (39,15,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (40,16,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (41,17,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (42,17,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (43,17,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (44,18,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (45,19,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (46,20,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (47,21,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (48,21,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (49,21,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (50,22,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (51,23,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (52,23,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (53,23,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (54,24,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (55,24,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (56,24,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (57,24,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (58,25,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (59,26,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (60,26,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (61,27,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (62,27,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (63,27,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (64,27,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (65,28,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (66,28,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (67,29,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (68,29,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (69,29,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (70,29,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (71,30,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (72,30,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (73,30,106);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (74,30,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (75,31,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (76,31,102);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (77,31,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (78,31,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (79,32,105);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (80,32,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (81,32,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (82,32,103);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (83,33,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (84,33,101);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (85,33,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (86,34,104);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (87,34,107);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (88,34,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (89,34,108);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (90,35,109);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (91,36,110);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (92,36,111);
INSERT INTO fachstatelternproblem (id, fstat_id, pbe) VALUES (93,36,102);

--
-- Table structure for table 'fachstatkindproblem'
--

CREATE TABLE fachstatkindproblem (
  id int(11) default NULL,
  fstat_id int(11) default NULL,
  pbk int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstatkindproblem'
--


INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (2,2,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (3,2,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (4,3,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (5,4,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (6,4,125);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (7,5,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (8,6,113);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (9,6,120);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (10,7,118);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (11,7,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (12,7,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (13,8,123);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (14,8,117);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (15,8,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (16,8,128);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (17,9,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (18,10,121);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (19,11,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (20,11,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (21,11,115);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (22,12,125);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (23,12,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (24,13,112);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (25,13,118);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (26,13,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (27,14,117);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (28,14,130);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (29,14,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (30,15,112);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (31,15,113);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (32,15,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (33,15,123);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (34,16,117);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (35,16,124);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (36,16,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (37,16,115);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (38,17,125);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (39,17,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (40,17,122);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (41,17,120);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (42,18,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (43,18,125);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (44,18,118);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (45,18,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (46,19,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (47,19,113);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (48,19,122);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (49,19,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (50,20,112);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (51,20,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (52,20,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (53,21,124);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (54,21,115);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (55,21,122);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (56,21,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (57,22,121);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (58,22,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (59,22,123);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (60,23,125);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (61,23,124);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (62,24,125);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (63,25,121);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (64,25,118);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (65,26,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (66,26,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (67,26,125);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (68,26,119);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (69,27,118);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (70,27,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (71,27,113);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (72,28,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (73,28,121);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (74,28,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (75,28,130);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (76,29,115);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (77,29,126);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (78,29,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (79,29,112);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (80,30,130);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (81,31,120);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (82,31,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (83,32,113);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (84,32,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (85,32,117);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (86,33,118);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (87,33,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (88,33,115);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (89,33,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (90,34,123);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (91,34,116);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (92,34,114);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (93,34,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (94,35,127);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (95,36,124);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (96,36,129);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (97,36,130);
INSERT INTO fachstatkindproblem (id, fstat_id, pbk) VALUES (98,36,123);

--
-- Table structure for table 'fachstatlei'
--

CREATE TABLE fachstatlei (
  id int(11) default NULL,
  fstat_id int(11) default NULL,
  le int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fachstatlei'
--


INSERT INTO fachstatlei (id, fstat_id, le) VALUES (2,2,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (3,2,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (4,2,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (5,2,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (6,2,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (7,2,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (8,2,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (9,2,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (10,3,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (11,3,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (12,3,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (13,3,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (14,3,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (15,3,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (16,3,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (17,3,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (18,3,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (19,4,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (20,4,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (21,5,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (22,5,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (23,5,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (24,5,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (25,5,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (26,5,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (27,5,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (28,5,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (29,6,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (30,6,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (31,6,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (32,6,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (33,6,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (34,6,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (35,7,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (36,7,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (37,7,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (38,7,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (39,7,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (40,7,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (41,7,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (42,7,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (43,7,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (44,8,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (45,8,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (46,8,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (47,8,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (48,8,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (49,8,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (50,8,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (51,9,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (52,9,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (53,9,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (54,9,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (55,9,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (56,9,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (57,9,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (58,9,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (59,9,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (60,9,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (61,10,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (62,11,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (63,11,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (64,11,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (65,11,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (66,11,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (67,11,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (68,12,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (69,12,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (70,12,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (71,12,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (72,12,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (73,12,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (74,12,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (75,13,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (76,13,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (77,13,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (78,13,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (79,13,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (80,14,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (81,14,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (82,14,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (83,14,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (84,15,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (85,15,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (86,15,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (87,15,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (88,15,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (89,15,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (90,15,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (91,16,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (92,16,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (93,17,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (94,17,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (95,17,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (96,17,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (97,18,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (98,19,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (99,19,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (100,20,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (101,20,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (102,20,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (103,21,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (104,21,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (105,21,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (106,21,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (107,21,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (108,21,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (109,21,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (110,21,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (111,21,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (112,22,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (113,22,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (114,22,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (115,22,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (116,22,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (117,22,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (118,22,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (119,23,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (120,23,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (121,23,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (122,23,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (123,23,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (124,23,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (125,23,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (126,24,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (127,24,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (128,24,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (129,24,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (130,24,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (131,24,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (132,25,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (133,26,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (134,27,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (135,27,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (136,27,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (137,27,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (138,27,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (139,27,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (140,27,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (141,28,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (142,28,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (143,28,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (144,28,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (145,28,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (146,28,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (147,29,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (148,29,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (149,29,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (150,29,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (151,29,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (152,29,131);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (153,29,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (154,29,147);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (155,29,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (156,30,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (157,30,134);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (158,30,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (159,30,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (160,30,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (161,30,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (162,30,132);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (163,30,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (164,30,146);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (165,31,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (166,31,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (167,31,142);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (168,31,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (169,31,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (170,31,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (171,31,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (172,32,141);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (173,32,149);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (174,32,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (175,33,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (176,33,133);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (177,33,145);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (178,33,136);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (179,33,140);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (180,33,135);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (181,33,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (182,34,138);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (183,35,143);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (184,35,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (185,35,150);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (186,35,137);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (187,36,148);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (188,36,139);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (189,36,144);
INSERT INTO fachstatlei (id, fstat_id, le) VALUES (190,36,146);

--
-- Table structure for table 'fall'
--

CREATE TABLE fall (
  id int(11) default NULL,
  akte_id int(11) default NULL,
  fn char(30) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  zdad int(11) default NULL,
  zdam int(11) default NULL,
  zday int(11) default NULL,
  status int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fall'
--


INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (2,2,'1-2002A',25,11,2002,21,8,2003,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (3,2,'1-2004A',6,1,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (4,3,'1-2004B',18,5,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (5,4,'2-2004B',2,9,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (6,5,'3-2004B',26,1,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (7,6,'4-2004B',6,4,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (8,7,'2-2002A',1,12,2002,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (9,8,'5-2004B',7,10,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (10,9,'1-2003B',13,2,2003,5,8,2003,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (11,10,'6-2004B',23,2,2004,14,9,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (12,11,'2-2003B',27,7,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (13,12,'2-2004A',18,9,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (14,13,'7-2004B',22,9,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (15,14,'3-2003B',16,7,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (16,15,'1-2003A',25,3,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (17,16,'3-2002A',25,12,2002,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (18,17,'8-2004B',8,10,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (19,18,'4-2003B',19,12,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (20,19,'3-2004A',9,6,2004,26,9,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (21,20,'5-2003B',11,2,2003,13,8,2003,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (22,21,'1-2002B',22,10,2002,20,8,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (23,22,'2-2003A',5,1,2003,13,7,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (24,23,'6-2003B',27,2,2003,3,1,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (25,24,'9-2004B',18,9,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (26,25,'10-2004B',10,7,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (27,26,'4-2004A',8,1,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (28,27,'11-2004B',16,1,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (29,28,'7-2003B',7,10,2003,22,2,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (30,29,'2-2002B',27,10,2002,8,2,2004,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (31,30,'3-2002B',21,11,2002,14,8,2003,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (32,31,'3-2003A',28,11,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (33,32,'5-2004A',4,8,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (34,33,'4-2003A',12,2,2003,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (35,34,'8-2003B',6,11,2003,8,12,2003,211);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (36,34,'6-2004A',5,3,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (37,35,'12-2004B',14,3,2004,0,0,0,210);
INSERT INTO fall (id, akte_id, fn, bgd, bgm, bgy, zdad, zdam, zday, status) VALUES (38,36,'13-2004B',28,3,2004,0,0,0,210);

--
-- Table structure for table 'fallgruppe'
--

CREATE TABLE fallgruppe (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  gruppe_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'fallgruppe'
--



--
-- Table structure for table 'feld'
--

CREATE TABLE feld (
  id int(11) default NULL,
  tab_id int(11) default NULL,
  feld char(30) default NULL,
  name char(60) default NULL,
  inverse char(60) default NULL,
  typ char(20) default NULL,
  laenge int(11) default NULL,
  notnull int(11) default NULL,
  verwtyp int(11) default NULL,
  ftab_id int(11) default NULL,
  kat_id int(11) default NULL,
  kat_code char(8) default NULL,
  flag int(11) default NULL,
  dok char(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'feld'
--


INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (1,1,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (2,1,'vn','Vorname',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (3,1,'na','Name',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (4,1,'ben','Benutzer',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (5,1,'anr','Anrede',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (6,1,'tl1','Diensttelefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (7,1,'fax','Fax',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (8,1,'mail','Mail',NULL,'CHAR(50)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (9,1,'stat','Status',NULL,'INT',NULL,NULL,3,24,17,'status',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (10,1,'benr','Benutzungsrecht',NULL,'INT',NULL,NULL,3,24,19,'benr',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (11,1,'stz','Hauptdienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (12,1,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (13,1,'pass','Passwort',NULL,'CHAR(50)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (14,2,'nr','nr',NULL,'INT(11)',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (15,2,'zeit','zeit',NULL,'VARCHAR(17)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (16,2,'artdeszugriffs','artdeszugriffs',NULL,'longtext',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (17,2,'benutzerkennung','benutzerkennung',NULL,'VARCHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (18,2,'ipadresse','ipadresse',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (19,3,'str_nummer','Str_nummer',NULL,'CHAR(5)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (20,3,'str_name','Str_name',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (21,3,'hausnr','Hausnr',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (22,3,'bezirk','Bezirk',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (23,3,'plz','Plz',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (24,3,'Plraum','Planungsraum',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (25,4,'session_id','SessionID',NULL,'CHAR(50)',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (26,4,'time','Time',NULL,'CHAR(16)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (27,4,'user_name','UserName',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (28,5,'mit_id','Mitarbeiterid','neben_stz','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (29,5,'stz','Nebendienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (30,6,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (31,6,'vn','Vorname',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (32,6,'na','Name',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (33,6,'gb','Geburtsdatum',NULL,'CHAR(10)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (34,6,'ber','Ausbildung',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (35,6,'str','Strasse',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (36,6,'hsnr','Hausnummer',NULL,'CHAR(5)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (37,6,'plz','Postleitzahl',NULL,'CHAR(9)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (38,6,'planungsr','Planungsraum',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (39,6,'wohnbez','Wohnbezirk',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (40,6,'lage','inBerlin',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (41,6,'ort','Ort',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (42,6,'tl1','Telefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (43,6,'tl2','Diensttelefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (44,6,'fs','Familienstatus (lebt bei)',NULL,'INT',NULL,NULL,3,24,4,'fsfs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (45,6,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (46,6,'stzbg','Aufnahmedienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (47,6,'stzak','Aktuelle Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (48,6,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (49,7,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (50,7,'akte_id','Aktenid','faelle','INT',NULL,NULL,2,6,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (51,7,'fn','Fallnummer',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (52,7,'bgd','Beginn Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (53,7,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (54,7,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (55,7,'zdad','Abschluss Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (56,7,'zdam','Abschluss Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (57,7,'zday','Abschluss Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (58,7,'status','Fallstand',NULL,'INT',NULL,NULL,3,24,20,'stand',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (59,8,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (60,8,'fall_id','Fall_id','anmeldung','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (61,8,'von','angemeldet von',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (62,8,'ad','Anmeldetag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (63,8,'am','Anmeldemonat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (64,8,'ay','Anmeldejahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (65,8,'mtl','Telefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (66,8,'me','auf Empfehlung von',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (67,8,'zm','Zugangsart',NULL,'INT',NULL,NULL,3,24,5,'fszm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (68,8,'mg','Anmeldegrund',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (69,8,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (70,9,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (71,9,'akte_id','Aktenid','bezugspersonen','INT',NULL,NULL,2,6,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (72,9,'vn','Vorname',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (73,9,'na','Name',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (74,9,'gb','Geburtsdatum',NULL,'CHAR(10)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (75,9,'ber','Beruf',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (76,9,'str','Strasse',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (77,9,'hsnr','Hausnummer',NULL,'CHAR(5)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (78,9,'lage','inBerlin',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (79,9,'plz','Postleitzahl',NULL,'CHAR(9)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (80,9,'ort','Ort',NULL,'CHAR(35)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (81,9,'tl1','Telefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (82,9,'tl2','Diensttelefon',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (83,9,'fs','Familienstatus (lebt bei)',NULL,'INT',NULL,NULL,3,24,4,'fsfs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (84,9,'verw','Verwandschaftsgrad',NULL,'INT',NULL,NULL,3,24,15,'klerv',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (85,9,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (86,9,'nobed','Notizbedeutung',NULL,'INT',NULL,NULL,3,24,21,'notizbed',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (87,9,'vrt','im Verteiler',NULL,'INT',NULL,NULL,3,24,22,'vert',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (88,10,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (89,10,'akte_id','Aktenid','einrichtungen','INT',NULL,NULL,2,6,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (90,10,'na','Name',NULL,'CHAR(80)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (91,10,'tl1','Telefon1',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (92,10,'tl2','Telefon2',NULL,'CHAR(25)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (93,10,'insta','Einrichtungsart',NULL,'INT',NULL,NULL,3,24,16,'klinsta',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (94,10,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (95,10,'nobed','Notizbedeutung',NULL,'INT',NULL,NULL,3,24,21,'notizbed',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (96,10,'status','Aktueller Kontakt',NULL,'INT',NULL,NULL,3,24,23,'einrstat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (97,11,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (98,11,'fall_id','Fallid','leistungen','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (99,11,'mit_id','Mitarbeiterid','leistungen','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (100,11,'le','Leistungsart',NULL,'INT',NULL,NULL,3,24,11,'fsle',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (101,11,'bgd','Beginn Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (102,11,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (103,11,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (104,11,'ed','Ende Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (105,11,'em','Ende Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (106,11,'ey','Ende Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (107,11,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (108,12,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (109,12,'fall_id','Fallid','zustaendigkeiten','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (110,12,'mit_id','Mitarbeiterid','zustaendigkeiten','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (111,12,'bgd','Beginn Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (112,12,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (113,12,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (114,12,'ed','Ende Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (115,12,'em','Ende Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (116,12,'ey','Ende Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (117,13,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (118,13,'fall_id','Fallid','dokumente','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (119,13,'mit_id','Mitarbeiterid','dokumente','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (120,13,'betr','Betrifft',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (121,13,'fname','Dateiname',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (122,13,'art','Text ist',NULL,'INT',NULL,NULL,3,24,53,'dokart',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (123,13,'vd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (124,13,'vm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (125,13,'vy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (126,13,'mtyp','Mime Typ',NULL,'INT',NULL,NULL,3,24,52,'mimetyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (127,13,'dok','Dokument',NULL,'BLOB',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (128,13,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (129,14,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (130,14,'gruppe_id','Gruppeid','gruppendokumente','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (131,14,'mit_id','Mitarbeiterid','gruppendokumente','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (132,14,'betr','Betrifft',NULL,'CHAR(254)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (133,14,'fname','Dateiname',NULL,'CHAR(254)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (134,14,'art','Text ist',NULL,'INT',NULL,NULL,3,24,53,'dokart',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (135,14,'vd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (136,14,'vm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (137,14,'vy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (138,14,'mtyp','Mime Typ',NULL,'INT',NULL,NULL,3,24,52,'mimetyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (139,14,'dok','Dokument',NULL,'BLOB',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (140,14,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (141,15,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (142,15,'gn','Gruppennummer',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (143,15,'name','Name',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (144,15,'thema','Thema',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (145,15,'tzahl','Anzahl der Termine',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (146,15,'stzahl','Anzahl der Stunden',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (147,15,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (148,15,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (149,15,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (150,15,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (151,15,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (152,15,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (153,15,'teiln','Teilnehmer',NULL,'INT',NULL,NULL,3,24,54,'teiln',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (154,15,'grtyp','Gruppentyp',NULL,'INT',NULL,NULL,3,24,55,'grtyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (155,15,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (156,15,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (157,16,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (158,16,'fall_id','Fallid','gruppen','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (159,16,'gruppe_id','Gruppeid','faelle','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (160,16,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (161,16,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (162,16,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (163,16,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (164,16,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (165,16,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (166,16,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (167,17,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (168,17,'bezugsp_id','Bezugspersonid','gruppen','INT',NULL,NULL,2,9,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (169,17,'gruppe_id','Gruppeid','bezugspersonen','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (170,17,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (171,17,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (172,17,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (173,17,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (174,17,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (175,17,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (176,17,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (177,18,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (178,18,'mit_id','Mitarbeiterid','gruppen','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (179,18,'gruppe_id','Gruppeid','mitarbeiter','INT',NULL,NULL,2,15,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (180,18,'bgd','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (181,18,'bgm','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (182,18,'bgy','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (183,18,'ed','Tag',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (184,18,'em','Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (185,18,'ey','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (186,18,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (187,19,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (188,19,'mit_id','Mitarbeiterid','fachstatistiken','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (189,19,'fall_id','Fallid','fachstatistiken','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (190,19,'fall_fn','Fallnummer',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (191,19,'jahr','Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (192,19,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (193,19,'bz','Region',NULL,'CHAR(4)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (194,19,'gs','Geschlecht',NULL,'INT',NULL,NULL,3,24,30,'gs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (195,19,'ag','Altersgruppe Kind',NULL,'INT',NULL,NULL,3,24,2,'fsag',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (196,19,'fs','Familienstatus (lebt bei)',NULL,'INT',NULL,NULL,3,24,4,'fsfs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (197,19,'zm','Zugangsart',NULL,'INT',NULL,NULL,3,24,5,'fszm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (198,19,'qualij','Qualifikation des/r Jugendlicher/n',NULL,'INT',NULL,NULL,3,24,13,'fsqualij',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (199,19,'hkm','Herkunft der Mutter',NULL,'INT',NULL,NULL,3,24,8,'fshe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (200,19,'hkv','Herkunft des Vaters',NULL,'INT',NULL,NULL,3,24,8,'fshe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (201,19,'bkm','Beruf der Mutter',NULL,'INT',NULL,NULL,3,24,7,'fsbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (202,19,'bkv','Beruf des Vaters',NULL,'INT',NULL,NULL,3,24,7,'fsbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (203,19,'qualikm','Qualifikation der Mutter',NULL,'INT',NULL,NULL,3,24,14,'fsquali',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (204,19,'qualikv','Qualifikation des Vater',NULL,'INT',NULL,NULL,3,24,14,'fsquali',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (205,19,'agkm','Altersgruppe der Mutter',NULL,'INT',NULL,NULL,3,24,3,'fsagel',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (206,19,'agkv','Altersgruppe des Vaters',NULL,'INT',NULL,NULL,3,24,3,'fsagel',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (207,19,'ba1','Vorstellungsanlass 1 bei der Anmeldung',NULL,'INT',NULL,NULL,3,24,6,'fsba',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (208,19,'ba2','Vorstellungsanlass 2 bei der Anmeldung',NULL,'INT',NULL,NULL,3,24,6,'fsba',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (209,19,'pbe','Hauptproblematik Eltern',NULL,'INT',NULL,NULL,3,24,9,'fspbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (210,19,'pbk','Hauptproblematik Kind/Jugendliche',NULL,'INT',NULL,NULL,3,24,10,'fspbk',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (211,19,'kat','Summe der Konsultationen insgesamt (a 50 Min.)',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (212,19,'kkm','Anzahl der Konsultationen Mutter',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (213,19,'kkv','Anzahl der Konsultationen Vater',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (214,19,'kki','Anzahl der Konsultationen Kind / Jugendlicher',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (215,19,'kpa','Anzahl der Konsultationen Paar',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (216,19,'kfa','Anzahl der Konsultationen Familie',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (217,19,'ksoz','Anzahl der Konsultationen Sozialarbeiter',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (218,19,'kleh','Anzahl der Konsultationen Lehrer',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (219,19,'kerz','Anzahl der Konsultationen Erzieher',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (220,19,'kkonf','Anzahl der Konsultationen Hilfebesprechung',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (221,19,'kson','Kontaktanzahl Sonstige',NULL,'INT',NULL,NULL,4,NULL,12,'fskat',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (222,19,'no','Notiz',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (223,19,'no2','anders geartete Problemlagen Kind',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (224,19,'no3','anders geartete Problemlagen Eltern',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (225,19,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (226,20,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (227,20,'fstat_id','Fachstatistikid','leistungen','INT',NULL,NULL,2,19,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (228,20,'le','Leistungsart',NULL,'INT',NULL,NULL,3,24,11,'fsle',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (229,21,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (230,21,'fstat_id','Fachstatistikid','fachstatkindprobleme','INT',NULL,NULL,2,19,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (231,21,'pbk','Problemspektrum Kind',NULL,'INT',NULL,NULL,3,24,10,'fspbk',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (232,22,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (233,22,'fstat_id','Fachstatistikid','fachstatelternprobleme','INT',NULL,NULL,2,19,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (234,22,'pbe','Problemspektrum Eltern',NULL,'INT',NULL,NULL,3,24,9,'fspbe',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (235,23,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (236,23,'fall_id','Fallid','jgh_statistiken','INT',NULL,NULL,2,7,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (237,23,'mit_id','Mitarbeiterid','jgh_statistiken','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (238,23,'fall_fn','Fallnummer',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (239,23,'gfall','Geschwisterfall',NULL,'INT',NULL,NULL,3,24,56,'gfall',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (240,23,'bezirksnr','Wohnbezirksnummer des Klienten',NULL,'INT',NULL,NULL,3,24,57,'wohnbez',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (241,23,'stz','Dienststelle',NULL,'INT',NULL,NULL,3,24,18,'stzei',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (242,23,'rbz','Regierungsbezirk',NULL,'INT',NULL,NULL,3,24,24,'rbz',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (243,23,'kr','Kreis',NULL,'INT',NULL,NULL,3,24,25,'kr',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (244,23,'gm','Gemeinde',NULL,'INT',NULL,NULL,3,24,26,'gm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (245,23,'gmt','Gemeindeteil',NULL,'INT',NULL,NULL,3,24,27,'gmt',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (246,23,'lnr','laufendeNummer',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (247,23,'traeg','Tr�ger',NULL,'INT',NULL,NULL,3,24,28,'traeg',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (248,23,'bgm','Beginn Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (249,23,'bgy','Beginn Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (250,23,'em','Ende Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (251,23,'ey','Ende Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (252,23,'bgr','Beendigungsgrund',NULL,'INT',NULL,NULL,3,24,29,'bgr',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (253,23,'gs','Geschlecht',NULL,'INT',NULL,NULL,3,24,30,'gs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (254,23,'ag','Altersgruppe',NULL,'INT',NULL,NULL,3,24,31,'ag',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (255,23,'fs','lebt bei',NULL,'INT',NULL,NULL,3,24,32,'fs',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (256,23,'hke','Herkunft Eltern',NULL,'INT',NULL,NULL,3,24,33,'hke',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (257,23,'gsa','Geschwisterzahl',NULL,'INT',NULL,NULL,4,NULL,35,'gsa',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (258,23,'gsu','Geschwisterzahl unbekannt',NULL,'INT',NULL,NULL,3,24,36,'gsu',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (259,23,'zm','Kontaktaufnahme',NULL,'INT',NULL,NULL,3,24,34,'zm',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (260,23,'ba0','Beratungsanlass 0',NULL,'INT',NULL,NULL,3,24,37,'ba0',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (261,23,'ba1','Beratungsanlass 1',NULL,'INT',NULL,NULL,3,24,38,'ba1',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (262,23,'ba2','Beratungsanlass 2',NULL,'INT',NULL,NULL,3,24,39,'ba2',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (263,23,'ba3','Beratungsanlass 3',NULL,'INT',NULL,NULL,3,24,40,'ba3',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (264,23,'ba4','Beratungsanlass 4',NULL,'INT',NULL,NULL,3,24,41,'ba4',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (265,23,'ba5','Beratungsanlass 5',NULL,'INT',NULL,NULL,3,24,42,'ba5',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (266,23,'ba6','Beratungsanlass 6',NULL,'INT',NULL,NULL,3,24,43,'ba6',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (267,23,'ba7','Beratungsanlass 7',NULL,'INT',NULL,NULL,3,24,44,'ba7',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (268,23,'ba8','Beratungsanlass 8',NULL,'INT',NULL,NULL,3,24,45,'ba8',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (269,23,'ba9','Beratungsanlass 9',NULL,'INT',NULL,NULL,3,24,46,'ba9',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (270,23,'schw','Beratungsschwerpunkt',NULL,'INT',NULL,NULL,3,24,47,'schw',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (271,23,'fbe0','Beratung Kind',NULL,'INT',NULL,NULL,3,24,48,'fbe0',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (272,23,'fbe1','Beratung Eltern',NULL,'INT',NULL,NULL,3,24,49,'fbe1',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (273,23,'fbe2','Beratung Familie',NULL,'INT',NULL,NULL,3,24,50,'fbe2',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (274,23,'fbe3','Beratung Umfeld',NULL,'INT',NULL,NULL,3,24,51,'fbe3',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (275,23,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (276,24,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (277,24,'kat_id','Kategorienid','codes','INT',NULL,NULL,2,25,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (278,24,'kat_code','Kategoriencode',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (279,24,'code','Code',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (280,24,'name','Name',NULL,'CHAR(160)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (281,24,'sort','Sortierreihenfolge',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (282,24,'mini','Bereichsminimum',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (283,24,'maxi','Bereichsmaximum',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (284,24,'off','Ung�ltig',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (285,24,'dm','Ung�ltig ab Monat',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (286,24,'dy','Ung�ltig ab Jahr',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (287,24,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (288,24,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (289,25,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (290,25,'code','Code',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (291,25,'name','Name',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (292,25,'kat_id','Kategorienart','kategorien','INT',NULL,NULL,2,25,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (293,25,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (294,25,'zeit','�nderungszeit',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (295,26,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (296,26,'mit_id','Mitarbeiterid','','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (297,26,'zeit','Exportzeitpunkt',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (298,26,'dbsite','Datenbanksite',NULL,'INT',NULL,NULL,3,24,58,'dbsite',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (299,27,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (300,27,'exp_id','Exportprotokollid','importprotokolle','INT',NULL,NULL,2,26,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (301,27,'mit_id','Mitarbeiterid','','INT',NULL,NULL,2,1,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (302,27,'zeit','Importzeitpunkt',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (303,27,'dbsite','Datenbanksite',NULL,'INT',NULL,NULL,3,24,58,'dbsite',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (304,28,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (305,28,'tab_id','Tabelle','felder','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (306,28,'feld','Feldname',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (307,28,'name','Langname des Feldes',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (308,28,'inverse','Name f�r inverse Beziehung',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (309,28,'typ','Datenbanktyp',NULL,'CHAR(20)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (310,28,'laenge','Feldl�nge',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (311,28,'notnull','Nicht NULL',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (312,28,'verwtyp','Verwendungstyp',NULL,'INT',NULL,NULL,3,24,1,'verwtyp',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (313,28,'ftab_id','Fremdtabelle','inverse','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (314,28,'kat_id','Kategorienid','','INT',NULL,NULL,2,25,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (315,28,'kat_code','Kategoriencode',NULL,'CHAR(8)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (316,28,'flag','Flags',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (317,28,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (318,29,'id','id',NULL,'INT',NULL,NULL,1,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (319,29,'tabelle','Tabellenname',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (320,29,'name','Langname der Tabelle',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (321,29,'klasse','Klassenname',NULL,'CHAR(60)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (322,29,'flag','Flags',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (323,29,'dok','Erl�uterung',NULL,'CHAR(255)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (324,30,'table_id','Tabellenid','iddaten','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (325,30,'table_name','Tabellenname',NULL,'CHAR(30)',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (326,30,'dbsite','Datenbanksite',NULL,'INT',NULL,NULL,3,24,58,'dbsite',0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (327,30,'minid','Minimale ID',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (328,30,'maxid','Maximale ID',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (329,30,'maxist','Maximale verwendete ID',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (330,31,'tab_id','Tabelle','schluessel','INT',NULL,NULL,2,29,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (331,31,'feld_id','Feld','schluessel','INT',NULL,NULL,2,28,NULL,NULL,0,NULL);
INSERT INTO feld (id, tab_id, feld, name, inverse, typ, laenge, notnull, verwtyp, ftab_id, kat_id, kat_code, flag, dok) VALUES (332,31,'seq','Laufende Nummer',NULL,'INT',NULL,NULL,5,NULL,NULL,NULL,0,NULL);

--
-- Table structure for table 'gruppe'
--

CREATE TABLE gruppe (
  id int(11) default NULL,
  gn char(20) default NULL,
  name char(255) default NULL,
  thema char(255) default NULL,
  tzahl int(11) default NULL,
  stzahl int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  teiln int(11) default NULL,
  grtyp int(11) default NULL,
  stz int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'gruppe'
--



--
-- Table structure for table 'gruppendokument'
--

CREATE TABLE gruppendokument (
  id int(11) default NULL,
  gruppe_id int(11) default NULL,
  mit_id int(11) default NULL,
  betr varchar(254) default NULL,
  fname varchar(254) default NULL,
  art int(11) default NULL,
  vd int(11) default NULL,
  vm int(11) default NULL,
  vy int(11) default NULL,
  mtyp int(11) default NULL,
  dok blob,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'gruppendokument'
--



--
-- Table structure for table 'importprotokoll'
--

CREATE TABLE importprotokoll (
  id int(11) default NULL,
  exp_id int(11) default NULL,
  mit_id int(11) default NULL,
  zeit int(11) default NULL,
  dbsite int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'importprotokoll'
--



--
-- Table structure for table 'jghstat'
--

CREATE TABLE jghstat (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  fall_fn char(20) default NULL,
  gfall int(11) default NULL,
  bezirksnr int(11) default NULL,
  stz int(11) default NULL,
  rbz int(11) default NULL,
  kr int(11) default NULL,
  gm int(11) default NULL,
  gmt int(11) default NULL,
  lnr int(11) default NULL,
  traeg int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  bgr int(11) default NULL,
  gs int(11) default NULL,
  ag int(11) default NULL,
  fs int(11) default NULL,
  hke int(11) default NULL,
  gsa int(11) default NULL,
  gsu int(11) default NULL,
  zm int(11) default NULL,
  ba0 int(11) default NULL,
  ba1 int(11) default NULL,
  ba2 int(11) default NULL,
  ba3 int(11) default NULL,
  ba4 int(11) default NULL,
  ba5 int(11) default NULL,
  ba6 int(11) default NULL,
  ba7 int(11) default NULL,
  ba8 int(11) default NULL,
  ba9 int(11) default NULL,
  schw int(11) default NULL,
  fbe0 int(11) default NULL,
  fbe1 int(11) default NULL,
  fbe2 int(11) default NULL,
  fbe3 int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'jghstat'
--


INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (2,2,5,'1-2002A',356,358,205,218,219,222,223,NULL,224,11,2002,10,2004,226,7,235,240,250,NULL,257,260,265,266,269,271,273,275,277,278,281,283,285,289,292,294,296,1097425406);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (3,4,6,'1-2004B',356,358,365,218,219,222,223,NULL,224,5,2004,10,2004,227,6,234,244,249,0,256,263,265,266,269,271,273,275,276,279,281,283,286,289,291,294,295,1097425417);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (4,5,5,'2-2004B',356,358,365,218,219,222,223,NULL,225,9,2004,10,2004,227,6,229,245,249,NULL,257,258,265,267,269,271,273,275,276,279,281,283,285,289,292,294,296,1097425424);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (5,6,6,'3-2004B',357,358,365,218,219,222,223,NULL,224,1,2004,10,2004,228,7,237,243,250,NULL,257,259,265,267,269,271,273,274,277,279,281,283,285,289,292,294,296,1097425432);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (6,7,6,'4-2004B',357,358,365,218,219,222,223,NULL,224,4,2004,10,2004,228,6,233,243,250,7,256,261,265,267,269,271,273,275,277,279,281,282,284,289,292,294,296,1097425438);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (7,8,7,'2-2002A',357,358,205,218,219,222,223,NULL,224,12,2002,10,2004,227,6,233,239,248,1,256,260,265,267,268,271,273,275,277,279,281,282,285,289,291,294,296,1097425447);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (8,9,5,'5-2004B',356,358,365,218,219,222,223,NULL,224,10,2004,10,2004,228,7,232,243,248,NULL,257,263,265,267,269,271,272,275,277,279,281,283,286,288,292,294,296,1097425454);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (9,10,6,'1-2003B',356,358,365,218,219,222,223,NULL,225,2,2003,10,2004,226,6,229,242,249,3,256,260,265,267,269,271,273,275,277,278,281,283,284,289,292,293,296,1097425462);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (10,11,5,'6-2004B',357,358,365,218,219,222,223,NULL,224,2,2004,10,2004,226,6,229,239,250,NULL,257,260,265,267,269,271,273,275,277,279,281,282,286,289,290,294,296,1097425477);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (11,12,7,'2-2003B',357,358,365,218,219,222,223,NULL,224,7,2003,10,2004,227,7,232,239,249,4,256,258,265,267,269,271,273,274,277,278,281,283,284,289,291,294,296,1097425488);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (12,13,6,'2-2004A',356,358,205,218,219,222,223,NULL,225,9,2004,10,2004,226,7,229,245,249,2,256,260,265,267,269,271,273,275,276,279,281,282,286,289,291,294,296,1097425496);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (13,14,5,'7-2004B',356,358,365,218,219,222,223,NULL,225,9,2004,10,2004,226,6,229,244,250,1,256,258,265,266,269,271,273,275,277,278,281,283,286,289,292,294,296,1097425503);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (14,15,7,'3-2003B',356,358,365,218,219,222,223,NULL,224,7,2003,10,2004,226,6,231,246,249,NULL,257,260,264,267,269,271,273,275,277,279,280,283,285,289,292,294,296,1097425512);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (15,16,6,'1-2003A',356,358,205,218,219,222,223,NULL,225,3,2003,10,2004,226,7,234,244,248,NULL,257,258,264,267,269,271,273,275,277,278,281,283,285,289,292,294,296,1097425521);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (16,17,7,'3-2002A',357,358,205,218,219,222,223,NULL,224,12,2002,10,2004,226,6,229,239,248,NULL,257,263,265,267,269,271,273,275,276,279,281,283,284,288,292,294,296,1097425528);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (17,18,7,'8-2004B',356,358,365,218,219,222,223,NULL,225,10,2004,10,2004,228,6,236,245,248,NULL,257,260,264,267,268,271,273,275,277,279,281,283,285,289,292,294,296,1097425537);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (18,19,6,'4-2003B',357,358,365,218,219,222,223,NULL,224,12,2003,10,2004,228,6,237,244,248,NULL,257,262,265,267,269,271,272,275,277,279,281,283,284,289,292,294,296,1097425545);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (19,20,7,'3-2004A',357,358,205,218,219,222,223,NULL,224,6,2004,10,2004,226,7,231,240,250,NULL,257,263,265,267,269,271,273,275,277,279,281,282,285,289,292,294,296,1097425553);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (20,21,5,'5-2003B',357,358,365,218,219,222,223,NULL,225,2,2003,10,2004,226,6,234,238,248,NULL,257,260,265,267,269,271,272,275,277,278,281,283,286,289,292,294,296,1097425562);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (21,22,5,'1-2002B',356,358,365,218,219,222,223,NULL,224,10,2002,10,2004,227,7,229,245,248,NULL,257,263,265,267,269,270,273,275,277,279,281,283,285,289,292,294,296,1097425571);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (22,23,7,'2-2003A',356,358,205,218,219,222,223,NULL,225,1,2003,10,2004,227,6,231,244,249,NULL,257,258,265,267,268,271,273,275,277,279,281,283,284,288,292,294,296,1097425579);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (23,24,7,'6-2003B',356,358,365,218,219,222,223,NULL,224,2,2003,10,2004,228,7,233,247,248,2,256,259,265,266,269,271,273,275,277,279,280,283,285,289,292,293,296,1097425586);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (24,25,7,'9-2004B',357,358,365,218,219,222,223,NULL,225,9,2004,10,2004,227,7,237,238,250,NULL,257,258,265,266,269,271,273,275,277,279,281,283,285,289,292,293,296,1097425596);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (25,26,6,'10-2004B',356,358,365,218,219,222,223,NULL,225,7,2004,10,2004,226,6,230,242,249,7,256,258,265,267,269,270,273,275,276,279,281,283,284,289,292,294,296,1097425603);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (26,27,5,'4-2004A',356,358,205,218,219,222,223,NULL,224,1,2004,10,2004,227,7,234,241,250,NULL,257,262,264,267,269,270,273,275,277,279,281,283,284,287,292,294,296,1097425610);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (27,28,7,'11-2004B',356,358,365,218,219,222,223,NULL,224,1,2004,10,2004,226,7,232,241,248,7,256,261,265,267,269,270,273,275,277,279,280,283,285,289,292,294,296,1097425619);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (28,29,5,'7-2003B',357,358,365,218,219,222,223,NULL,224,10,2003,10,2004,227,7,229,246,250,4,256,261,265,267,269,271,273,275,277,279,281,282,284,289,292,294,296,1097425626);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (29,30,7,'2-2002B',357,358,365,218,219,222,223,NULL,225,10,2002,10,2004,226,7,237,240,248,NULL,257,258,265,267,268,271,273,275,277,279,281,283,284,289,292,293,296,1097425636);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (30,31,5,'3-2002B',357,358,365,218,219,222,223,NULL,224,11,2002,10,2004,228,7,236,244,248,NULL,257,262,265,267,268,271,273,275,277,279,280,283,286,289,291,294,296,1097425646);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (31,32,5,'3-2003A',356,358,205,218,219,222,223,NULL,224,11,2003,10,2004,228,7,229,245,249,3,256,261,265,266,269,271,272,275,277,279,281,283,286,289,292,293,296,1097425656);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (32,33,5,'5-2004A',357,358,205,218,219,222,223,NULL,224,8,2004,10,2004,228,6,230,247,248,5,256,262,265,267,269,271,272,275,277,279,281,283,284,289,292,293,296,1097425662);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (33,34,5,'4-2003A',357,358,205,218,219,222,223,NULL,225,2,2003,10,2004,228,7,232,238,250,7,256,258,265,267,268,271,273,275,277,279,281,283,284,287,292,293,296,1097425670);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (34,35,5,'8-2003B',357,358,365,218,219,222,223,NULL,225,11,2003,10,2004,227,7,234,238,249,1,256,260,265,266,269,271,273,275,277,279,281,283,285,288,292,294,296,1097425679);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (35,37,6,'12-2004B',357,358,365,218,219,222,223,NULL,225,3,2004,10,2004,226,7,236,246,250,5,256,262,265,266,269,271,273,275,277,279,281,283,285,288,292,294,296,1097425688);
INSERT INTO jghstat (id, fall_id, mit_id, fall_fn, gfall, bezirksnr, stz, rbz, kr, gm, gmt, lnr, traeg, bgm, bgy, em, ey, bgr, gs, ag, fs, hke, gsa, gsu, zm, ba0, ba1, ba2, ba3, ba4, ba5, ba6, ba7, ba8, ba9, schw, fbe0, fbe1, fbe2, fbe3, zeit) VALUES (36,38,7,'13-2004B',356,358,365,218,219,222,223,NULL,225,3,2004,10,2004,226,6,236,238,250,NULL,257,259,265,266,269,271,273,275,277,279,281,283,285,289,291,294,296,1097425696);

--
-- Table structure for table 'kategorie'
--

CREATE TABLE kategorie (
  id int(11) default NULL,
  code char(8) default NULL,
  name char(60) default NULL,
  kat_id int(11) default NULL,
  dok char(255) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'kategorie'
--


INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (1,'verwtyp','Feldverwendungstyp',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (2,'fsag','Altersgruppe Kind/Jugendliche',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (3,'fsagel','Altersgruppe Eltern',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (4,'fsfs','Lebensmittelpunkt des Kindes',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (5,'fszm','Zugangsweg',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (6,'fsba','Vorstellungsanlass bei der Anmeldung',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (7,'fsbe','Beruf der Eltern',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (8,'fshe','Herkunftsland der Eltern',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (9,'fspbe','Problemspektrum Eltern',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (10,'fspbk','Problemspektrum Kind, Jugendliche',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (11,'fsle','Erbrachte Leistungen',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (12,'fskat','Anzahl der Termine',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (13,'fsqualij','sozialer Status Jugendlicher, 14-27',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (14,'fsquali','Qualifikation der Eltern',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (15,'klerv','Verwandtschaftsgrad',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (16,'klinsta','Einrichtungskontakt',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (17,'status','Mitarbeiterstatus',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (18,'stzei','Dienststelle',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (19,'benr','Benutzungsrecht',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (20,'stand','Bearbeitungsstand',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (21,'notizbed','Notizbedeutung',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (22,'vert','im Verteiler',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (23,'einrstat','Aktueller Kontakt',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (24,'rbz','Regierungsbezirk',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (25,'kr','Kreis',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (26,'gm','Gemeinde',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (27,'gmt','Gemeindeteil',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (28,'traeg','Jugendhilfe-Tr�ger',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (29,'bgr','Beendigungsgrund',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (30,'gs','Geschlecht',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (31,'ag','Alter',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (32,'fs','Junger Mensch lebt bei',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (33,'hke','Staatsangeh�rigkeit',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (34,'zm','1. Kontakt durch',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (35,'gsa','Geschwisteranzahl',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (36,'gsu','Kenntnis der Geschwisterzahl',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (37,'ba0','Beratungsanlass 0',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (38,'ba1','Beratungsanlass 1',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (39,'ba2','Beratungsanlass 2',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (40,'ba3','Beratungsanlass 3',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (41,'ba4','Beratungsanlass 4',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (42,'ba5','Beratungsanlass 5',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (43,'ba6','Beratungsanlass 6',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (44,'ba7','Beratungsanlass 7',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (45,'ba8','Beratungsanlass 8',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (46,'ba9','Beratungsanlass 9',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (47,'schw','Beratungsschwerpunkt',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (48,'fbe0','beim jungen Menschen',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (49,'fbe1','bei den Eltern',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (50,'fbe2','in der Familie',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (51,'fbe3','im sozialen Umfeld',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (52,'mimetyp','Mime Typ',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (53,'dokart','Der Eintrag ist',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (54,'teiln','Teilnehmer/innnen',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (55,'grtyp','Gruppentyp',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (56,'gfall','Geschwisterfall',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (57,'wohnbez','Wohnbezirksnr des Klienten',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (58,'dbsite','Datenbank-Site',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (59,'lage','Lage innerhalb oder au�erhalb des Geltungsbereichs des Stra�',NULL,NULL,1097425384);
INSERT INTO kategorie (id, code, name, kat_id, dok, zeit) VALUES (60,'config','Konfigurationseinstellungen',NULL,NULL,1097425384);

--
-- Table structure for table 'leistung'
--

CREATE TABLE leistung (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  le int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  stz int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'leistung'
--


INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (2,2,5,136,25,11,2002,21,8,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (3,2,5,135,26,3,2003,21,8,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (4,3,5,138,6,1,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (5,4,5,134,18,5,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (6,5,6,137,2,9,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (7,6,6,146,26,1,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (8,7,6,133,6,4,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (9,8,7,137,1,12,2002,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (10,9,5,140,7,10,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (11,10,6,138,13,2,2003,5,8,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (12,10,6,141,13,3,2003,5,8,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (13,10,6,131,20,3,2003,5,8,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (14,10,6,140,17,3,2003,5,8,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (15,10,6,147,11,7,2003,5,8,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (16,11,6,148,23,2,2004,14,9,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (17,11,5,148,10,6,2004,14,9,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (18,11,5,146,23,5,2004,14,9,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (19,11,5,149,19,4,2004,14,9,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (20,12,7,148,27,7,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (21,13,5,144,18,9,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (22,14,5,144,22,9,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (23,15,6,138,16,7,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (24,16,7,140,25,3,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (25,17,5,148,25,12,2002,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (26,18,6,140,8,10,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (27,19,6,146,19,12,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (28,20,6,147,9,6,2004,26,9,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (29,20,7,144,22,8,2004,26,9,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (30,20,7,134,28,6,2004,26,9,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (31,20,7,149,16,7,2004,26,9,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (32,21,7,149,11,2,2003,13,8,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (33,22,5,145,22,10,2002,20,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (34,22,5,134,7,8,2003,20,8,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (35,23,7,132,5,1,2003,13,7,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (36,24,5,141,27,2,2003,3,1,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (37,24,7,136,11,3,2003,3,1,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (38,24,7,141,25,5,2003,3,1,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (39,24,7,149,6,4,2003,3,1,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (40,24,7,144,22,11,2003,3,1,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (41,25,6,142,18,9,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (42,26,7,137,10,7,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (43,27,7,134,8,1,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (44,28,7,134,16,1,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (45,29,5,139,7,10,2003,22,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (46,29,5,141,1,1,2004,22,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (47,29,5,148,16,2,2004,22,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (48,30,5,131,27,10,2002,8,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (49,30,7,135,5,5,2003,8,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (50,30,7,149,26,2,2003,8,2,2004,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (51,31,6,138,21,11,2002,14,8,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (52,32,6,140,28,11,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (53,33,6,144,4,8,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (54,34,6,148,12,2,2003,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (55,35,5,143,6,11,2003,8,12,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (56,35,5,139,21,11,2003,8,12,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (57,35,5,131,26,11,2003,8,12,2003,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (58,36,5,137,5,3,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (59,37,6,131,14,3,2004,0,0,0,205);
INSERT INTO leistung (id, fall_id, mit_id, le, bgd, bgm, bgy, ed, em, ey, stz) VALUES (60,38,6,148,28,3,2004,0,0,0,205);

--
-- Table structure for table 'mitarbeiter'
--

CREATE TABLE mitarbeiter (
  id int(11) default NULL,
  vn char(35) default NULL,
  na char(35) default NULL,
  ben char(25) default NULL,
  anr char(20) default NULL,
  tl1 char(25) default NULL,
  fax char(25) default NULL,
  mail char(50) default NULL,
  stat int(11) default NULL,
  benr int(11) default NULL,
  stz int(11) default NULL,
  zeit int(11) default NULL,
  pass char(50) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'mitarbeiter'
--


INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (1,'Admin','Administrator','Admin',NULL,NULL,NULL,NULL,203,206,205,1097425388,'4e7afebcfbae000b22c7c85e5560f89a2a0280b4');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (2,'Protokol2vn','Protokol2na','pr1',NULL,NULL,NULL,NULL,203,209,365,1097425397,'16bc8ed897088bc50fc6d41eddeb2928401dd942');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (3,'Protokol3vn','Protokol3na','pr2',NULL,NULL,NULL,NULL,203,209,205,1097425397,'e590beb38f2503444a9f9e2e6f0f61698890fb5e');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (4,'Verw4vn','Verw4na','verw',NULL,NULL,NULL,NULL,203,208,365,1097425398,'dad3d82ccef3940d682e7eb5c62e6ff5b1bb43aa');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (5,'Bearb5vn','Bearb5na','bearb1',NULL,NULL,NULL,NULL,203,207,205,1097425398,'bf46eb1252e630d57d7362ff9d1ded47c9f54763');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (6,'Bearb6vn','Bearb6na','bearb2',NULL,NULL,NULL,NULL,203,207,205,1097425398,'984cbfa8abac2ec5c2147d248bf1f12f1d663943');
INSERT INTO mitarbeiter (id, vn, na, ben, anr, tl1, fax, mail, stat, benr, stz, zeit, pass) VALUES (7,'Test','Tester','test',NULL,NULL,NULL,NULL,203,207,205,1097425399,'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3');

--
-- Table structure for table 'mitarbeitergruppe'
--

CREATE TABLE mitarbeitergruppe (
  id int(11) default NULL,
  mit_id int(11) default NULL,
  gruppe_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL,
  zeit int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'mitarbeitergruppe'
--



--
-- Table structure for table 'mitstelle'
--

CREATE TABLE mitstelle (
  mit_id int(11) default NULL,
  stz int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'mitstelle'
--



--
-- Table structure for table 'protokoll'
--

CREATE TABLE protokoll (
  nr int(11) default NULL,
  zeit varchar(17) default NULL,
  artdeszugriffs longtext,
  benutzerkennung varchar(25) default NULL,
  ipadresse varchar(25) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'protokoll'
--



--
-- Table structure for table 'schluessel'
--

CREATE TABLE schluessel (
  tab_id int(11) default NULL,
  feld_id int(11) default NULL,
  seq int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'schluessel'
--



--
-- Table structure for table 'sessions'
--

CREATE TABLE sessions (
  session_id char(50) default NULL,
  time char(16) default NULL,
  user_name char(25) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'sessions'
--



--
-- Table structure for table 'strassenkat'
--

CREATE TABLE strassenkat (
  str_nummer char(5) default NULL,
  str_name char(60) default NULL,
  hausnr char(4) default NULL,
  bezirk int(11) default NULL,
  plz int(11) default NULL,
  Plraum char(4) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'strassenkat'
--



--
-- Table structure for table 'tabelle'
--

CREATE TABLE tabelle (
  id int(11) default NULL,
  tabelle char(30) default NULL,
  name char(60) default NULL,
  klasse char(60) default NULL,
  flag int(11) default NULL,
  dok char(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'tabelle'
--


INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (1,'mitarbeiter','Mitarbeiter','Mitarbeiter',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (2,'protokoll','Protokoll','Protokoll',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (3,'strassenkat','Strassenkatalog','Strassenkatalog',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (4,'sessions','Session','Session',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (5,'mitstelle','Zuordnung Mitarbeiter-Dienststelle','MitarbeiterDienststelle',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (6,'akte','Akte','Akte',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (7,'fall','Fall','Fall',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (8,'anmeldung','Anmeldung','Anmeldung',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (9,'bezugsperson','Bezugsperson','Bezugsperson',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (10,'einrichtung','Kontakt mit Einrichtung','Einrichtungskontakt',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (11,'leistung','Leistung','Leistung',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (12,'zustaendigkeit','Zust�ndigkeit','Zustaendigkeit',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (13,'dokument','Dokument','Dokument',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (14,'gruppendokument','Zuordnung Gruppe-Dokument','Gruppendokument',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (15,'gruppe','Gruppe','Gruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (16,'fallgruppe','Zuordnung Fall-Gruppe','FallGruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (17,'bezugspersongruppe','Zuordnung Bezugsperson-Gruppe','BezugspersonGruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (18,'mitarbeitergruppe','Zuordnung Mitarbeiter-Gruppe','MitarbeiterGruppe',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (19,'fachstat','Fachstatistik','Fachstatistik',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (20,'fachstatlei','Zuordnung Fachstatistik-Leistung','Fachstatistikleistung',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (21,'fachstatkindproblem','Zuordnung Fachstatistik-Problemspektrum Kind','Fachstatistikkindproblem',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (22,'fachstatelternproblem','Zuordnung Fachstatistik-Problemspektrum Eltern','Fachstatistikelternproblem',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (23,'jghstat','Jugendhilfestatistik','Jugendhilfestatistik',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (24,'code','Code','Code',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (25,'kategorie','Kategorie','Kategorie',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (26,'exportprotokoll','DB Exportprotokoll','Exportprotokoll',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (27,'importprotokoll','DB Importprotokoll','Importprotokoll',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (28,'feld','Feld','Feld',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (29,'tabelle','Tabelle','Tabelle',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (30,'tabid','Zuordnung Tabelle-ID-Bereiche','TabellenID',0,NULL);
INSERT INTO tabelle (id, tabelle, name, klasse, flag, dok) VALUES (31,'schluessel','Schl�ssel','Schluessel',0,NULL);

--
-- Table structure for table 'tabid'
--

CREATE TABLE tabid (
  table_id int(11) default NULL,
  table_name char(30) default NULL,
  dbsite int(11) default NULL,
  minid int(11) default NULL,
  maxid int(11) default NULL,
  maxist int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'tabid'
--


INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (1,'mitarbeiter',360,1,1000000000,7);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (2,'protokoll',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (4,'sessions',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (6,'akte',360,1,1000000000,36);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (7,'fall',360,1,1000000000,38);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (8,'anmeldung',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (9,'bezugsperson',360,1,1000000000,79);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (10,'einrichtung',360,1,1000000000,33);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (11,'leistung',360,1,1000000000,60);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (12,'zustaendigkeit',360,1,1000000000,38);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (13,'dokument',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (14,'gruppendokument',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (15,'gruppe',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (16,'fallgruppe',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (17,'bezugspersongruppe',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (18,'mitarbeitergruppe',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (19,'fachstat',360,1,1000000000,36);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (20,'fachstatlei',360,1,1000000000,190);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (21,'fachstatkindproblem',360,1,1000000000,98);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (22,'fachstatelternproblem',360,1,1000000000,93);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (23,'jghstat',360,1,1000000000,36);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (24,'code',360,1,1000000000,365);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (25,'kategorie',360,1,1000000000,60);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (26,'exportprotokoll',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (27,'importprotokoll',360,1,1000000000,1);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (28,'feld',360,1,1000000000,332);
INSERT INTO tabid (table_id, table_name, dbsite, minid, maxid, maxist) VALUES (29,'tabelle',360,1,1000000000,31);

--
-- Table structure for table 'zustaendigkeit'
--

CREATE TABLE zustaendigkeit (
  id int(11) default NULL,
  fall_id int(11) default NULL,
  mit_id int(11) default NULL,
  bgd int(11) default NULL,
  bgm int(11) default NULL,
  bgy int(11) default NULL,
  ed int(11) default NULL,
  em int(11) default NULL,
  ey int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'zustaendigkeit'
--


INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (2,2,5,25,11,2002,21,8,2003);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (3,3,5,6,1,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (4,4,6,18,5,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (5,5,5,2,9,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (6,6,6,26,1,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (7,7,6,6,4,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (8,8,7,1,12,2002,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (9,9,5,7,10,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (10,10,6,13,2,2003,5,8,2003);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (11,11,5,23,2,2004,14,9,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (12,12,7,27,7,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (13,13,6,18,9,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (14,14,5,22,9,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (15,15,7,16,7,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (16,16,6,25,3,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (17,17,7,25,12,2002,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (18,18,7,8,10,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (19,19,6,19,12,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (20,20,7,9,6,2004,26,9,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (21,21,5,11,2,2003,13,8,2003);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (22,22,5,22,10,2002,20,8,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (23,23,7,5,1,2003,13,7,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (24,24,7,27,2,2003,3,1,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (25,25,7,18,9,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (26,26,6,10,7,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (27,27,5,8,1,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (28,28,7,16,1,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (29,29,5,7,10,2003,22,2,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (30,30,7,27,10,2002,8,2,2004);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (31,31,5,21,11,2002,14,8,2003);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (32,32,5,28,11,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (33,33,5,4,8,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (34,34,5,12,2,2003,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (35,35,5,6,11,2003,8,12,2003);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (36,36,5,5,3,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (37,37,6,14,3,2004,0,0,0);
INSERT INTO zustaendigkeit (id, fall_id, mit_id, bgd, bgm, bgy, ed, em, ey) VALUES (38,38,7,28,3,2004,0,0,0);

